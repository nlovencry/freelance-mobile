package com.example.bimops

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
