import 'package:flutter/material.dart';

import '../helper/constant.dart';

class CustomDatePicker {
  static Future<DateTime?> pickDate(
    BuildContext context,
    DateTime? date, {
    DatePickerMode? datePickerMode,
    DatePickerEntryMode? datePickerEntryMode,
    DateTime? firstDate,
    DateTime? lastDate,
  }) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: date ?? DateTime.now(),
      initialDatePickerMode: datePickerMode ?? DatePickerMode.day,
      initialEntryMode: datePickerEntryMode ?? DatePickerEntryMode.calendar,
      firstDate: firstDate ?? DateTime(1900),
      lastDate: lastDate ?? DateTime(2101),
      builder: (BuildContext? context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: Constant.primaryColor,
            colorScheme: ColorScheme.light(primary: Constant.primaryColor),
            buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != date) return picked;
  }

  static Future<DateTimeRange?> pickDateRange(
    BuildContext context,
  ) async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(DateTime.now().year - 1),
      lastDate: DateTime(DateTime.now().year + 1),
      builder: (BuildContext? context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: Constant.primaryColor,
            colorScheme: ColorScheme.light(
              primary: Constant.primaryColor,
            ),
            buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) return picked;
  }

  static Future<TimeOfDay?> pickTime(BuildContext context) async {
    final now = DateTime.now();
    final hour = now.hour;
    final minute = now.minute;
    return showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: hour, minute: minute),
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );
  }
}
