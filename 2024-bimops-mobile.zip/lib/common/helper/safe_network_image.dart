import 'package:cached_network_image/cached_network_image.dart';
import 'package:bimops/common/component/skeleton.dart';
import 'package:flutter/material.dart';

class SafeNetworkImage extends StatefulWidget {
  late double width;
  late double height;
  final String url;
  final Widget? errorBuilder;
  bool circle = false;
  double borderRadius = 0;

  SafeNetworkImage(
      {Key? key,
      required this.width,
      required this.height,
      required this.url,
      this.errorBuilder,
      this.borderRadius = 0})
      : super(key: key);

  SafeNetworkImage.circle(
      {required double radius, this.errorBuilder, required this.url}) {
    this.width = radius;
    this.height = radius;
    this.url;
    circle = true;
  }

  @override
  State<SafeNetworkImage> createState() => _SafeNetworkImageState();
}

class _SafeNetworkImageState extends State<SafeNetworkImage> {
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: widget.circle
          ? BorderRadius.circular(widget.width / 2)
          : BorderRadius.circular(widget.borderRadius),
      child: Container(
        width: widget.width,
        height: widget.height,
        child: CachedNetworkImage(
          imageUrl: widget.url,
          width: widget.width,
          height: widget.height,
          fit: BoxFit.cover,
          progressIndicatorBuilder: (context, url, progress) =>
              Skeleton(child: SizedBox()),
          errorWidget: (context, url, error) {
            if (widget.errorBuilder != null) {
              return widget.errorBuilder!;
            } else {
              return Container(
                width: widget.width,
                height: widget.height,
                color: Colors.grey,
              );
            }
          },
        ),
      ),
    );
  }
}
