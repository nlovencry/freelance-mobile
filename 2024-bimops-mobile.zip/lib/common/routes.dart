part of '../main.dart';

Map<String, WidgetBuilder> get _routes => <String, WidgetBuilder>{
      '/': (context) => SplashView(),
      '/login': (context) => LoginView(),
      '/home': (context) => HomeView(
            () {},
            () {},
            () {},
          ),
      // '/forgot': (context) => ForgotView(),
      '/token': (context) => TokenView(),
      '/confirm': (context) => ConfirmationView(),
      '/transaction': (context) => TransactionView(),
      '/assetMeter': (context) => ConfirmationView(),
    };
