import 'package:bimops/common/base/base_state.dart';
import 'package:bimops/common/component/custom_alert.dart';
import 'package:bimops/common/component/custom_button.dart';
import 'package:bimops/common/component/custom_container.dart';
import 'package:bimops/common/component/custom_textfield.dart';
import 'package:bimops/main.dart';
// import 'package:bimops/src/auth/view/sign_up_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

import '../../../common/helper/constant.dart';
import '../../../common/helper/widgets.dart';
import '../../../utils/utils.dart';
import '../../home/view/home_view.dart';
import '../../home/view/main_home.dart';
import '../provider/auth_provider.dart';

class LoginView extends StatefulWidget {
  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends BaseState<LoginView> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    Widget form() {
      return Padding(
        padding: EdgeInsets.only(top: 13, left: 10, right: 10),
        child: Form(
          key: auth.loginKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(top: 40, left: 40, right: 40),
                child: Image.asset('assets/icons/ic-bimops-rectangle2.png'),
              ),
              SizedBox(height: 40),
              CustomTextField.borderTextField(
                controller: auth.usernameC,
                fillColor: Colors.white,
                hintColor: Constant.quarteryColor,
                labelText: "Username",
                hintText: "Enter Username",
                labelFontSize: 20,
                labelFontWeight: FontWeight.bold,
                labelColor: Constant.primaryColor,
                borderColor: Constant.primaryColor,
              ),
              SizedBox(height: 20),
              CustomTextField.borderTextField(
                controller: auth.passC,
                fillColor: Colors.white,
                hintColor: Constant.quarteryColor,
                labelText: "Password",
                hintText: "Enter Password",
                labelFontSize: 20,
                labelFontWeight: FontWeight.bold,
                labelColor: Constant.primaryColor,
                borderColor: Constant.primaryColor,
                obscureText: auth.obscurePass,
                onEditingComplete: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                  // Validate returns true if the form is valid, or false otherwise.
                  if (_formKey.currentState!.validate()) {
                    // If the form is valid, display a snackbar. In the real world,
                    // you'd often call a server or save the information in a database.
                    // WrapLoading(auth.login()).then((value) {
                    //   Navigator.restorablePushReplacementNamed(
                    //       context, '/home');
                    // }).onError((error, stackTrace) {
                    //   CustomAlert.showSnackBar(
                    //     context,
                    //     error.toString().toLowerCase().contains("doctype")
                    //         ? "Maaf, Terjadi Galat!"
                    //         : error.toString(),
                    //     true,
                    //   );
                    // });
                  }
                },
                suffixIcon: GestureDetector(
                  onTap: () => auth.toggleObscurePass(),
                  child: Icon(
                    auth.obscurePass ? Icons.visibility_off : Icons.visibility,
                    color: Constant.primaryColor,
                  ),
                ),
              ),
              SizedBox(height: 16),
              CustomButton.mainButton(
                "Login",
                () async {
                  FocusScope.of(context).requestFocus(new FocusNode());
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HomeView(
                                () {},
                                () {},
                                () {},
                              )));
                  // Validate returns true if the form is valid, or false otherwise.
                  // if (_formKey.currentState!.validate()) {
                  // If the form is valid, display a snackbar. In the real world,
                  // you'd often call a server or save the information in a database.
                  // WrapLoading(auth.login()).then((value) {
                  //   Navigator.restorablePushReplacementNamed(
                  //       context, '/home');
                  // }).onError((error, stackTrace) {
                  //   CustomAlert.showSnackBar(
                  //     context,
                  //     error.toString().toLowerCase().contains("doctype")
                  //         ? "Maaf, Terjadi Galat!"
                  //         : error.toString(),
                  //     true,
                  //   );
                  // });
                  // }
                  // try {
                  //   final result = await context.read<AuthProvider>().login();
                  //   if (result.success == true) {
                  //     Navigator.pushReplacementNamed(context, '/home',
                  //         arguments: result.data?.roles ?? "");
                  //   } else {
                  //     Utils.showFailed(msg: result.message ?? "Error");
                  //   }
                  // } catch (e) {
                  //   Utils.showFailed(
                  //       msg: e.toString().toLowerCase().contains("doctype")
                  //           ? "Maaf, Terjadi Galat!"
                  //           : "$e");
                  // }
                },
                textStyle: Constant.whiteExtraBold18,
                contentPadding: EdgeInsets.all(16),
                margin: EdgeInsets.symmetric(horizontal: 20),
              ),
              SizedBox(height: 8),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Constant.quarteryColor.withOpacity(0.2),
      body: SafeArea(
        top: true,
        child: ListView(
          children: [
            Form(key: _formKey, child: form()),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
