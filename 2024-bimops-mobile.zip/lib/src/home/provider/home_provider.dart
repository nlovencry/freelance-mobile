import 'dart:convert';
import 'dart:developer';

import 'package:bimops/common/base/base_controller.dart';
import 'package:bimops/common/helper/constant.dart';
import 'package:bimops/src/home/model/home_model.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeProvider extends BaseController with ChangeNotifier {
  String isSubAgent = "agen";
  String get getIsSubAgent => this.isSubAgent;
  HomeModel homeModel = HomeModel();

  HomeModel get getHomeModel => this.homeModel;

  set setHomeModel(HomeModel homeModel) => this.homeModel = homeModel;
  set setIsSubAgent(String isSubAgent) => this.isSubAgent = isSubAgent;

  Future<void> fetchHome({bool withLoading = false}) async {
    log("IS SUB AGENT : $getIsSubAgent");
    if (withLoading) loading(true);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setIsSubAgent = prefs.getString(Constant.kSetPrefRoles) ?? "agen";

    final response = await get(Constant.BASE_API_FULL + '/agen/home');

    if (response.statusCode == 201 || response.statusCode == 200) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      setHomeModel = HomeModel.fromJson(jsonDecode(response.body));
      notifyListeners();

      if (withLoading) loading(false);
      // return model;
    } else {
      final message = jsonDecode(response.body)["message"];
      loading(false);
      throw Exception(message);
    }
  }
}
