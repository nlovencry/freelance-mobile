import 'package:bimops/common/component/custom_container.dart';
import 'package:bimops/common/component/skeleton.dart';
import 'package:bimops/common/helper/safe_network_image.dart';
import 'package:bimops/src/home/model/home_model.dart';
import 'package:bimops/src/home/provider/home_provider.dart';
import 'package:bimops/src/jamaah/view/detail_jamaah_view.dart';
import 'package:bimops/src/jamaah/view/tambah_jamaah_2_view.dart';
import 'package:bimops/src/jamaah/view/pilih_paket_umroh_view.dart';
import 'package:bimops/src/komisi/view/komisi_sub_agen_view.dart';
import 'package:bimops/src/komisi/view/tarik_komisi_view.dart';
import 'package:bimops/src/paket/view/paket_umroh_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../../common/helper/constant.dart';
import '../../../utils/utils.dart';
import '../../auth/provider/auth_provider.dart';
import '../../komisi/view/komisi_agen_view.dart';
import '../../paket/provider/paket_provider.dart';
import '../../paket/view/paket_haji_view.dart';
import '../../sub_agen/view/add_sub_agen_view.dart';

class HomeView extends StatelessWidget {
  HomeView(this.jumpToJamaah, this.jumpToSubAgen, this.jumpToProfile);

  final void Function() jumpToJamaah;
  final void Function() jumpToSubAgen;
  final void Function() jumpToProfile;

  static String thousandSeparator(int val) {
    return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
        .format(val);
  }

  @override
  Widget build(BuildContext context) {
    final home = context.watch<HomeProvider>();

    Widget header() {
      return Center(
        child: Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Text(
            'Home',
            style: Constant.primaryTextStyle
                .copyWith(fontSize: 18, color: Colors.white),
          ),
        ),
      );
    }

    Widget account() {
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 20),
        child: GestureDetector(
          onTap: () async {
            SharedPreferences prefs = await SharedPreferences.getInstance();

            final roles = prefs.getString(Constant.kSetPrefRoles);
            // Navigator.push(context, MaterialPageRoute(
            //   builder: (context) {
            //     if (roles == "agen") {
            //       return KomisiAgenView();
            //     }
            //     return KomisiSubAgenView(
            //         adminId: home.homeModel.data?.user?.id ?? 0);
            //   },
            // ));
          },
          child: Row(
            children: [
              Image.asset('assets/icons/ic-bimops-logo.png',
                  width: 40, height: 40),
              InkWell(
                onTap: () async {
                  jumpToProfile();
                },
                onLongPress: () async {
                  SharedPreferences prefs =
                      await SharedPreferences.getInstance();
                  String? fcm = prefs.getString(Constant.kSetPrefFcmToken);
                  Clipboard.setData(new ClipboardData(text: fcm ?? ""));
                  Utils.showSuccess(msg: "FCM TOKEN DISALIN");
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Ferdi Hidayat", style: Constant.iBlackMedium13),
                    SizedBox(height: 4),
                    Text("961121046", style: Constant.grayMedium13),
                    // Text("961121046", style: Constant.grayMedium13),
                  ],
                ),
              ),
              // lama
              // CircleAvatar(
              //   radius: 28,
              //   backgroundColor: Colors.white,
              //   child: CircleAvatar(
              //     radius: 26,
              //     backgroundImage: NetworkImage(
              //         '${home.getHomeModel.data?.user?.photoPath ?? ""}'),
              //   ),
              // )
            ],
          ),
        ),
      );
    }

    Widget subMenu() {
      return Container(
        height: 82,
        margin: EdgeInsets.only(top: 14, left: 20, right: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: home.getIsSubAgent != "agen" ? 5 : 3,
              child: InkWell(
                onTap: () {
                  // Navigator.of(context).push(MaterialPageRoute(
                  //   builder: (context) => TarikKomisiView(),
                  // ));
                },
                child: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 1,
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: home.getIsSubAgent != "agen"
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                                margin: EdgeInsets.only(top: 4),
                                child: Image.asset(
                                  'assets/icons/Tarik Komisi.png',
                                  width: 30,
                                )),
                            Text(
                              'Tarik Komisi',
                              style: Constant.primaryTextStyle.copyWith(
                                  fontSize: 12, fontWeight: Constant.semibold),
                              textAlign: TextAlign.center,
                            )
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                                margin: EdgeInsets.only(top: 4),
                                child: Image.asset(
                                  'assets/icons/Tarik Komisi.png',
                                  width: 30,
                                )),
                            Text(
                              'Tarik Komisi',
                              style: Constant.primaryTextStyle.copyWith(
                                  fontSize: 12, fontWeight: Constant.semibold),
                              textAlign: TextAlign.center,
                            )
                          ],
                        ),
                ),
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              flex: home.getIsSubAgent != "agen" ? 5 : 3,
              child: InkWell(
                onTap: () {
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //       builder: (context) => TambahJamaah2View(),
                  //     ));
                },
                child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 2,
                        ),
                      ],
                    ),
                    child: home.getIsSubAgent != "agen"
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                  margin: EdgeInsets.only(top: 4),
                                  child: Image.asset(
                                    'assets/icons/Tambah Agen.png',
                                    width: 30,
                                  )),
                              Flexible(
                                flex: 1,
                                child: Text(
                                  'Tambah Tabungan Jamaah',
                                  style: Constant.primaryTextStyle.copyWith(
                                      fontSize: 12,
                                      fontWeight: Constant.semibold),
                                  textAlign: TextAlign.center,
                                ),
                              )
                            ],
                          )
                        : InkWell(
                            onTap: () {
                              // Navigator.push(
                              //     context,
                              //     MaterialPageRoute(
                              //       builder: (context) => AddSubAgenView(),
                              //     ));
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    child: Image.asset(
                                  'assets/icons/Tambah Agen.png',
                                  width: 30,
                                )),
                                Text(
                                  'Tambah Sub Agen',
                                  style: Constant.primaryTextStyle.copyWith(
                                      fontSize: 12,
                                      fontWeight: Constant.semibold),
                                  textAlign: TextAlign.center,
                                )
                              ],
                            ),
                          )),
              ),
            ),
            SizedBox(width: home.getIsSubAgent != "agen" ? 0 : 8),
            home.getIsSubAgent != "agen"
                ? SizedBox()
                : Expanded(
                    flex: 3,
                    child: InkWell(
                      onTap: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //       builder: (context) => TambahJamaah2View(),
                        //     ));
                      },
                      child: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 1,
                              blurRadius: 2,
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                                margin: EdgeInsets.only(top: 2),
                                child: Image.asset(
                                  'assets/icons/tambah Jamaah.png',
                                  width: 30,
                                )),
                            Text(
                              'Tambah Tabungan Jamaah',
                              style: Constant.primaryTextStyle.copyWith(
                                  fontSize: 12, fontWeight: Constant.semibold),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
          ],
        ),
      );
    }

    Widget mainMenu() {
      return Container(
        margin: EdgeInsets.only(top: 10, left: 20, right: 20),
        height: 180,
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  blurRadius: 7,
                  offset: Offset(0, 1))
            ]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.only(left: 20, top: 20, right: 20),
              child: Text(
                'Menu Utama',
                style: Constant.primaryTextStyle
                    .copyWith(fontSize: 18, fontWeight: Constant.bold),
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () async {
                      // context.read<PaketProvider>().clearFilter();
                      // Navigator.push(
                      //     context,
                      //     MaterialPageRoute(
                      //       builder: (context) => PaketUmrohView(),
                      //     ));
                    },
                    child: Container(
                      height: 106,
                      margin: EdgeInsets.only(top: 18),
                      child: Column(
                        children: [
                          Container(
                              child: Image.asset(
                            'assets/icons/Paket Umroh_1.png',
                            width: 60,
                          )),
                          SizedBox(height: 8),
                          Text(
                            'Paket Umroh',
                            style: Constant.primaryTextStyle.copyWith(
                                fontSize: 12, fontWeight: Constant.semibold),
                          )
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      // context.read<PaketProvider>().clearFilter();
                      // Navigator.push(
                      // context,
                      // MaterialPageRoute(
                      //   builder: (context) => PaketHajiView(),
                      // ));
                    },
                    child: Container(
                      height: 106,
                      margin: EdgeInsets.only(top: 18),
                      child: Column(
                        children: [
                          Container(
                              child: Image.asset(
                            'assets/icons/Paket haji_1.png',
                            width: 60,
                          )),
                          SizedBox(height: 8),
                          Text(
                            'Paket Haji',
                            style: Constant.primaryTextStyle.copyWith(
                                fontSize: 12, fontWeight: Constant.semibold),
                          )
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: jumpToJamaah,
                    child: Container(
                      height: 106,
                      margin: EdgeInsets.only(top: 18),
                      child: Column(
                        children: [
                          Container(
                              child: Image.asset(
                            'assets/icons/Daftar Jamaah_1.png',
                            width: 60,
                          )),
                          SizedBox(height: 8),
                          Text(
                            'Data Jamaah',
                            style: Constant.primaryTextStyle.copyWith(
                                fontSize: 12, fontWeight: Constant.semibold),
                          )
                        ],
                      ),
                    ),
                  ),
                  if (home.getIsSubAgent == "agen")
                    GestureDetector(
                      onTap: jumpToSubAgen,
                      child: Container(
                        height: 106,
                        margin: EdgeInsets.only(top: 18),
                        child: Column(
                          children: [
                            Container(
                                child: Image.asset(
                              'assets/icons/Daftar Sub Agen_1.png',
                              width: 60,
                            )),
                            SizedBox(height: 8),
                            Text(
                              'Data Sub\nAgen',
                              textAlign: TextAlign.center,
                              style: Constant.primaryTextStyle.copyWith(
                                  fontSize: 12, fontWeight: Constant.semibold),
                            ),
                          ],
                        ),
                      ),
                    )
                ],
              ),
            )
          ],
        ),
      );
    }

    Widget jamaahTiTle() {
      return Container(
        margin: EdgeInsets.only(
            left: 20, right: 20, top: home.getIsSubAgent != "agen" ? 0 : 0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Data Jamaah',
              style: Constant.primaryTextStyle
                  .copyWith(fontSize: 18, fontWeight: Constant.bold),
            ),
            GestureDetector(
              onTap: jumpToJamaah,
              child: Container(
                child: Text(
                  'Lihat semua',
                  style: Constant.primaryTextStyle.copyWith(
                      color: Constant.primaryColor,
                      fontWeight: Constant.semibold),
                ),
              ),
            )
          ],
        ),
      );
    }

    Widget jamaahList() {
      return ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: home.getHomeModel.data?.jamaah?.length ?? 0,
        separatorBuilder: (context, index) => SizedBox(height: 10),
        itemBuilder: (context, index) {
          final jamaah = home.getHomeModel.data?.jamaah?[index];
          return GestureDetector(
            onTap: () {
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) =>
              //             DetailJamaah.create(jamaah?.id ?? 0)));
            },
            child: Container(
                // height: 84,
                width: double.infinity,
                margin: EdgeInsets.only(left: 20, right: 20),
                padding:
                    EdgeInsets.only(left: 14, right: 14, top: 12, bottom: 12),
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey, width: 0.5),
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration:
                          BoxDecoration(borderRadius: BorderRadius.circular(8)),
                      child: SafeNetworkImage(
                        width: 40,
                        height: 40,
                        borderRadius: 10,
                        url: jamaah?.photo ?? "",
                        errorBuilder: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 12,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${jamaah?.userName}'.toUpperCase(),
                            style: Constant.primaryTextStyle.copyWith(
                              fontWeight: Constant.bold,
                            ),
                          ),
                          Divider(
                            thickness: 0.4,
                            color: Colors.grey,
                          ),
                          // SizedBox(
                          //   height: 2,
                          // ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${jamaah?.memberNo}',
                                style: Constant.primaryTextStyle
                                    .copyWith(fontSize: 12),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Image.asset(
                                    'assets/icons/userr.png',
                                    width: 13,
                                  ),
                                  SizedBox(
                                    width: 8,
                                  ),
                                  Text(
                                    'Bekti Danu',
                                    style: Constant.primaryTextStyle.copyWith(
                                        // fontWeight: Constant.bold,
                                        fontSize: 12),
                                  ),
                                ],
                              )
                              // Spacer(),
                              // jamaah1?.agenName == null ||
                              //         jamaah1?.agenName == ""
                              //     ? SizedBox(
                              //         width: 10,
                              //       )
                              //     : Row(
                              //         mainAxisAlignment: MainAxisAlignment.end,
                              //         children: [
                              //           Image.asset(
                              //             'assets/icons/userr.png',
                              //             width: 13,
                              //           ),
                              //           SizedBox(
                              //             width: 8,
                              //           ),
                              //           Text(
                              //             '${jamaah1?.agenName}',
                              //             style: Constant.primaryTextStyle
                              //                 .copyWith(
                              //                     // fontWeight: Constant.bold,
                              //                     fontSize: 12),
                              //           ),
                              //         ],
                              //       )
                            ],
                          ),
                          SizedBox(
                            height: 6,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Image.asset(
                                    'assets/icons/money.png',
                                    width: 15,
                                  ),
                                  SizedBox(
                                    width: 8,
                                  ),
                                  Text(
                                    '${jamaah?.totalPaidDesc}',
                                    style: Constant.primaryTextStyle.copyWith(
                                        fontWeight: Constant.bold,
                                        fontSize: 12),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Image.asset(
                                    'assets/icons/calendar.png',
                                    width: 12,
                                  ),
                                  SizedBox(
                                    width: 8,
                                  ),
                                  Text(
                                    '${jamaah?.dates}',
                                    style: Constant.primaryTextStyle.copyWith(
                                        // fontWeight: Constant.bold,
                                        fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                )),
          );
        },
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        top: true,
        child: Container(
          color: Colors.white,
          child: RefreshIndicator(
            color: Constant.primaryColor,
            onRefresh: () async {
              await context.read<HomeProvider>().fetchHome(withLoading: true);
            },
            child: ListView(
              children: [
                header(),
                account(),
                subMenu(),
                mainMenu(),
                SizedBox(height: 16),
                jamaahTiTle(),
                SizedBox(height: 12),
                jamaahList(),
                SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
