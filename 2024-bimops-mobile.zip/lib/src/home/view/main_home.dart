// import 'dart:io';

// import 'package:chatour/src/home/model/home_model.dart';
// import 'package:chatour/src/home/provider/home_provider.dart';
// import 'package:chatour/src/home/view/home_view.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:chatour/src/jamaah/view/jamaah_view.dart';
// import 'package:chatour/src/notifikasi/provider/notifikasi_provider.dart';
// import 'package:chatour/src/notifikasi/view/notifikasi_view.dart';
// import 'package:chatour/src/profil/provider/profile_provider.dart';
// import 'package:chatour/src/sub_agen/provider/sub_agen_provider.dart';
// import 'package:chatour/src/sub_agen/view/sub_agen_view.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import 'package:shared_preferences/shared_preferences.dart';
// import '../../../common/helper/constant.dart';
// import '../../../utils/utils.dart';
// import '../../paket/provider/paket_provider.dart';
// import '../../profil/view/profile_view.dart';

// class MainHome extends StatefulWidget {
//   final int? index;

//   const MainHome({super.key, this.index});

//   @override
//   State<MainHome> createState() => _MainHomeState();
// }

// class _MainHomeState extends State<MainHome> {
//   int currentIndex = 0;
//   late HomeModel homeModel;
//   String? roles;

//   @override
//   void initState() {
//     getData();
//     // setIndex();
//     super.initState();
//   }

//   @override
//   void didChangeDependencies() {
//     roles = ModalRoute.of(context)?.settings.arguments as String?;
//     // getData();
//     super.didChangeDependencies();
//   }

//   getData() async {
//     setIndex();
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     // roles = prefs.getString(Constant.kSetPrefRoles);
//     await Utils.showLoading();
//     await context.read<HomeProvider>().fetchHome();
//     await context.read<ProfileProvider>().fetchProfile(context: context);
//     // await context.read<JamaahProvider>().fetchJamaah();
//     // if (roles == "agen") await context.read<SubAgenProvider>().fetchSubAgen();
//     await context.read<ProfileProvider>().fetchSosmed();
//     await context.read<NotifikasiProvider>().fetchNotif();
//     await Utils.dismissLoading();
//     setState(() {});
//   }

//   setIndex() {
//     setState(() {
//       if (widget.index != null) {
//         currentIndex = widget.index ?? 0;
//       }
//     });
//   }

//   void jumpToJamaah() {
//     setState(() {
//       currentIndex = 1;
//     });
//   }

//   void jumpToSubAgen() {
//     setState(() {
//       currentIndex = 2;
//     });
//   }

//   void jumpToProfile() {
//     setState(() {
//       if (roles == "agen") {
//         currentIndex = 4;
//       } else {
//         currentIndex = 3;
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     Widget customBottomNav() {
//       return Container(
//         height: Platform.isAndroid ? 70 : 105,
//         decoration: BoxDecoration(
//           boxShadow: [
//             BoxShadow(
//               color: Colors.grey.withOpacity(0.5),
//               spreadRadius: 4,
//               blurRadius: 7,
//               offset: Offset(0, 1), // changes position of shadow
//             ),
//           ],
//         ),
//         child: BottomNavigationBar(
//           backgroundColor: Colors.white,
//           selectedFontSize: 12,
//           unselectedItemColor: Colors.grey,
//           currentIndex: currentIndex,
//           onTap: (index) {
//             context.read<PaketProvider>().clearFilter();
//             setState(() => currentIndex = index);
//           },
//           type: BottomNavigationBarType.fixed,
//           selectedIconTheme: IconThemeData(color: Constant.primaryColor),
//           selectedItemColor: Constant.primaryColor,
//           items: [
//             BottomNavigationBarItem(
//                 icon: SizedBox(
//                     width: 22,
//                     height: 22,
//                     child: FittedBox(
//                         child: Image.asset(currentIndex == 0
//                             ? 'assets/icons/home.png'
//                             : 'assets/icons/home abu.png'))),
//                 label: 'Home'
//                 // icon:
//                 //     Icon(currentIndex == 0 ? Icons.home : Icons.home_outlined),
//                 // label: 'Home'
//                 ),
//             BottomNavigationBarItem(
//                 // icon: SizedBox(width: 22, height: 22, child: FittedBox(child: Image.asset(currentIndex == 0 ? 'assets/icons/home 1.png' : 'assets/icons/home abu.png'))),
//                 // label: 'Home'
//                 icon: Icon(
//                   currentIndex == 1
//                       ? Icons.person_4_outlined
//                       : Icons.person_4_outlined,
//                   weight: 0.2,
//                 ),
//                 label: 'Jamaah'),
//             if (roles == "agen")
//               BottomNavigationBarItem(
//                   icon: Icon(
//                       currentIndex == 2 ? Icons.people : Icons.people_outline),
//                   label: 'Sub Agen'),
//             BottomNavigationBarItem(
//                 icon: SizedBox(
//                     width: 22,
//                     height: 22,
//                     child: FittedBox(
//                         child: Image.asset((roles == "agen"
//                                 ? currentIndex == 3
//                                 : currentIndex == 2)
//                             ? 'assets/icons/notification merah 1.png'
//                             : 'assets/icons/notification.png'))),
//                 label: 'Notifikasi'
//                 // icon: Icon(currentIndex == 3
//                 //     ? Icons.notifications
//                 //     : Icons.notifications_outlined),
//                 // label: 'Notifikasi'
//                 ),
//             BottomNavigationBarItem(
//                 icon: SizedBox(
//                     width: 22,
//                     height: 22,
//                     child: FittedBox(
//                         child: Image.asset((roles == "agen"
//                                 ? currentIndex == 4
//                                 : currentIndex == 3)
//                             ? 'assets/icons/Profile merah.png'
//                             : 'assets/icons/Profile.png'))),
//                 label: 'Profil'
//                 // icon: Icon(currentIndex == 4
//                 //     ? Icons.person_2
//                 //     : Icons.person_2_outlined),
//                 // label: 'Profil'
//                 ),
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       primary: true,
//       bottomNavigationBar: customBottomNav(),
//       body: WillPopScope(
//         onWillPop: () async {
//           if (currentIndex != 0) {
//             setState(() => currentIndex = 0);
//             return false;
//           }
//           // kalau sudah ada api maka muncul konfirm exit dua kali
//           return true;
//         },
//         child: [
//           HomeView(jumpToJamaah, jumpToSubAgen, jumpToProfile),
//           JamaahView(),
//           if (roles == "agen") SubAgenView(),
//           NotifikasiView(),
//           ProfileView(jumpToJamaah, jumpToSubAgen)
//         ][currentIndex],
//       ),
//     );
//   }
// }
