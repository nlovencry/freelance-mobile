// import 'dart:convert';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/model/jamaah_detail_model.dart';
// import 'package:flutter/material.dart';

// import '../../../common/helper/download_file_helper_2.dart';
// import '../../../common/helper/downloading_dialog.dart';
// import '../view/detail_jamaah_view.dart';

// class DetailJamaahProvider extends BaseController with ChangeNotifier {
//   JamaahDetailModel jamaahDetailModel = JamaahDetailModel();

//   JamaahDetailModel get getJamaahDetailModel => this.jamaahDetailModel;

//   set getJamaahDetailModel(JamaahDetailModel value) {
//     this.jamaahDetailModel = value;
//     notifyListeners();
//   }

//   Future<void> fetchDetailJamaah(int id, {bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     final response =
//         await get(Constant.BASE_API_FULL + '/agen/jamaah-detail/${id}');

//     if (response.statusCode == 200) {
//       final model = JamaahDetailModel.fromJson(jsonDecode(response.body));
//       getJamaahDetailModel = model;
//       notifyListeners();
//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   DownloadFileHelper2 _downloadFileHelper2 = DownloadFileHelper2();
//   DownloadFileHelper2 get downloadFileHelper2 => this._downloadFileHelper2;

//   set downloadFileHelper2(DownloadFileHelper2 value) =>
//       this._downloadFileHelper2 = value;

//   late GlobalKey<DownloadingDialogState> downloadingDialogKey;

//   DetailJamaahState? state;
//   DetailJamaahState? get getState => this.state;

//   set setState(DetailJamaahState? state) => this.state = state;

//   init() {
//     downloadFileHelper2.setdownloadListener(state!.context,
//         onFinished: (String id) {
//       if (downloadFileHelper2.isOpenOnly(id)) {
//         final downloadingState = downloadingDialogKey.currentState!;
//         downloadingState.finish();
//       }
//     }, onProgress: (String id, int progress) {
//       if (downloadFileHelper2.isOpenOnly(id)) {
//         final downloadingState = downloadingDialogKey.currentState!;
//         downloadingState.setState(() {
//           downloadingState.percentage = progress / 100;
//         });
//       }
//     }, onRetry: (String id, int count) {
//       if (downloadFileHelper2.isOpenOnly(id)) {
//         final downloadingState = downloadingDialogKey.currentState!;
//         downloadingState.widget.taskId = id;
//       }
//     }, onFailed: (id) {
//       if (downloadFileHelper2.isOpenOnly(id)) {
//         final downloadingState = downloadingDialogKey.currentState!;
//         downloadingState.failed();
//       }
//     });
//   }
// }
