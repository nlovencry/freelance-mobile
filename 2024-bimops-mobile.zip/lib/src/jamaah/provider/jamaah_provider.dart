// import 'dart:convert';
// import 'dart:developer';
// import 'dart:io';

// import 'package:chatour/src/jamaah/model/add_jamaah_model.dart';
// import 'package:chatour/src/jamaah/model/detail_booking_model.dart';
// import 'package:chatour/src/jamaah/model/jamaah_list_sub_agen_model.dart';
// import 'package:chatour/src/jamaah/model/paket_booking_model.dart';
// import 'package:http/http.dart' as http;
// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/model/jamaah_detail_model.dart';
// import 'package:chatour/src/jamaah/model/jamaah_list_model.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';

// import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
// import '../../../common/base/base_response.dart';
// import '../../../common/helper/download_file_helper_2.dart';
// import '../../../common/helper/multipart.dart';
// import '../../../main.dart';
// import '../../../utils/Utils.dart';
// import '../../region/model/region_model.dart';
// import '../model/add_jamaah_local_model.dart';
// import '../model/create_booking_model.dart';
// import '../model/paket_approval_detail_model.dart';
// import '../model/paket_approval_model.dart';
// import '../model/paket_approval_review_model.dart';

// class JamaahProvider extends BaseController with ChangeNotifier {
//   bool _isFetching = false;
//   bool get isFetching => this._isFetching;

//   set isFetching(bool value) => this._isFetching = value;
//   JamaahListModel jamaahListModel = JamaahListModel();

//   JamaahListModel get getJamaahListModel => this.jamaahListModel;

//   set getJamaahListModel(JamaahListModel value) {
//     this.jamaahListModel = value;
//     notifyListeners();
//   }

//   JamaahListSubAgenModel jamaahListSubAgenModel = JamaahListSubAgenModel();
//   JamaahListSubAgenModel get getJamaahListSubAgenModel =>
//       this.jamaahListSubAgenModel;

//   set setJamaahListSubAgenModel(
//           JamaahListSubAgenModel jamaahListSubAgenModel) =>
//       this.jamaahListSubAgenModel = jamaahListSubAgenModel;

//   TextEditingController NIKC = TextEditingController();
//   TextEditingController namaLengkapC = TextEditingController();
//   TextEditingController namaIbuKandungC = TextEditingController();
//   TextEditingController emailC = TextEditingController();
//   TextEditingController noTelpC = TextEditingController();
//   TextEditingController tempatLahirC = TextEditingController();
//   TextEditingController tanggalLahirC = TextEditingController();
//   TextEditingController tanggalUmrohC = TextEditingController();
//   TextEditingController alamatC = TextEditingController();
//   TextEditingController noRekC = TextEditingController();
//   TextEditingController atasNamaRekC = TextEditingController();

//   TextEditingController searchC = TextEditingController();
//   TextEditingController searchSubAgenC = TextEditingController();

//   PagingController<int, JamaahListModelData> _pagingController =
//       PagingController(firstPageKey: 1);

//   PagingController<int, JamaahListModelData> get pagingController =>
//       this._pagingController;

//   set pagingController(PagingController<int, JamaahListModelData> value) =>
//       this._pagingController = value;

//   int pageSize = 0;

//   get getPageSize => this.pageSize;

//   set setPageSize(pageSize) => this.pageSize;

//   PagingController<int, JamaahListSubAgenModelData> _pagingControllerSubAgen =
//       PagingController(firstPageKey: 1);

//   PagingController<int, JamaahListSubAgenModelData>
//       get pagingControllerSubAgen => this._pagingControllerSubAgen;

//   set pagingControllerSubAgen(
//           PagingController<int, JamaahListSubAgenModelData> value) =>
//       this._pagingControllerSubAgen = value;

//   int pageSizeSubAgen = 0;

//   get getPageSizeSubAgen => this.pageSizeSubAgen;

//   set setPageSizeSubAgen(pageSize) => this.pageSizeSubAgen;

//   String? _paketV;

//   String? get paketV => this._paketV;

//   set paketV(String? value) {
//     this._paketV = value;
//     notifyListeners();
//   }

//   // String? _provinsiV;
//   String? _desaNameV;
//   String? _desaIdV;
//   String? get desaIdV => this._desaIdV;

//   set desaIdV(String? value) {
//     this._desaIdV = value;
//     notifyListeners();
//   }

//   String? _bankRekV;

//   // String? get provinsiV => this._provinsiV;
//   String? _provinsiIdV;
//   String? _provinsiNameV;

//   String? get provinsiNameV => this._provinsiNameV;

//   set provinsiNameV(String? value) {
//     this._provinsiNameV = value;
//     notifyListeners();
//   }

//   String? _kotaIdV;
//   String? _kotaNameV;
//   String? get kotaNameV => this._kotaNameV;

//   set kotaNameV(String? value) {
//     this._kotaNameV = value;
//     notifyListeners();
//   }

//   String? _kecamatanIdV;
//   String? _kecamatanNameV;
//   String? get kecamatanNameV => this._kecamatanNameV;

//   set kecamatanNameV(String? value) {
//     this._kecamatanNameV = value;
//     notifyListeners();
//   }

//   String? get provinsiIdV => this._provinsiIdV;

//   set provinsiIdV(String? value) {
//     this._provinsiIdV = value;
//     notifyListeners();
//   }

//   get kotaIdV => this._kotaIdV;

//   set kotaIdV(value) {
//     this._kotaIdV = value;
//     notifyListeners();
//   }

//   get kecamatanIdV => this._kecamatanIdV;

//   set kecamatanIdV(value) {
//     this._kecamatanIdV = value;
//     notifyListeners();
//   }

//   get desaNameV => this._desaNameV;

//   set desaNameV(value) {
//     this._desaNameV = value;
//     notifyListeners();
//   }

//   get bankRekV => this._bankRekV;

//   set bankRekV(value) {
//     this._bankRekV = value;
//     notifyListeners();
//   }

//   bool _gender = true;

//   get gender => _gender;

//   set gender(value) {
//     this._gender = value;
//     notifyListeners();
//   }

//   GlobalKey<FormState> jamaahKey = GlobalKey<FormState>();

//   DateTime? _tanggalUmroh;

//   get tanggalUmroh => _tanggalUmroh;

//   setTanggalUmroh(DateTime? date) {
//     _tanggalUmroh = date;
//     tanggalUmrohC.text =
//         DateFormat("dd MMMM yyyy").format(date ?? DateTime.now()).toString();

//     notifyListeners();
//   }

//   setTanggalUmrohNull() {
//     _tanggalUmroh = null;
//     tanggalUmrohC.clear();

//     notifyListeners();
//   }

//   DateTime? _tanggalLahir;

//   get tanggalLahir => _tanggalLahir;

//   setTanggalLahir(DateTime? date) {
//     _tanggalLahir = date;
//     tanggalLahirC.text =
//         DateFormat("dd MMMM yyyy").format(date ?? DateTime.now()).toString();

//     notifyListeners();
//   }

//   bool isJamaaht = true;
//   bool get getIsJamaaht => this.isJamaaht;

//   set setIsJamaaht(bool isJamaaht) => this.isJamaaht = isJamaaht;

//   File? _pasPhotoPic;
//   File? get pasPhotoPic => _pasPhotoPic;

//   set pasPhotoPic(File? pasPhotoPic) {
//     _pasPhotoPic = pasPhotoPic;
//     notifyListeners();
//   }

//   File? _ktpPic;
//   File? get ktpPic => _ktpPic;

//   set ktpPic(File? ktpPic) {
//     _ktpPic = ktpPic;
//     notifyListeners();
//   }

//   CreateBookingModel _createBookingModel = CreateBookingModel();
//   CreateBookingModel get createBookingModel => this._createBookingModel;

//   set createBookingModel(CreateBookingModel value) {
//     this._createBookingModel = value;
//     notifyListeners();
//   }

//   Future<void> createBooking(
//       {bool withLoading = false,
//       required String packageId,
//       required bool isGroup}) async {
//     if (withLoading) loading(true);

//     Map<String, String> param = {
//       'package_id': packageId,
//       'is_group': isGroup ? "1" : "0"
//     };
//     final response =
//         await post(Constant.BASE_API_FULL + '/agen/booking', body: param);

//     if (response.statusCode == 200) {
//       final model = CreateBookingModel.fromJson(jsonDecode(response.body));
//       createBookingModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   Future<void> fetchJamaah({
//     required int page,
//     bool withLoading = false,
//   }) async {
//     if (!isFetching) {
//       isFetching = true;

//       log("IS SUB AGENT : $getIsJamaaht");
//       if (withLoading) loading(true);
//       Map<String, String> param = {
//         'page': '$page',
//         'key': searchC.text,
//         // 'is_promo': isPromo == true ? "1" : "0",
//         // 'is_reguler': isReguler == true ? "1" : "0",
//       };
//       final response =
//           await get(Constant.BASE_API_FULL + '/agen/list-jamaah', query: param);

//       if (response.statusCode == 200) {
//         final model = JamaahListModel.fromJson(jsonDecode(response.body));
//         // getJamaahListModel = model;
//         final newItems = model.data ?? [];
//         pageSize = model.pagination?.perPage ?? 0;
//         final isLastPage = newItems.length < pageSize;
//         if (isLastPage) {
//           pagingController
//               .appendLastPage(newItems as List<JamaahListModelData>);
//         } else {
//           final nextPageKey = page += 1;
//           pagingController.appendPage(
//               newItems as List<JamaahListModelData>, nextPageKey);
//         }
//         notifyListeners();

//         if (withLoading) loading(false);
//       } else {
//         final message = jsonDecode(response.body)["message"];
//         pagingController.error = message;
//         loading(false);
//         throw Exception(message);
//       }
//       isFetching = false;
//     }
//   }

//   int _subAgenId = 0;

//   int get subAgenId => this._subAgenId;

//   set subAgenId(int value) => this._subAgenId = value;

//   Future<void> fetchJamaahSubAgen({
//     required int page,
//     bool withLoading = false,
//   }) async {
//     if (!isFetching) {
//       isFetching = true;

//       // log("IS SUB AGENT : $getIsJamaaht");
//       if (withLoading) loading(true);
//       Map<String, String> param = {
//         'page': '$page',
//         'key': searchSubAgenC.text,
//         // 'is_promo': isPromo == true ? "1" : "0",
//         // 'is_reguler': isReguler == true ? "1" : "0",
//       };
//       final response = await get(
//           Constant.BASE_API_FULL + '/agen/list-jamaah-subagen/$subAgenId',
//           query: param);

//       if (response.statusCode == 200) {
//         final model =
//             JamaahListSubAgenModel.fromJson(jsonDecode(response.body));
//         // jamaahListSubAgenModel = model;

//         final newItems = model.data ?? [];
//         pageSizeSubAgen = model.pagination?.perPage ?? 0;
//         final isLastPage = newItems.length < pageSizeSubAgen;
//         if (isLastPage) {
//           pagingControllerSubAgen
//               .appendLastPage(newItems as List<JamaahListSubAgenModelData>);
//         } else {
//           final nextPageKey = page += 1;
//           pagingControllerSubAgen.appendPage(
//               newItems as List<JamaahListSubAgenModelData>, nextPageKey);
//         }
//         notifyListeners();

//         if (withLoading) loading(false);
//       } else {
//         final message = jsonDecode(response.body)["message"];
//         pagingControllerSubAgen.error = message;
//         loading(false);
//         throw Exception(message);
//       }
//       isFetching = false;
//     }
//   }

//   /// add jamaah
//   List<AddJamaahLocalModel> _listJamaahLocal = [];
//   List<AddJamaahLocalModel> get listJamaahLocal => this._listJamaahLocal;

//   set listJamaahLocal(List<AddJamaahLocalModel> value) {
//     this._listJamaahLocal = [];
//     notifyListeners();
//   }

//   clearListJamaahLocal() {
//     this._listJamaahLocal = [];
//     notifyListeners();
//   }

//   List<AddJamaahLocalFilesModel> _listJamaahLocalFiles = [];

//   List<AddJamaahLocalFilesModel> get listJamaahLocalFiles =>
//       this._listJamaahLocalFiles;

//   set listJamaahLocalFiles(List<AddJamaahLocalFilesModel> value) =>
//       this._listJamaahLocalFiles = [];

//   ////////
//   ///addd jamaah
//   /// Halaman 1
//   String? paketUmrohNameV;
//   String? paketUmrohIdV;
//   int? paketUmrohIndexV;
//   String? paketUmrohHargaV;
//   String? get getPaketUmrohNameV => this.paketUmrohNameV;

//   set setPaketUmrohNameV(String? paketUmrohNameV) {
//     this.paketUmrohNameV = paketUmrohNameV;
//     notifyListeners();
//   }

//   String? get getPaketUmrohIdV => this.paketUmrohIdV;

//   set setPaketUmrohIdV(paketUmrohIdV) {
//     this.paketUmrohIdV = paketUmrohIdV;
//     notifyListeners();
//   }

//   int? get getPaketUmrohIndexV => this.paketUmrohIndexV;

//   set setPaketUmrohIndexV(paketUmrohIndexV) =>
//       this.paketUmrohIndexV = paketUmrohIndexV;

//   String? get getPaketUmrohHargaV => this.paketUmrohHargaV;

//   set setPaketUmrohHargaV(String? paketUmrohHargaV) =>
//       this.paketUmrohHargaV = paketUmrohHargaV;

//   String? tanggalUmrohNameV;
//   String? tanggalUmrohIdV;
//   String? get getTanggalUmrohNameV => this.tanggalUmrohNameV;

//   set setTanggalUmrohNameV(String? tanggalUmrohNameV) =>
//       this.tanggalUmrohNameV = tanggalUmrohNameV;

//   get getTanggalUmrohIdV => this.tanggalUmrohIdV;

//   set setTanggalUmrohIdV(tanggalUmrohIdV) =>
//       this.tanggalUmrohIdV = tanggalUmrohIdV;

//   PaketBookingModel _paketBookingModel = PaketBookingModel();

//   PaketBookingModel get paketBookingModel => this._paketBookingModel;

//   set paketBookingModel(PaketBookingModel value) =>
//       this._paketBookingModel = value;

//   // add paket dan tanggal
//   Future<void> fetchPaketBooking({bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     final response =
//         await get(Constant.BASE_API_FULL + '/agen/booking/package');

//     if (response.statusCode == 200) {
//       final model = PaketBookingModel.fromJson(jsonDecode(response.body));
//       paketBookingModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   PaketApprovalModel _paketApprovalModel = PaketApprovalModel();

//   PaketApprovalModel get paketApprovalModel => this._paketApprovalModel;

//   set paketApprovalModel(value) {
//     this._paketApprovalModel = value;
//     notifyListeners();
//   }

//   Future<void> fetchJenisPaket({bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     final response =
//         await get(Constant.BASE_API_FULL + '/agen/approval/package');

//     if (response.statusCode == 200) {
//       final model = PaketApprovalModel.fromJson(jsonDecode(response.body));
//       paketApprovalModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   PaketApprovalDetailModel _paketApprovalDetailModel =
//       PaketApprovalDetailModel();

//   PaketApprovalDetailModel get paketApprovalDetailModel =>
//       this._paketApprovalDetailModel;

//   set paketApprovalDetailModel(value) {
//     this._paketApprovalDetailModel = value;
//     notifyListeners();
//   }

//   Future<void> fetchDetailJenisPaket(String paketId,
//       {bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     final response = await get(
//         Constant.BASE_API_FULL + '/agen/approval/package/detail/${paketId}');

//     if (response.statusCode == 200) {
//       final model =
//           PaketApprovalDetailModel.fromJson(jsonDecode(response.body));
//       paketApprovalDetailModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   PaketApprovalReviewModel _paketApprovalReviewModel =
//       PaketApprovalReviewModel();

//   PaketApprovalReviewModel get paketApprovalReviewModel =>
//       this._paketApprovalReviewModel;

//   set paketApprovalReviewModel(value) {
//     this._paketApprovalReviewModel = value;
//     notifyListeners();
//   }

//   Future<void> fetchReviewApprovalJenisPaket(
//       String paketId, String bookingId, String jamaahId,
//       {bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     Map<String, String> param = {
//       'package_id': paketId,
//       'booking_id': bookingId,
//       'jamaah_id': jamaahId
//     };
//     final response = await get(
//         Constant.BASE_API_FULL + '/agen/approval/review-change-package',
//         query: param);

//     if (response.statusCode == 200) {
//       final model =
//           PaketApprovalReviewModel.fromJson(jsonDecode(response.body));
//       paketApprovalReviewModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   /// Halaman 2
//   bool _tabunganIndividu = true;

//   get tabunganIndividu => _tabunganIndividu;

//   set setTabunganIndividu(value) {
//     this._tabunganIndividu = value;
//     notifyListeners();
//   }

//   /// Halaman Tambah Jamaah
//   bool _teamleader = false;

//   get teamleader => _teamleader;

//   set teamleader(value) {
//     this._teamleader = value;
//     notifyListeners();
//   }

//   bool _setuju = false;
//   bool get setuju => this._setuju;

//   set setuju(bool value) {
//     this._setuju = value;
//     notifyListeners();
//   }

//   Future<void> loadJamaahData(
//     AddJamaahLocalModel? model1,
//     AddJamaahLocalFilesModel? model2,
//     List<ProvinceModelData?>? provinceList,
//     List<CityModelData?>? cityList,
//     List<DistrictModelData?>? districtList,
//     List<SubDistrictModelData?>? subDistrictList,
//   ) async {
//     if (model1 != null) {
//       NIKC.text = model1.nik ?? "";
//       namaLengkapC.text = model1.name ?? "";
//       namaIbuKandungC.text = model1.motherName ?? "";
//       emailC.text = model1.email ?? "";
//       noTelpC.text = model1.phone ?? "";
//       tempatLahirC.text = model1.birthPlace ?? "";
//       setTanggalLahir(DateTime.parse(model1.birthDate ?? ""));
//       gender = model1.gender == "1";
//       alamatC.text = model1.address ?? "";
//       provinsiIdV = model1.provinceId ?? "";
//       kotaIdV = model1.cityId ?? "";
//       kecamatanIdV = model1.districtId ?? "";
//       // desaIdV = model1.subDistrictId ?? "";

//       bankRekV = model1.accBank ?? "";
//       noRekC.text = model1.accNo ?? "";
//       atasNamaRekC.text = model1.accName ?? "";
//       teamleader = model1.isLeader == "1";

//       log("PROVINCE LIST : ${provinceList}");
//       log("PROVINCE LIST : ${model1.provinceId}");
//       if ((provinceList ?? []).isNotEmpty &&
//           model1.provinceId.toString() != "null") {
//         provinsiNameV = (provinceList)
//             ?.firstWhere((element) => element?.provinceId == model1.provinceId)
//             ?.province;
//       }
//       if ((cityList ?? []).isNotEmpty && model1.cityId.toString() != "null") {
//         kotaNameV = (cityList)
//             ?.firstWhere((element) => element?.cityId == model1.cityId)
//             ?.cityName;
//       }
//       if ((districtList ?? []).isNotEmpty &&
//           model1.districtId.toString() != "null") {
//         kecamatanNameV = (districtList)
//             ?.firstWhere((element) => element?.districtId == model1.districtId)
//             ?.districtName;
//       }
//       // desaNameV = (subDistrictList)
//       //     ?.firstWhere(
//       //         (element) => element?.subdistrictId == model1.subDistrictId)
//       //     ?.subdistrictName;
//     }
//     if (model2 != null) {
//       // log("FOTO PATH : ${model2.photo?.path}");
//       pasPhotoPic = model2.photo;
//       ktpPic = model2.ktp;
//     }
//     notifyListeners();
//   }

//   Future<void> addJamaah() async {
//     loading(true);
//     if (jamaahKey.currentState!.validate()) {
//       Map<String, String> param = {
//         "nik": NIKC.text,
//         "name": namaLengkapC.text,
//         "mother_name": namaIbuKandungC.text,
//         "email": emailC.text,
//         "phone": noTelpC.text,
//         "birth_place": tempatLahirC.text,
//         "birth_date": tanggalLahir.toString(),
//         "gender": "${gender ? 1 : 0}",
//         "address": alamatC.text,
//         "province_id": provinsiIdV.toString(),
//         "city_id": kotaIdV.toString(),
//         "district_id": kecamatanIdV.toString(),
//         "sub_district_id": desaIdV.toString(),
//         "acc_bank": bankRekV.toString(),
//         "acc_no": noRekC.text,
//         "acc_name": atasNamaRekC.text,
//         "is_leader": (teamleader ?? false) ? "1" : "0"
//       };
//       listJamaahLocal.add(AddJamaahLocalModel.fromJson(param));

//       List<http.MultipartFile> files = [];
//       if (pasPhotoPic != null) {
//         files.add(await getMultipart('photo', File(pasPhotoPic!.path)));
//       } else {
//         // throw 'Harap Isi Pas Foto';
//       }
//       if (ktpPic != null) {
//         files.add(await getMultipart('ktp', File(ktpPic!.path)));
//       } else {
//         // throw 'Harap Isi Foto KTP';
//       }
//       listJamaahLocalFiles
//           .add(AddJamaahLocalFilesModel(photo: pasPhotoPic, ktp: ktpPic));
//       // final response = BaseResponse.from(await post(
//       //   Constant.BASE_API_FULL + '/agen/order/add-jamaah',
//       //   body: param,
//       //   files: files,
//       // ));

//       // if (response.success) {
//       NIKC.clear();
//       namaLengkapC.clear();
//       namaIbuKandungC.clear();
//       emailC.clear();
//       noTelpC.clear();
//       tempatLahirC.clear();
//       _tanggalLahir = null;
//       tanggalLahirC.clear();
//       gender = true;
//       alamatC.clear();
//       provinsiIdV = null;
//       provinsiNameV = null;
//       kotaIdV = null;
//       kotaNameV = null;
//       kecamatanIdV = null;
//       kecamatanNameV = null;
//       bankRekV = null;
//       noRekC.clear();
//       teamleader = false;
//       atasNamaRekC.clear();
//       pasPhotoPic = null;
//       ktpPic = null;
//       loading(false);
//       // } else {
//       //   loading(false);
//       //   throw Exception(response.message);
//       // }
//     } else {
//       loading(false);
//       throw 'Harap Lengkapi Form';
//     }
//   }

//   Future<void> editJamaah(int index) async {
//     loading(true);
//     if (jamaahKey.currentState!.validate()) {
//       Map<String, String> param = {
//         "nik": NIKC.text,
//         "name": namaLengkapC.text,
//         "mother_name": namaIbuKandungC.text,
//         "email": emailC.text,
//         "phone": noTelpC.text,
//         "birth_place": tempatLahirC.text,
//         "birth_date": tanggalLahir.toString(),
//         "gender": "${gender ? 1 : 0}",
//         "address": alamatC.text,
//         "province_id": provinsiIdV.toString(),
//         "city_id": kotaIdV.toString(),
//         "district_id": kecamatanIdV.toString(),
//         "sub_district_id": desaNameV.toString(),
//         "acc_bank": bankRekV.toString(),
//         "acc_no": noRekC.text,
//         "acc_name": atasNamaRekC.text,
//         "is_leader": (teamleader ?? false) ? "1" : "0"
//       };
//       listJamaahLocal[index] = AddJamaahLocalModel.fromJson(param);

//       List<http.MultipartFile> files = [];
//       if (pasPhotoPic != null) {
//         files.add(await getMultipart('photo', File(pasPhotoPic!.path)));
//       }
//       if (ktpPic != null) {
//         files.add(await getMultipart('ktp', File(ktpPic!.path)));
//       }
//       listJamaahLocalFiles[index] =
//           AddJamaahLocalFilesModel(photo: pasPhotoPic, ktp: ktpPic);
//       // final response = BaseResponse.from(await post(
//       //   Constant.BASE_API_FULL + '/agen/order/add-jamaah',
//       //   body: param,
//       //   files: files,
//       // ));

//       // if (response.success) {
//       NIKC.clear();
//       namaLengkapC.clear();
//       namaIbuKandungC.clear();
//       emailC.clear();
//       noTelpC.clear();
//       tempatLahirC.clear();
//       _tanggalLahir = null;
//       tanggalLahirC.clear();
//       gender = true;
//       alamatC.clear();
//       provinsiIdV = null;
//       provinsiNameV = null;
//       kotaIdV = null;
//       kotaNameV = null;
//       kecamatanIdV = null;
//       kecamatanNameV = null;
//       bankRekV = null;
//       noRekC.clear();
//       teamleader = false;
//       atasNamaRekC.clear();
//       pasPhotoPic = null;
//       ktpPic = null;
//       loading(false);
//       // } else {
//       //   loading(false);
//       //   throw Exception(response.message);
//       // }
//     } else {
//       loading(false);
//       throw 'Harap Lengkapi Form';
//     }
//   }

//   Future<void> deleteJamaah(int index) async {
//     loading(true);
//     NIKC.clear();
//     namaLengkapC.clear();
//     namaIbuKandungC.clear();
//     emailC.clear();
//     noTelpC.clear();
//     tempatLahirC.clear();
//     _tanggalLahir = null;
//     tanggalLahirC.clear();
//     gender = true;
//     alamatC.clear();
//     provinsiIdV = null;
//     provinsiNameV = null;
//     kotaIdV = null;
//     kotaNameV = null;
//     kecamatanIdV = null;
//     kecamatanNameV = null;
//     bankRekV = null;
//     noRekC.clear();
//     teamleader = false;
//     atasNamaRekC.clear();
//     pasPhotoPic = null;
//     ktpPic = null;
//     loading(false);
//     listJamaahLocal.removeAt(index);
//     listJamaahLocalFiles.removeAt(index);
//     notifyListeners();
//     loading(false);
//   }

//   Future<void> clearJamaah({bool deleteAll = false}) async {
//     NIKC.clear();
//     namaLengkapC.clear();
//     namaIbuKandungC.clear();
//     emailC.clear();
//     noTelpC.clear();
//     tempatLahirC.clear();
//     _tanggalLahir = null;
//     tanggalLahirC.clear();
//     gender = true;
//     alamatC.clear();
//     provinsiIdV = null;
//     provinsiNameV = null;
//     kotaIdV = null;
//     kotaNameV = null;
//     kecamatanIdV = null;
//     kecamatanNameV = null;
//     noRekC.clear();
//     teamleader = false;
//     atasNamaRekC.clear();
//     bankRekV = null;
//     pasPhotoPic = null;
//     ktpPic = null;
//     teamleader = false;
//     if (deleteAll) {
//       setTabunganIndividu = true;
//       setuju = false;
//       listAddJamaahModel.clear();
//       listJamaahLocal.clear();
//       listJamaahLocalFiles.clear();
//     }
//   }

//   List<AddJamaahModel> _listAddJamaahModel = [];
//   List<AddJamaahModel> get listAddJamaahModel => this._listAddJamaahModel;

//   set listAddJamaahModel(List<AddJamaahModel> value) {
//     this._listAddJamaahModel = value;
//     notifyListeners();
//   }

//   Future<void> sendJamaah() async {
//     loading(true);
//     for (int i = 0; i < listJamaahLocal.length; i++) {
//       log("KIRIM ${i + 1}");
//       final item = listJamaahLocal[i];
//       final itemFiles = listJamaahLocalFiles[i];
//       Map<String, String> param = {
//         "booking_id": "${createBookingModel.data?.bookingId ?? 0}",
//         "nik": item.nik ?? "",
//         "name": item.name ?? "",
//         "mother_name": item.motherName ?? "",
//         "email": item.email ?? "",
//         "phone": "62" + (item.phone ?? ""),
//         "birth_place": item.birthPlace ?? "",
//         "birth_date": (item.birthDate ?? "").replaceAll(" 00:00:00.000", ""),
//         "gender": item.gender ?? "",
//         "address": item.address ?? "",
//         "province_id": item.provinceId ?? "",
//         "city_id": item.cityId ?? "",
//         "district_id": item.districtId ?? "",
//         "sub_district_id": item.subDistrictId ?? "",
//         "acc_bank": item.accBank ?? "",
//         "acc_no": item.accNo ?? "",
//         "acc_name": item.accName ?? "",
//         "is_leader": item.isLeader ?? ""
//       };
//       List<http.MultipartFile> files = [];
//       if (itemFiles.photo != null) {
//         files.add(await getMultipart('photo', itemFiles.photo!));
//       }
//       if (itemFiles.ktp != null) {
//         files.add(await getMultipart('ktp', itemFiles.ktp!));
//       }
//       final response = await post(
//         Constant.BASE_API_FULL + '/agen/booking/add-jamaah',
//         body: param,
//         files: files,
//       );

//       if (response.statusCode == 200) {
//         final model = AddJamaahModel.fromJson(jsonDecode(response.body));
//         listAddJamaahModel.add(model);
//         notifyListeners();

//         loading(false);
//       } else {
//         final message = jsonDecode(response.body)["message"];
//         loading(false);
//         throw Exception(message);
//       }
//     }
//   }

//   Future<void> confirmBooking() async {
//     loading(true);
//     Map<String, String> param = {
//       "booking_id": "${createBookingModel.data?.bookingId ?? 0}",
//       // "jamaah_id[]": "${item.data?.jamaahId ?? 0}"
//     };
//     final response = BaseResponse.from(await post(
//         Constant.BASE_API_FULL + '/agen/booking/confirm',
//         body: param));

//     if (response.success) {
//       NIKC.clear();
//       namaLengkapC.clear();
//       namaIbuKandungC.clear();
//       emailC.clear();
//       noTelpC.clear();
//       tempatLahirC.clear();
//       _tanggalLahir = null;
//       tanggalLahirC.clear();
//       gender = true;
//       alamatC.clear();
//       provinsiIdV = null;
//       provinsiNameV = null;
//       kotaIdV = null;
//       kotaNameV = null;
//       kecamatanIdV = null;
//       kecamatanNameV = null;
//       bankRekV = null;
//       noRekC.clear();
//       teamleader = false;
//       atasNamaRekC.clear();
//       pasPhotoPic = null;
//       ktpPic = null;
//       listJamaahLocal = [];
//       listJamaahLocalFiles = [];
//       listAddJamaahModel.clear();
//       setTabunganIndividu = true;
//       setuju = false;
//       teamleader = false;
//       loading(false);
//     } else {
//       loading(false);
//       throw Exception(response.message);
//     }
//     // for (int i = 0; i < listAddJamaahModel.length; i++) {
//     //   log("CONFIRM ${i + 1}");
//     //   final item = listAddJamaahModel[i];
//     //
//     //   // List<String> listJamaahId =
//     //   //     listAddJamaahModel.map((e) => "${e.model1?.id ?? 0}").toList();
//     //   // param.addAll({"jamaah_id": "${listJamaahId}"});
//     //
//     //
//     // }
//     loading(false);
//   }

//   DetailBookingModel _detailBookingModel = DetailBookingModel();
//   DetailBookingModel get detailBookingModel => this._detailBookingModel;

//   set detailBookingModel(DetailBookingModel value) =>
//       this._detailBookingModel = value;

//   Future<void> fetchDetailBooking({bool withLoading = false}) async {
//     if (withLoading) loading(true);

//     Map<String, String> param = {
//       "booking_id": "${createBookingModel.data?.bookingId ?? 0}"
//     };
//     final response = await get(Constant.BASE_API_FULL + '/agen/booking/detail',
//         query: param);

//     if (response.statusCode == 200) {
//       final model = DetailBookingModel.fromJson(jsonDecode(response.body));
//       detailBookingModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   Future<void> confirmPaketApproval(int? bookingId, String? packageId) async {
//     loading(true);

//     for (int i = 0;
//         i < (paketApprovalReviewModel.data?.jamaah ?? []).length;
//         i++) {
//       log("CONFIRM APPROVAL : ${i + 1}");
//       final item = paketApprovalReviewModel.data?.jamaah?[i];
//       Map<String, String> param = {
//         "booking_id": "${bookingId ?? 0}",
//         "jamaah_id[]": "${item?.jamaahId ?? 0}",
//         "package_id": "${packageId ?? 0}",
//       };

//       final response = BaseResponse.from(await post(
//           Constant.BASE_API_FULL + '/agen/approval/change-package',
//           body: param));

//       if (response.success) {
//         paketApprovalReviewModel = PaketApprovalReviewModel();
//         setTanggalUmrohNull();
//         paketUmrohIdV = null;
//         paketUmrohNameV = null;
//         loading(false);
//       } else {
//         loading(false);
//         throw Exception(response.message);
//       }
//     }
//     loading(false);
//   }
// }
