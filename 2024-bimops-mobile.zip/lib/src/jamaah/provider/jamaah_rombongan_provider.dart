// import 'dart:convert';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/model/jamaah_rombongan_model.dart';
// import 'package:flutter/material.dart';

// class JamaahRombonganProvider extends BaseController with ChangeNotifier {
//   JamaahRombonganModel _jamaahRombonganModel = JamaahRombonganModel();

//   JamaahRombonganModel get jamaahRombonganModel => this._jamaahRombonganModel;

//   set jamaahRombonganModel(JamaahRombonganModel value) =>
//       this._jamaahRombonganModel = value;

//   Future<void> fetchJamaahRombongan(int bookingId) async {
//     // loading(true);
//     Map<String, String> param = {'booking_id': "$bookingId"};
//     final response = await get(
//         Constant.BASE_API_FULL + '/agen/list-jamaah-group',
//         query: param);

//     if (response.statusCode == 200) {
//       final rombongan =
//           JamaahRombonganModel.fromJson(jsonDecode(response.body));
//       jamaahRombonganModel = rombongan;
//       notifyListeners();
//       // loading(false);
//     } else {
//       final message = jsonDecode(response.body)['message'];
//       loading(false);
//       throw Exception(message);
//     }
//   }
// }
