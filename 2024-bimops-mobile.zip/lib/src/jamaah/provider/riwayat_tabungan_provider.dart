// import 'dart:convert';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/model/riwayat_tabungan_model.dart';
// import 'package:flutter/material.dart';

// class RiwayatTabunganProvider extends BaseController with ChangeNotifier {
//   RiwayatTabunganModel _riwayatTabunganModel = RiwayatTabunganModel();
//   RiwayatTabunganModel get riwayatTabunganModel => this._riwayatTabunganModel;

//   set riwayatTabunganModel(RiwayatTabunganModel value) =>
//       this._riwayatTabunganModel = value;

//   Future<void> fetchRiwayatTabungan(int id, {bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     final response = await get(
//         Constant.BASE_API_FULL + '/agen/booking/list-payment',
//         query: {'jamaah_id': id.toString()});

//     if (response.statusCode == 200) {
//       final model = RiwayatTabunganModel.fromJson(jsonDecode(response.body));
//       riwayatTabunganModel = model;
//       notifyListeners();
//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       if (withLoading) loading(false);
//       throw Exception(message);
//     }
//   }
// }
