// import 'dart:io';

// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_alert.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/provider/detail_jamaah_provider.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';
// import 'package:url_launcher/url_launcher.dart';

// import '../../../common/component/custom_appbar.dart';
// import '../../../common/helper/scroll_listener.dart';

// class DetailJamaahRombonganView extends StatefulWidget {
//   const DetailJamaahRombonganView(
//       {super.key, required this.id, required this.isLeader});

//   static Widget create(int id, bool isLeader) =>
//       ChangeNotifierProvider<ScrollListener>(
//           create: (context) => ScrollListener.initialise(ScrollController()),
//           child: DetailJamaahRombonganView(id: id, isLeader: isLeader));

//   final int id;
//   final bool isLeader;

//   @override
//   State<DetailJamaahRombonganView> createState() =>
//       _DetailJamaahRombonganViewState();
// }

// class _DetailJamaahRombonganViewState
//     extends BaseState<DetailJamaahRombonganView> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     loading(true);
//     context
//         .read<DetailJamaahProvider>()
//         .fetchDetailJamaah(widget.id, withLoading: true);
//     loading(false);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final listen = context.watch<ScrollListener>();
//     final detail =
//         context.watch<DetailJamaahProvider>().getJamaahDetailModel.data;

//     Future<void> _makePhoneCall(String url) async {
//       if (await canLaunch(url)) {
//         await launch(url);
//       } else {
//         throw 'Could not launch $url';
//       }
//     }

//     openWhatsApp() async {
//       String whatsapp = '${detail?.phone}';
//       String whatsappUrlAndroid = "https://wa.me/$whatsapp?text=Hello";
//       String whatsappUrlIOS =
//           "https://wa.me/$whatsapp?text=${Uri.parse("Hello")}";
//       if (Platform.isIOS) {
//         if (await canLaunchUrl(Uri.parse(whatsappUrlIOS))) {
//           await launchUrl(Uri.parse(whatsappUrlIOS));
//         } else {
//           throw 'WhatsApp tidak terinstall';
//         }
//       } else {
//         if (await canLaunchUrl(Uri.parse(whatsappUrlAndroid))) {
//           await launchUrl(Uri.parse(whatsappUrlAndroid));
//         } else {
//           throw 'WhatsApp tidak terinstall';
//         }
//       }
//     }

//     Widget header() {
//       return SafeArea(
//         child: Container(
//           margin: EdgeInsets.only(top: 10),
//           width: double.infinity,
//           child: AppBar(
//             elevation: 0,
//             backgroundColor: Colors.transparent,
//             foregroundColor: Colors.white,
//             automaticallyImplyLeading: true,
//             leading: InkWell(
//               onTap: () => Navigator.pop(context),
//               child: Icon(Icons.arrow_back),
//             ),
//             centerTitle: true,
//             title: Text(
//               'Jamaah',
//               style: Constant.primaryTextStyle
//                   .copyWith(fontSize: 18, color: Colors.white),
//             ),
//           ),
//         ),
//       );
//     }

//     Widget account() {
//       return CustomContainer.mainCard(
//         margin: EdgeInsets.symmetric(horizontal: 15),
//         isShadow: true,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Container(
//               margin: EdgeInsets.only(top: 4, bottom: 10),
//               child: Text(
//                 detail?.memberNo == null ||
//                         detail?.memberNo == "" ||
//                         detail?.memberNo == "-"
//                     ? "Member No : -"
//                     : '${detail?.memberNo}',
//                 style: Constant.primaryTextStyle,
//               ),
//             ),
//             Row(
//               children: [
//                 CircleAvatar(
//                   radius: 18,
//                   backgroundImage: NetworkImage('${detail?.photo}'),
//                 ),
//                 SizedBox(width: 10),
//                 Text(
//                   '${detail?.name}',
//                   maxLines: 1,
//                   style: Constant.primaryTextStyle
//                       .copyWith(fontSize: 18, fontWeight: Constant.semibold),
//                 )
//               ],
//             ),
//             SizedBox(height: 10),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               crossAxisAlignment: CrossAxisAlignment.end,
//               children: [
//                 Expanded(
//                   flex: 7,
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Container(
//                         width: 260,
//                         child: Row(
//                           children: [
//                             SizedBox(width: 8),
//                             Icon(Icons.email_outlined,
//                                 color: Constant.primaryColor, size: 18),
//                             SizedBox(width: 20),
//                             Container(
//                               // width: 160,
//                               child: Text(
//                                 detail?.email ?? "-",
//                                 maxLines: 1,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                             ),
//                             SizedBox(width: 6),
//                             (detail?.email ?? "") == ""
//                                 ? SizedBox()
//                                 : InkWell(
//                                     onTap: () {
//                                       String? email = detail?.email;
//                                       if (email != null || email != "") {
//                                         Clipboard.setData(new ClipboardData(
//                                             text: email ?? ""));

//                                         CustomAlert.showSnackBar(context,
//                                             "Email berhasil disalin", false,
//                                             color: Colors.black);
//                                       }
//                                     },
//                                     child: Container(
//                                       // padding: EdgeInsets.all(2),
//                                       // width: 46,
//                                       height: 18,
//                                       decoration: BoxDecoration(
//                                           // color: Constant.primaryColor,
//                                           borderRadius:
//                                               BorderRadius.circular(50)),
//                                       child: Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.start,
//                                         children: [
//                                           Icon(
//                                             Icons.copy_outlined,
//                                             color: Constant.primaryColor,
//                                             size: 14,
//                                           ),
//                                           SizedBox(width: 2),
//                                           // Text(
//                                           //   'salin',
//                                           //   style: Constant.primaryTextStyle
//                                           //       .copyWith(
//                                           //           color: Colors.white,
//                                           //           fontSize: 10),
//                                           // ),
//                                         ],
//                                       ),
//                                     ),
//                                   )
//                           ],
//                         ),
//                       ),
//                       SizedBox(height: 8),
//                       Row(
//                         children: [
//                           SizedBox(width: 8),
//                           Icon(
//                             Icons.phone_outlined,
//                             color: Constant.primaryColor,
//                             size: 18,
//                           ),
//                           SizedBox(
//                             width: 20,
//                           ),
//                           Text('${detail?.phone}'),
//                           SizedBox(
//                             width: 6,
//                           ),
//                           InkWell(
//                             onTap: () {
//                               String? phone = detail?.phone;
//                               if (phone != null || phone != "") {
//                                 Clipboard.setData(
//                                     new ClipboardData(text: phone ?? ""));

//                                 CustomAlert.showSnackBar(context,
//                                     "Nomor Telepon berhasil disalin", false,
//                                     color: Colors.black);
//                               }
//                             },
//                             child: Container(
//                               // padding: EdgeInsets.all(2),
//                               width: 46,
//                               height: 18,
//                               decoration: BoxDecoration(
//                                   // color: Constant.primaryColor,
//                                   borderRadius: BorderRadius.circular(50)),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.start,
//                                 children: [
//                                   Icon(
//                                     Icons.copy_outlined,
//                                     color: Constant.primaryColor,
//                                     size: 14,
//                                   ),
//                                   SizedBox(
//                                     width: 2,
//                                   ),
//                                   // Text(
//                                   //   'salin',
//                                   //   style: Constant.primaryTextStyle.copyWith(
//                                   //       color: Colors.white, fontSize: 10),
//                                   // ),
//                                 ],
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 8),
//                         child: Row(
//                           children: [
//                             SizedBox(width: 8),
//                             Icon(
//                               Icons.location_on_outlined,
//                               color: Constant.primaryColor,
//                               size: 18,
//                             ),
//                             SizedBox(width: 20),
//                             Text(detail?.cityName == null ||
//                                     detail?.cityName == ""
//                                 ? "-"
//                                 : '${detail?.cityName}')
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 8),
//                         child: Row(
//                           children: [
//                             SizedBox(width: 8),
//                             Icon(
//                               Icons.calendar_month_outlined,
//                               color: Constant.primaryColor,
//                               size: 18,
//                             ),
//                             SizedBox(width: 20),
//                             Text(detail?.birthDateDesc == null ||
//                                     detail?.birthDateDesc == ""
//                                 ? "-"
//                                 : '${detail?.birthDateDesc}')
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 8),
//                         child: Row(
//                           children: [
//                             SizedBox(width: 8),
//                             Icon(
//                               Icons.person_outline,
//                               color: Constant.primaryColor,
//                               size: 18,
//                             ),
//                             SizedBox(width: 20),
//                             Text(detail?.agenName == null ||
//                                     detail?.agenName == ""
//                                 ? "-"
//                                 : '${detail?.agenName}')
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 8),
//                         child: Row(
//                           children: [
//                             SizedBox(width: 8),
//                             Icon(
//                               Icons.groups_outlined,
//                               color: Constant.primaryColor,
//                               size: 18,
//                             ),
//                             SizedBox(width: 20),
//                             Text(detail?.isGroup == 1 || detail?.isGroup == 1
//                                 ? "Rombongan"
//                                 : "Individu")
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Expanded(
//                   flex: 2,
//                   child: Row(
//                     children: [
//                       InkWell(
//                         onTap: () {
//                           setState(() {
//                             _makePhoneCall('tel:${detail?.phone}');
//                           });
//                         },
//                         child: Container(
//                           padding: EdgeInsets.all(4),
//                           decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(80),
//                               color: Constant.primaryColor),
//                           child: Center(
//                             child: Icon(
//                               Icons.phone,
//                               color: Colors.white,
//                               size: 20,
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 10),
//                       InkWell(
//                         onTap: () {
//                           setState(() {
//                             openWhatsApp();
//                           });
//                         },
//                         child: Container(
//                           padding: EdgeInsets.all(6),
//                           decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(80),
//                               color: Constant.primaryColor),
//                           child: Center(
//                             child: Image.asset(
//                               'assets/icons/whatsapp.png',
//                               width: 18,
//                             ),
//                           ),
//                         ),
//                       )
//                     ],
//                   ),
//                 )
//               ],
//             ),
//           ],
//         ),
//       );
//     }

//     Widget bank() {
//       return Container(
//         margin: EdgeInsets.only(top: 10, left: 15, right: 15),
//         padding: EdgeInsets.only(top: 15, right: 15, left: 15),
//         width: double.infinity,
//         decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(14),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.grey.withOpacity(0.5),
//                 spreadRadius: 1,
//                 blurRadius: 2,
//               )
//             ]),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               'Virtual Account',
//               style: Constant.primaryTextStyle
//                   .copyWith(fontSize: 16, fontWeight: Constant.semibold),
//             ),
//             SizedBox(height: 18),
//             ListView.separated(
//               physics: NeverScrollableScrollPhysics(),
//               shrinkWrap: true,
//               padding: EdgeInsets.zero,
//               itemCount: detail?.va?.length ?? 0,
//               separatorBuilder: (_, __) => Padding(
//                 padding: EdgeInsets.symmetric(vertical: 4),
//                 child: Divider(thickness: 1, color: Colors.grey.shade200),
//               ),
//               itemBuilder: (context, index) {
//                 final itemVa = detail?.va?[index];
//                 return Column(
//                   mainAxisSize: MainAxisSize.min,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       children: [
//                         Icon(Icons.house_outlined, size: 18),
//                         SizedBox(width: 10),
//                         Text(
//                           itemVa?.vaBank == null || itemVa?.vaBank == ""
//                               ? "-"
//                               : '${itemVa?.vaBank}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 12),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 10),
//                     Row(
//                       children: [
//                         Icon(
//                           Icons.atm,
//                           size: 18,
//                         ),
//                         SizedBox(width: 10),
//                         Text(
//                           itemVa?.vaNumber == null || itemVa?.vaNumber == ""
//                               ? "-"
//                               : '${itemVa?.vaNumber}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 12),
//                         ),
//                         SizedBox(width: 10),
//                         (itemVa?.vaNumber ?? "") == ""
//                             ? SizedBox()
//                             : InkWell(
//                                 onTap: () {
//                                   String? vaNumber = itemVa?.vaNumber;
//                                   if (vaNumber != null || vaNumber != "") {
//                                     Clipboard.setData(new ClipboardData(
//                                         text: vaNumber ?? ""));
//                                     CustomAlert.showSnackBar(context,
//                                         "Nomor VA berhasil disalin", false,
//                                         color: Colors.black);
//                                   }
//                                 },
//                                 child: Container(
//                                   width: 46,
//                                   height: 18,
//                                   decoration: BoxDecoration(
//                                       // color: Constant.primaryColor,
//                                       borderRadius: BorderRadius.circular(50)),
//                                   child: Row(
//                                     mainAxisAlignment: MainAxisAlignment.start,
//                                     children: [
//                                       Icon(
//                                         Icons.copy_outlined,
//                                         color: Constant.primaryColor,
//                                         size: 14,
//                                       ),
//                                       SizedBox(width: 2),
//                                     ],
//                                   ),
//                                 ),
//                               ),
//                       ],
//                     ),
//                     SizedBox(height: 10),
//                     Row(
//                       children: [
//                         Icon(
//                           Icons.person_outline,
//                           size: 18,
//                         ),
//                         SizedBox(width: 10),
//                         Text(
//                           itemVa?.vaName == null || itemVa?.vaName == ""
//                               ? "-"
//                               : '${itemVa?.vaName}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 12),
//                         ),
//                         SizedBox(width: 10),
//                         (itemVa?.vaName ?? "") == ""
//                             ? SizedBox()
//                             : InkWell(
//                                 onTap: () {
//                                   String? vaName = itemVa?.vaName;
//                                   if (vaName != null || vaName != "") {
//                                     Clipboard.setData(
//                                         new ClipboardData(text: vaName ?? ""));
//                                     CustomAlert.showSnackBar(context,
//                                         "Nama VA berhasil disalin", false,
//                                         color: Colors.black);
//                                   }
//                                 },
//                                 child: Container(
//                                   width: 46,
//                                   height: 18,
//                                   decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(50)),
//                                   child: Row(
//                                     mainAxisAlignment: MainAxisAlignment.start,
//                                     children: [
//                                       Icon(
//                                         Icons.copy_outlined,
//                                         color: Constant.primaryColor,
//                                         size: 14,
//                                       ),
//                                       SizedBox(width: 2),
//                                     ],
//                                   ),
//                                 ),
//                               )
//                       ],
//                     ),
//                   ],
//                 );
//               },
//             ),
//             SizedBox(height: 18),
//           ],
//         ),
//       );
//     }

//     Widget tabungan() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         margin: EdgeInsets.only(top: 11, left: 15, right: 15),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               'Tabungan',
//               style: Constant.primaryTextStyle
//                   .copyWith(fontSize: 16, fontWeight: Constant.semibold),
//             ),
//             SizedBox(height: 18),
//             Row(
//               children: [
//                 Icon(
//                   Icons.attach_money_outlined,
//                   size: 18,
//                 ),
//                 SizedBox(width: 10),
//                 Text(
//                   (detail?.payment?.totalPaidDesc ?? "") == ""
//                       ? '-'
//                       : '${detail?.payment?.totalPaidDesc}',
//                   style: Constant.primaryTextStyle.copyWith(fontSize: 12),
//                 ),
//               ],
//             ),
//             SizedBox(height: 10),
//             Row(
//               children: [
//                 Icon(
//                   Icons.calendar_month_outlined,
//                   size: 18,
//                 ),
//                 SizedBox(width: 10),
//                 Text(
//                   (detail?.payment?.paymentDate ?? "") == ""
//                       ? '-'
//                       : '${detail?.payment?.paymentDate}',
//                   style: Constant.primaryTextStyle.copyWith(fontSize: 12),
//                 ),
//               ],
//             ),
//             SizedBox(height: 20),
//             // Center(
//             //     child: CustomButton.mainButton('Riwayat Tabungan', () {
//             //       Navigator.push(
//             //           context,
//             //           MaterialPageRoute(
//             //             builder: (context) =>
//             //                 RiwayatTabunganView.create(detail?.jamaahId ?? 0),
//             //           ));
//             //     }, stretched: false)),
//             SizedBox(height: 8),
//           ],
//         ),
//       );
//     }

//     Widget paket() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         margin: EdgeInsets.only(top: 13, left: 15, right: 15),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               'Paket',
//               style: Constant.primaryTextStyle
//                   .copyWith(fontSize: 16, fontWeight: Constant.semibold),
//             ),
//             (detail?.packageName ?? "") == ""
//                 ? Padding(
//                     padding: EdgeInsets.only(bottom: 8),
//                     child: Center(child: Text("Paket belum dipilih")),
//                   )
//                 : Padding(
//                     padding: const EdgeInsets.only(top: 18),
//                     child: Row(
//                       children: [
//                         Icon(
//                           Icons.airplane_ticket,
//                           size: 18,
//                         ),
//                         SizedBox(width: 10),
//                         Text(
//                           '${detail?.packageName}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 12),
//                         ),
//                       ],
//                     ),
//                   ),
//             // Padding(
//             //   padding: EdgeInsets.only(top: 8),
//             //   child: CustomButton.mainButton(
//             //     'Pilih Paket',
//             //         () {
//             //       Navigator.push(
//             //           context,
//             //           MaterialPageRoute(
//             //             builder: (context) => PilihPaketView(paketId: 1),
//             //           ));
//             //     },
//             //   ),
//             // ),
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: PreferredSize(
//           child: AnimatedBuilder(
//               animation: listen,
//               builder: (context, child) {
//                 if (listen.showAppbar) {
//                   return Container(
//                     color: Constant.primaryColor,
//                     child: CustomAppBar.appBar("Detail Jamaah",
//                         color: Colors.black, isLeading: true, isCenter: true),
//                   );
//                 }
//                 return AppBar(
//                   elevation: 0,
//                   backgroundColor: Colors.transparent,
//                   foregroundColor: Colors.transparent,
//                   automaticallyImplyLeading: true,
//                   title: Container(),
//                 );
//               }),
//           preferredSize: Size.fromHeight(56)),
//       body: Container(
//         child: RefreshIndicator(
//           color: Constant.primaryColor,
//           onRefresh: () async {
//             await context
//                 .read<DetailJamaahProvider>()
//                 .fetchDetailJamaah(widget.id, withLoading: true);
//           },
//           child: ListView(
//             padding: EdgeInsets.only(top: 0),
//             controller: listen.scrollController,
//             children: [
//               SizedBox(height: 24),
//               Container(
//                 height: 342,
//                 child: Stack(
//                   children: [
//                     Container(
//                       width: 100.w,
//                       height: 171,
//                       decoration: BoxDecoration(
//                           image: DecorationImage(
//                               image: AssetImage('assets/images/BG login.png'),
//                               fit: BoxFit.fitWidth)),
//                     ),
//                     Positioned(top: -80, left: 0, right: 0, child: header()),
//                     Positioned(top: 82, left: 0, right: 0, child: account())
//                   ],
//                 ),
//               ),
//               bank(),
//               tabungan(),
//               paket(),
//               // Container(
//               //   margin: EdgeInsets.only(top: 20, left: 30, right: 30),
//               //   child: CustomButton.mainButton('Dokumen Jamaah', () {}),
//               // ),
//               (detail?.lobcPath ?? "") == ""
//                   ? SizedBox()
//                   : Container(
//                       margin: EdgeInsets.only(top: 12, left: 30, right: 30),
//                       child: CustomButton.mainButton(
//                           'Letter of Booking Confirmation (LOBC)',
//                           color: Colors.black, () {
//                         launch('${detail?.lobcPath}');
//                       }),
//                     ),
//               // Container(
//               //   margin: EdgeInsets.only(top: 44, left: 30, right: 30),
//               //   child: CustomButton.secondaryButton('Dokumen Rombongan', () {
//               //     Navigator.push(
//               //         context,
//               //         MaterialPageRoute(
//               //           builder: (context) =>
//               //               JamaahRombonganView.create(detail?.bookingId ?? 0),
//               //         ));
//               //   }),
//               // ),
//               SizedBox(height: 16),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
