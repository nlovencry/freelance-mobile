// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_rombongan_provider.dart';
// import 'package:chatour/src/jamaah/view/detail_jamaah_rombongan_view.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../../common/helper/safe_network_image.dart';
// import '../../../common/helper/scroll_listener.dart';

// class JamaahRombonganView extends StatefulWidget {
//   const JamaahRombonganView({super.key, required this.id});

//   static Widget create(int id) => ChangeNotifierProvider<ScrollListener>(
//       create: (context) => ScrollListener.initialise(ScrollController()),
//       child: JamaahRombonganView(id: id));

//   final int id;

//   @override
//   State<JamaahRombonganView> createState() => _JamaahRombonganViewState();
// }

// class _JamaahRombonganViewState extends State<JamaahRombonganView> {
//   @override
//   void initState() {
//     context.read<JamaahRombonganProvider>().fetchJamaahRombongan(widget.id);
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final listen = context.watch<ScrollListener>();
//     final rombongan =
//         context.watch<JamaahRombonganProvider>().jamaahRombonganModel.message;
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Daftar Jamaah Rombongan',
//         color: Colors.black,
//         isLeading: true,
//         isCenter: true,
//         // flexibleSpace: Container(
//         //   decoration: BoxDecoration(
//         //     gradient: LinearGradient(
//         //       begin: Alignment.topLeft,
//         //       end: Alignment.bottomRight,
//         //       colors: <Color>[Constant.primaryColor, Colors.black],
//         //     ),
//         //   ),
//         // ),
//       );
//     }

//     Widget paketUmrohList() {
//       return ListView.separated(
//         shrinkWrap: true,
//         itemCount: rombongan?.length ?? 0,
//         separatorBuilder: (context, index) => SizedBox(),
//         itemBuilder: (context, index) {
//           final jamaah = rombongan?[index];
//           return GestureDetector(
//             onTap: () {
//               Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                       builder: (context) => DetailJamaahRombonganView.create(
//                           rombongan?[index]?.jamaahId ?? 0,
//                           jamaah?.isLeader ?? false)));
//             },
//             child: CustomContainer.mainCard(
//               isShadow: true,
//               margin: EdgeInsets.only(top: 10, left: 12, right: 12),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Row(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Expanded(
//                         flex: 2,
//                         child: SafeNetworkImage.circle(
//                           url: jamaah?.photo ?? "-",
//                           radius: 52,
//                           errorBuilder: CircleAvatar(
//                             radius: 26,
//                             backgroundImage:
//                                 AssetImage('assets/images/avatar.png'),
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 12),
//                       Expanded(
//                         flex: 5,
//                         child: Column(
//                           mainAxisSize: MainAxisSize.min,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Text('${jamaah?.memberNo ?? "-"}',
//                                 style: Constant.primaryTextStyle),
//                             Text(
//                               '${jamaah?.name ?? "-"}',
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontWeight: Constant.semibold),
//                             ),
//                             Row(
//                               mainAxisSize: MainAxisSize.min,
//                               children: [
//                                 Expanded(
//                                     flex: 2,
//                                     child: Image.asset('assets/icons/koin.png',
//                                         width: 18)),
//                                 SizedBox(width: 4),
//                                 Expanded(
//                                   flex: 9,
//                                   child: Text(
//                                     jamaah?.totalPaidDesc ?? "Rp 0",
//                                     maxLines: 1,
//                                     overflow: TextOverflow.ellipsis,
//                                     style: Constant.primaryTextStyle.copyWith(
//                                         color: Constant.textPriceColor,
//                                         fontSize: 12),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                       SizedBox(width: 8),
//                       Expanded(
//                         flex: 5,
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           crossAxisAlignment: CrossAxisAlignment.end,
//                           children: [
//                             Row(
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 (jamaah?.isLeader ?? false)
//                                     ? Icon(Icons.star_rate_rounded)
//                                     : SizedBox(),
//                                 Flexible(
//                                   child: Text(
//                                     '${(jamaah?.isLeader ?? false) ? "Team Leader" : ""}',
//                                     overflow: TextOverflow.ellipsis,
//                                     maxLines: 2,
//                                     textAlign: TextAlign.right,
//                                     style: Constant.primaryTextStyle.copyWith(
//                                         fontWeight: Constant.semibold),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 16),
//                             Row(
//                               crossAxisAlignment: CrossAxisAlignment.end,
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 Image.asset('assets/icons/calendar.png',
//                                     width: 18),
//                                 SizedBox(width: 4),
//                                 Flexible(
//                                   child: Text(
//                                     '${jamaah?.nik ?? "-"}',
//                                     overflow: TextOverflow.ellipsis,
//                                     maxLines: 1,
//                                     textAlign: TextAlign.right,
//                                     style: Constant.primaryTextStyle,
//                                   ),
//                                 )
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           );
//           // CustomContainer.mainCard(
//           //   isShadow: true,
//           //   margin: EdgeInsets.only(top: 8, left: 10, right: 10),
//           //   child: Column(
//           //     crossAxisAlignment: CrossAxisAlignment.stretch,
//           //     mainAxisSize: MainAxisSize.min,
//           //     children: [
//           //       Row(
//           //         crossAxisAlignment: CrossAxisAlignment.start,
//           //         children: [
//           //           Expanded(
//           //             flex: 2,
//           //             child: CircleAvatar(
//           //               radius: 26,
//           //               backgroundImage:
//           //                   AssetImage('assets/images/avatar.png'),
//           //             ),
//           //           ),
//           //           SizedBox(width: 12),
//           //           Expanded(
//           //             flex: 5,
//           //             child: Column(
//           //               mainAxisSize: MainAxisSize.min,
//           //               crossAxisAlignment: CrossAxisAlignment.start,
//           //               children: [
//           //                 Text('${jamaah?.memberNo ?? "null"}',
//           //                     style: Constant.primaryTextStyle),
//           //                 SizedBox(height: 5),
//           //                 Text(
//           //                   '${jamaah?.userName}',
//           //                   // maxLines: 1,
//           //                   // overflow: TextOverflow.ellipsis,
//           //                   style: Constant.primaryTextStyle
//           //                       .copyWith(fontWeight: Constant.semibold),
//           //                 ),
//           //                 SizedBox(height: 5),
//           //                 Row(
//           //                   mainAxisSize: MainAxisSize.min,
//           //                   children: [
//           //                     Expanded(
//           //                         flex: 2,
//           //                         child: Image.asset('assets/icons/koin.png',
//           //                             width: 18)),
//           //                     SizedBox(width: 4),
//           //                     Expanded(
//           //                       flex: 9,
//           //                       child: Text(
//           //                         'Rp. ${jamaah?.totalPaid}',
//           //                         maxLines: 1,
//           //                         overflow: TextOverflow.ellipsis,
//           //                         style: Constant.primaryTextStyle.copyWith(
//           //                             color: Constant.textPriceColor,
//           //                             fontSize: 12),
//           //                       ),
//           //                     ),
//           //                   ],
//           //                 ),
//           //               ],
//           //             ),
//           //           ),
//           //           Expanded(
//           //             flex: 5,
//           //             child: Column(
//           //               mainAxisAlignment: MainAxisAlignment.start,
//           //               crossAxisAlignment: CrossAxisAlignment.end,
//           //               children: [
//           //                 Row(
//           //                   crossAxisAlignment: CrossAxisAlignment.center,
//           //                   mainAxisAlignment: MainAxisAlignment.end,
//           //                   children: [
//           //                     Flexible(
//           //                       child: Text(
//           //                         '${jamaah?.userCity}',
//           //                         overflow: TextOverflow.ellipsis,
//           //                         maxLines: 2,
//           //                         textAlign: TextAlign.right,
//           //                         style: Constant.primaryTextStyle
//           //                             .copyWith(fontWeight: Constant.semibold),
//           //                       ),
//           //                     ),
//           //                   ],
//           //                 ),
//           //                 SizedBox(height: 16),
//           //                 Row(
//           //                   crossAxisAlignment: CrossAxisAlignment.end,
//           //                   mainAxisAlignment: MainAxisAlignment.end,
//           //                   children: [
//           //                     Flexible(
//           //                       child: Text(
//           //                         '${jamaah?.isLeader ?? ""}',
//           //                         overflow: TextOverflow.ellipsis,
//           //                         maxLines: 1,
//           //                         textAlign: TextAlign.right,
//           //                         style: Constant.primaryTextStyle,
//           //                       ),
//           //                     )
//           //                   ],
//           //                 ),
//           //               ],
//           //             ),
//           //           ),
//           //         ],
//           //       ),
//           //     ],
//           //   ),
//           // );
//         },
//       );
//     }

//     return Scaffold(
//       appBar: header(),
//       body: ListView(
//         shrinkWrap: true,
//         controller: listen.scrollController,
//         children: [paketUmrohList()],
//       ),
//     );
//   }
// }
