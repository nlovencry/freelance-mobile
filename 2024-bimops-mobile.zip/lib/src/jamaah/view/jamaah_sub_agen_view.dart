// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/model/jamaah_list_sub_agen_model.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:chatour/src/jamaah/view/detail_jamaah_view.dart';
// import 'package:flutter/material.dart';
// import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
// import 'package:intl/intl.dart';
// import 'package:provider/provider.dart';

// import '../../../common/component/custom_loading_indicator.dart';
// import '../../../common/helper/safe_network_image.dart';
// import '../../../utils/utils.dart';

// class JamaahSubAgenView extends StatefulWidget {
//   const JamaahSubAgenView(
//       {super.key, required this.subAgenid, required this.subAgenName});

//   static String thousandSeparator(int val) {
//     return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
//         .format(val);
//   }

//   final int subAgenid;
//   final String subAgenName;

//   @override
//   State<JamaahSubAgenView> createState() => _JamaahSubAgenViewState();
// }

// class _JamaahSubAgenViewState extends BaseState<JamaahSubAgenView> {
//   @override
//   void initState() {
//     final jP = context.read<JamaahProvider>();
//     jP.subAgenId = widget.subAgenid;
//     jP.pagingControllerSubAgen.addPageRequestListener(
//         (pageKey) => jP.fetchJamaahSubAgen(page: pageKey));
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final pagingC = context.watch<JamaahProvider>().pagingControllerSubAgen;
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Data Jamaah ${widget.subAgenName}',
//         color: Colors.black,
//         action: [
//           Padding(
//             padding: const EdgeInsets.only(right: 8),
//             child: ImageIcon(AssetImage('assets/icons/filter 2.png')),
//           )
//         ],
//         isLeading: true,
//         isCenter: true,
//         // flexibleSpace: Container(
//         //   decoration: BoxDecoration(
//         //     gradient: LinearGradient(
//         //       begin: Alignment.topLeft,
//         //       end: Alignment.bottomRight,
//         //       colors: <Color>[Constant.primaryColor, Colors.black],
//         //     ),
//         //   ),
//         // ),
//       );
//     }

//     Widget cardJamaah() {
//       return PagedListView(
//         shrinkWrap: true,
//         padding: EdgeInsets.only(bottom: 24),
//         pagingController: pagingC,
//         builderDelegate: PagedChildBuilderDelegate<JamaahListSubAgenModelData>(
//           firstPageProgressIndicatorBuilder: (_) => Container(
//             color: Colors.white,
//             padding: EdgeInsets.only(top: 32),
//             child: CustomLoadingIndicator.buildIndicator(),
//           ),
//           newPageProgressIndicatorBuilder: (_) => Container(
//             color: Colors.white,
//             child: CustomLoadingIndicator.buildIndicator(),
//           ),
//           noItemsFoundIndicatorBuilder: (_) => Padding(
//             padding: const EdgeInsets.only(top: 56),
//             child: Utils.notFoundImage(),
//           ),
//           itemBuilder: (context, item, index) {
//             final jamaah1 = item;
//             return GestureDetector(
//               onTap: () {
//                 Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                         builder: (context) =>
//                             DetailJamaah.create(jamaah1.id ?? 0)));
//               },
//               child: CustomContainer.mainCard(
//                 isShadow: true,
//                 margin: EdgeInsets.only(top: 10, left: 12, right: 12),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.stretch,
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Row(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Expanded(
//                           flex: 2,
//                           child: CircleAvatar(
//                             radius: 26,
//                             backgroundImage:
//                                 AssetImage('assets/images/avatar.png'),
//                           ),
//                         ),
//                         SizedBox(width: 12),
//                         Expanded(
//                           flex: 6,
//                           child: Column(
//                             mainAxisSize: MainAxisSize.min,
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text('${jamaah1.memberNo}',
//                                   style: Constant.primaryTextStyle
//                                       .copyWith(fontSize: 12)),
//                               SizedBox(
//                                 height: 2,
//                               ),
//                               Text(
//                                 '${jamaah1.userName}',
//                                 maxLines: 1,
//                                 overflow: TextOverflow.ellipsis,
//                                 style: Constant.primaryTextStyle.copyWith(
//                                     fontWeight: Constant.semibold,
//                                     fontSize: 16),
//                               ),
//                               SizedBox(
//                                 height: 2,
//                               ),
//                               Row(
//                                 mainAxisSize: MainAxisSize.min,
//                                 children: [
//                                   Expanded(
//                                       flex: 2,
//                                       child: Image.asset(
//                                           'assets/icons/koin.png',
//                                           width: 18)),
//                                   SizedBox(width: 4),
//                                   Expanded(
//                                     flex: 9,
//                                     child: Text(
//                                       'Rp. ${JamaahSubAgenView.thousandSeparator(jamaah1.savings ?? 0)}',
//                                       maxLines: 1,
//                                       overflow: TextOverflow.ellipsis,
//                                       style: Constant.primaryTextStyle.copyWith(
//                                           color: Constant.textPriceColor,
//                                           fontSize: 12),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         Expanded(
//                           flex: 6,
//                           child: Column(
//                             mainAxisAlignment: MainAxisAlignment.start,
//                             crossAxisAlignment: CrossAxisAlignment.end,
//                             children: [
//                               Row(
//                                 crossAxisAlignment: CrossAxisAlignment.end,
//                                 mainAxisAlignment: MainAxisAlignment.end,
//                                 children: [
//                                   Image.asset('assets/icons/calendar.png',
//                                       width: 16),
//                                   SizedBox(width: 4),
//                                   Flexible(
//                                     child: Text(
//                                       '${jamaah1.createdAt}',
//                                       overflow: TextOverflow.ellipsis,
//                                       maxLines: 1,
//                                       textAlign: TextAlign.right,
//                                       style: Constant.primaryTextStyle
//                                           .copyWith(fontSize: 12),
//                                     ),
//                                   )
//                                 ],
//                               ),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         ),
//       );
//     }

//     return Scaffold(
//       // backgroundColor: Constant.primaryColor,
//       appBar: header(),
//       resizeToAvoidBottomInset: true,
//       body: RefreshIndicator(
//         color: Constant.primaryColor,
//         onRefresh: () async => pagingC.refresh(),
//         child: cardJamaah(),
//       ),
//     );
//   }
// }
