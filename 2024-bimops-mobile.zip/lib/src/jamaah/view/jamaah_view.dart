// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/component/custom_textfield.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/common/helper/safe_network_image.dart';
// import 'package:chatour/src/jamaah/model/jamaah_list_model.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:chatour/src/jamaah/view/detail_jamaah_view.dart';
// import 'package:chatour/utils/Utils.dart';
// import 'package:flutter/material.dart';
// import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
// import 'package:intl/intl.dart';
// import 'package:provider/provider.dart';

// import '../../../common/component/custom_loading_indicator.dart';

// class JamaahView extends StatefulWidget {
//   static String thousandSeparator(int val) {
//     return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
//         .format(val);
//   }

//   @override
//   State<JamaahView> createState() => _JamaahViewState();
// }

// class _JamaahViewState extends BaseState<JamaahView> {
//   @override
//   void initState() {
//     final jP = context.read<JamaahProvider>();
//     jP.pagingController = PagingController(firstPageKey: 1)
//       ..addPageRequestListener((pageKey) => jP.fetchJamaah(page: pageKey));
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final jamaah = context.watch<JamaahProvider>();
//     final pagingC = context.watch<JamaahProvider>().pagingController;
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Data Jamaah',
//         color: Colors.black,
//         action: [
//           Padding(
//             padding: const EdgeInsets.only(right: 8),
//             child: GestureDetector(
//               onTap: () async {
//                 await CustomContainer.showModalBottom2(
//                   context: context,
//                   child: StatefulBuilder(
//                     builder: (context, state) {
//                       final search = context.watch<JamaahProvider>();
//                       // final reguler2 = context.watch<PaketProvider>().isReguler;
//                       // final promo2 = context.watch<PaketProvider>().isPromo;
//                       return Container(
//                         margin: EdgeInsets.only(top: 8, left: 12, right: 12),
//                         child: Column(
//                           mainAxisSize: MainAxisSize.min,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Text(
//                               'Masukkan Nama',
//                               style: Constant.primaryTextStyle.copyWith(
//                                   fontWeight: Constant.semibold, fontSize: 18),
//                             ),
//                             SizedBox(height: 5),
//                             Container(
//                               padding: EdgeInsets.symmetric(horizontal: 10),
//                               height: 50,
//                               width: double.infinity,
//                               decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(14),
//                                   border: Border.all(color: Colors.black)),
//                               child: TextFormField(
//                                 controller: jamaah.searchC,
//                                 decoration:
//                                     InputDecoration(border: InputBorder.none),
//                               ),
//                             ),
//                             SizedBox(height: 16),
//                             Row(
//                               crossAxisAlignment: CrossAxisAlignment.end,
//                               children: [
//                                 CustomButton.secondaryButton(
//                                   'Bersihkan Filter',
//                                   () async {
//                                     loading(true);
//                                     jamaah.searchC.clear();
//                                     pagingC.refresh();
//                                     loading(false);
//                                     Navigator.pop(context);
//                                   },
//                                 ),
//                                 SizedBox(width: 5),
//                                 Expanded(
//                                   child: CustomButton.mainButton(
//                                     'Filter',
//                                     () async {
//                                       loading(true);
//                                       pagingC.refresh();
//                                       loading(false);
//                                       Navigator.pop(context);
//                                     },
//                                     stretched: true,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             // SizedBox(height: 10),
//                           ],
//                         ),
//                       );
//                     },
//                   ),
//                 );
//               },
//               child: ImageIcon(AssetImage('assets/icons/filter 2.png')),
//             ),
//           )
//         ],
//         isLeading: false,
//         isCenter: true,
//         // flexibleSpace: Container(
//         //   decoration: BoxDecoration(
//         //     gradient: LinearGradient(
//         //       begin: Alignment.topLeft,
//         //       end: Alignment.bottomRight,
//         //       colors: <Color>[Constant.primaryColor, Colors.black],
//         //     ),
//         //   ),
//         // ),
//       );
//     }

//     Widget cardJamaah() {
//       return PagedListView(
//           shrinkWrap: true,
//           padding: EdgeInsets.only(bottom: 24),
//           pagingController: pagingC,
//           builderDelegate: PagedChildBuilderDelegate<JamaahListModelData>(
//             firstPageProgressIndicatorBuilder: (_) => Container(
//               color: Colors.white,
//               padding: EdgeInsets.only(top: 32),
//               child: CustomLoadingIndicator.buildIndicator(),
//             ),
//             newPageProgressIndicatorBuilder: (_) => Container(
//               color: Colors.white,
//               child: CustomLoadingIndicator.buildIndicator(),
//             ),
//             noItemsFoundIndicatorBuilder: (_) => Padding(
//               padding: const EdgeInsets.only(top: 56),
//               child: Utils.notFoundImage(),
//             ),
//             itemBuilder: (context, item, index) {
//               final jamaah1 = item;
//               return GestureDetector(
//                 onTap: () {
//                   Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) =>
//                               DetailJamaah.create(jamaah1.id ?? 0)));
//                 },
//                 child: Container(
//                     // height: 84,
//                     width: double.infinity,
//                     margin: EdgeInsets.only(left: 20, right: 20, top: 10),
//                     padding: EdgeInsets.only(
//                         left: 14, right: 14, top: 12, bottom: 12),
//                     decoration: BoxDecoration(
//                         border: Border.all(color: Colors.grey, width: 0.5),
//                         borderRadius: BorderRadius.circular(14)),
//                     child: Row(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Container(
//                           height: 40,
//                           width: 40,
//                           decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(8),
//                           ),
//                           child: SafeNetworkImage(
//                             width: 40,
//                             height: 40,
//                             borderRadius: 10,
//                             url: jamaah1.photoPath ?? "",
//                             errorBuilder: Container(
//                               width: 40,
//                               height: 40,
//                               decoration: BoxDecoration(
//                                 color: Colors.grey,
//                                 borderRadius: BorderRadius.circular(8),
//                               ),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           width: 12,
//                         ),
//                         Expanded(
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text(
//                                 '${jamaah1.userName}'.toUpperCase(),
//                                 style: Constant.primaryTextStyle.copyWith(
//                                   fontWeight: Constant.bold,
//                                 ),
//                               ),
//                               Divider(
//                                 thickness: 0.4,
//                                 color: Colors.grey,
//                               ),
//                               // SizedBox(
//                               //   height: 2,
//                               // ),
//                               Row(
//                                 mainAxisAlignment: MainAxisAlignment.start,
//                                 children: [
//                                   Expanded(
//                                     flex: 6,
//                                     child: Container(
//                                       child: Text(
//                                         '${jamaah1.memberNo}',
//                                         style: Constant.primaryTextStyle
//                                             .copyWith(fontSize: 12),
//                                       ),
//                                     ),
//                                   ),
//                                   jamaah1.agenName == null ||
//                                           jamaah1.agenName == ""
//                                       ? SizedBox(width: 10)
//                                       : Expanded(
//                                           flex: 6,
//                                           child: Row(
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.end,
//                                             children: [
//                                               Flexible(
//                                                 flex: 2,
//                                                 child: Image.asset(
//                                                   'assets/icons/userr.png',
//                                                   width: 13,
//                                                 ),
//                                               ),
//                                               SizedBox(width: 4),
//                                               Flexible(
//                                                 flex: 8,
//                                                 child: Text(
//                                                   '${jamaah1.agenName}',
//                                                   maxLines: 2,
//                                                   overflow:
//                                                       TextOverflow.ellipsis,
//                                                   textAlign: TextAlign.start,
//                                                   style: Constant
//                                                       .primaryTextStyle
//                                                       .copyWith(
//                                                           // fontWeight: Constant.bold,
//                                                           fontSize: 12),
//                                                 ),
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                 ],
//                               ),
//                               SizedBox(
//                                 height: 6,
//                               ),
//                               Row(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Row(
//                                     mainAxisAlignment: MainAxisAlignment.start,
//                                     children: [
//                                       Image.asset(
//                                         'assets/icons/money.png',
//                                         width: 15,
//                                       ),
//                                       SizedBox(
//                                         width: 8,
//                                       ),
//                                       Text(
//                                         Utils.thousandSeparator(
//                                             jamaah1.savings ?? 0),
//                                         style: Constant.primaryTextStyle
//                                             .copyWith(
//                                                 fontWeight: Constant.bold,
//                                                 fontSize: 12),
//                                       ),
//                                     ],
//                                   ),
//                                   Row(
//                                     mainAxisAlignment: MainAxisAlignment.end,
//                                     children: [
//                                       Image.asset(
//                                         'assets/icons/calendar.png',
//                                         width: 12,
//                                       ),
//                                       SizedBox(
//                                         width: 8,
//                                       ),
//                                       Text(
//                                         '${jamaah1.createdAt}',
//                                         style:
//                                             Constant.primaryTextStyle.copyWith(
//                                                 // fontWeight: Constant.bold,
//                                                 fontSize: 12),
//                                       ),
//                                     ],
//                                   ),
//                                 ],
//                               )
//                             ],
//                           ),
//                         )
//                       ],
//                     )),
//               );
//             },
//           ));
//       // return ListView.builder(
//       //   shrinkWrap: true,
//       //   physics: NeverScrollableScrollPhysics(),
//       //   itemCount: jamaah.getJamaahListModel.data?.length,
//       //   itemBuilder: (context, index) {
//       //     final jamaah1 = jamaah.getJamaahListModel.data?[index];
//       //   },
//       // );
//     }

//     // Widget cardJamaah() {
//     //   return ListView.builder(
//     //     shrinkWrap: true,
//     //     physics: NeverScrollableScrollPhysics(),
//     //     itemCount: jamaah.getJamaahListModel.data?.length,
//     //     itemBuilder: (context, index) {
//     //       final jamaah1 = jamaah.getJamaahListModel.data?[index];
//     //       return GestureDetector(
//     //         onTap: () {
//     //           Navigator.push(
//     //               context,
//     //               MaterialPageRoute(
//     //                   builder: (context) =>
//     //                       DetailJamaah.create(jamaah1.id ?? 0)));
//     //         },
//     //         child: CustomContainer.mainCard(
//     //           isShadow: true,
//     //           margin: EdgeInsets.only(top: 10, left: 12, right: 12),
//     //           child: Row(
//     //             crossAxisAlignment: CrossAxisAlignment.start,
//     //             children: [
//     //               Expanded(
//     //                 flex: 2,
//     //                 child: CircleAvatar(
//     //                   radius: 26,
//     //                   backgroundImage: AssetImage('assets/images/avatar.png'),
//     //                 ),
//     //               ),
//     //               SizedBox(width: 12),
//     //               Expanded(
//     //                 flex: 5,
//     //                 child: Column(
//     //                   mainAxisSize: MainAxisSize.min,
//     //                   crossAxisAlignment: CrossAxisAlignment.start,
//     //                   children: [
//     //                     Text('${jamaah1.memberNo}',
//     //                         style: Constant.primaryTextStyle
//     //                             .copyWith(fontSize: 12)),
//     //                     Text(
//     //                       '${jamaah1.userName}',
//     //                       maxLines: 1,
//     //                       overflow: TextOverflow.ellipsis,
//     //                       style: Constant.primaryTextStyle.copyWith(
//     //                           fontWeight: Constant.semibold, fontSize: 16),
//     //                     ),
//     //                     SizedBox(
//     //                       height: 2,
//     //                     ),
//     //                     Row(
//     //                       mainAxisSize: MainAxisSize.min,
//     //                       children: [
//     //                         Expanded(
//     //                             flex: 2,
//     //                             child: Image.asset('assets/icons/koin.png',
//     //                                 width: 18)),
//     //                         SizedBox(width: 4),
//     //                         Expanded(
//     //                           flex: 9,
//     //                           child: Text(
//     //                             'Rp. ${thousandSeparator(jamaah1.savings ?? 0)}',
//     //                             maxLines: 1,
//     //                             overflow: TextOverflow.ellipsis,
//     //                             style: Constant.primaryTextStyle.copyWith(
//     //                                 color: Constant.textPriceColor,
//     //                                 fontSize: 12),
//     //                           ),
//     //                         ),
//     //                       ],
//     //                     ),
//     //                   ],
//     //                 ),
//     //               ),
//     //               // SizedBox(width: 8),
//     //               Expanded(
//     //                 flex: 6,
//     //                 child: Column(
//     //                   mainAxisAlignment: MainAxisAlignment.start,
//     //                   crossAxisAlignment: CrossAxisAlignment.end,
//     //                   children: [
//     //                     jamaah1.agenName == null || jamaah1.agenName == ""
//     //                         ? SizedBox(height: 20)
//     //                         : Row(
//     //                             crossAxisAlignment: CrossAxisAlignment.start,
//     //                             mainAxisAlignment: MainAxisAlignment.end,
//     //                             children: [
//     //                               Flexible(
//     //                                 child: Image.asset(
//     //                                     'assets/icons/Agen hitam.png',
//     //                                     width: 20),
//     //                               ),
//     //                               Flexible(
//     //                                 child: Text(
//     //                                   '${jamaah1.agenName}',
//     //                                   overflow: TextOverflow.ellipsis,
//     //                                   maxLines: 1,
//     //                                   textAlign: TextAlign.right,
//     //                                   style: Constant.primaryTextStyle.copyWith(
//     //                                       fontWeight: Constant.semibold,
//     //                                       fontSize: 12),
//     //                                 ),
//     //                               ),
//     //                             ],
//     //                           ),
//     //                     SizedBox(height: 22),
//     //                     Row(
//     //                       crossAxisAlignment: CrossAxisAlignment.end,
//     //                       mainAxisAlignment: MainAxisAlignment.end,
//     //                       children: [
//     //                         Image.asset('assets/icons/calendar.png', width: 16),
//     //                         SizedBox(width: 4),
//     //                         Flexible(
//     //                           child: Text(
//     //                             '${jamaah1.createdAt}',
//     //                             overflow: TextOverflow.ellipsis,
//     //                             maxLines: 1,
//     //                             textAlign: TextAlign.right,
//     //                             style: Constant.primaryTextStyle
//     //                                 .copyWith(fontSize: 12),
//     //                           ),
//     //                         )
//     //                       ],
//     //                     ),
//     //                   ],
//     //                 ),
//     //               ),
//     //             ],
//     //           ),
//     //         ),
//     //       );
//     //     },
//     //   );
//     // }

//     return Scaffold(
//       // backgroundColor: Constant.primaryColor,
//       appBar: header(),
//       resizeToAvoidBottomInset: true,
//       body: RefreshIndicator(
//         color: Constant.primaryColor,
//         // onRefresh: () async {},
//         onRefresh: () async => pagingC.refresh(),
//         child: cardJamaah(),
//       ),
//     );
//   }
// }
