// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/provider/detail_jamaah_provider.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:chatour/src/paket/model/paket_detail_model.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// import '../../../common/base/base_state.dart';
// import '../../../common/component/custom_container.dart';
// import '../../../utils/utils.dart';
// import '../../paket/provider/paket_provider.dart';
// import '../../profil/provider/profile_provider.dart';

// class KonfirmasiPaketView extends StatefulWidget {
//   final String paketId;
//   final PaketDetailModel paketDetailModel;

//   const KonfirmasiPaketView(
//       {super.key, required this.paketId, required this.paketDetailModel});
//   @override
//   State<KonfirmasiPaketView> createState() => _KonfirmasiPaketViewState();
// }

// class _KonfirmasiPaketViewState extends BaseState<KonfirmasiPaketView> {
//   // String? selectedKota;

//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     // await context.read<JamaahProvider>().fetchJamaah(withLoading: true);
//     // await context.read<JamaahProvider>().fetchReviewApprovalJenisPaket(
//     // "${widget.paketId}", "${widget.bookingId}", "${widget.jamaahId}",
//     // withLoading: true);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final detailP = context.watch<PaketProvider>().paketDetailModel.data;
//     FocusManager.instance.primaryFocus?.unfocus();
//     final profileP = context.watch<ProfileProvider>().profileModel.data;
//     final jamaahP = context.watch<JamaahProvider>();
//     final detailJamaahP =
//         context.watch<DetailJamaahProvider>().jamaahDetailModel.data;
//     final paketP = context.watch<PaketProvider>();
//     final paketDetailModel =
//         context.watch<PaketProvider>().paketDetailModel.data;
//     // final paketDetailModel =
//     //     context.watch<JamaahProvider>().paketApprovalReviewModel.data;

//     // Widget textField({
//     //   required TextEditingController controller,
//     //   Widget? suffixIcon,
//     //   String? hintText,
//     //   bool ReadOnly = false,
//     //   Function()? onTap,
//     // }) {
//     //   return Column(
//     //     children: [
//     //       SizedBox(height: 6),
//     //       TextFormField(
//     //         cursorColor: Constant.primaryColor,
//     //         controller: controller,
//     //         style: Constant.primaryTextStyle,
//     //         readOnly: ReadOnly,
//     //         decoration: InputDecoration(
//     //           isDense: true,
//     //           contentPadding: EdgeInsets.fromLTRB(14, 14, 14, 14),
//     //           hintText: hintText ?? "",
//     //           suffixIcon: Padding(
//     //             padding: const EdgeInsets.only(right: 10),
//     //             child: suffixIcon,
//     //           ),
//     //           suffixIconConstraints:
//     //               BoxConstraints(maxHeight: 30, maxWidth: 30),
//     //           border: OutlineInputBorder(
//     //               borderSide: BorderSide.none,
//     //               borderRadius: BorderRadius.circular(10)),
//     //           filled: true,
//     //           fillColor: Colors.grey.shade200,
//     //         ),
//     //       ),
//     //       SizedBox(
//     //         height: 10,
//     //       )
//     //     ],
//     //   );
//     // }

//     Widget konfirmasiPaket() {
//       final dateDeparture = jamaahP.getTanggalUmrohNameV ?? "-";
//       return CustomContainer.mainCard(
//         isShadow: true,
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               '${paketDetailModel?.name ?? "-"}',
//               style: Constant.primaryTextStyle
//                   .copyWith(fontWeight: Constant.semibold),
//             ),
//             SizedBox(height: 6),
//             Text(
//               dateDeparture,
//               style: Constant.primaryTextStyle
//                   .copyWith(fontWeight: Constant.semibold),
//             ),
//             SizedBox(height: 6),
//             Row(
//               children: [
//                 Icon(Icons.calendar_today_outlined, size: 20),
//                 SizedBox(width: 5),
//                 Text(
//                   '${paketDetailModel?.duration ?? "-"} Hari',
//                   style: Constant.primaryTextStyle
//                       .copyWith(fontWeight: Constant.semibold),
//                 ),
//               ],
//             ),
//             SizedBox(height: 6),
//             Row(
//               children: [
//                 // Image.asset('assets/icons/Airplane Take Off.png'),
//                 Icon(Icons.airplanemode_on_outlined, size: 20),
//                 SizedBox(width: 5),
//                 Text(
//                   paketDetailModel?.cityName ?? "-",
//                   style: Constant.primaryTextStyle
//                       .copyWith(fontWeight: Constant.semibold),
//                 ),
//               ],
//             ),
//             SizedBox(height: 6),
//             Row(
//               children: [
//                 // Image.asset('assets/icons/Stack of Coins.png'),
//                 Icon(Icons.payment, size: 20),
//                 SizedBox(width: 5),
//                 Text(
//                   '${paketDetailModel?.price ?? ""}',
//                   style: Constant.primaryTextStyle
//                       .copyWith(fontWeight: Constant.semibold, fontSize: 14),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       );
//     }

//     Widget jamaahPaket() {
//       if (profileP != null) {
//         return CustomContainer.mainCard(
//           isShadow: true,
//           width: double.infinity,
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                   profileP?.memberNo == null || profileP?.memberNo == ""
//                       ? "Member No : -"
//                       : "${profileP?.memberNo}",
//                   style: Constant.primaryTextStyle),
//               SizedBox(height: 2),
//               Text(
//                 profileP?.name ?? "",
//                 style: Constant.primaryTextStyle
//                     .copyWith(fontWeight: Constant.semibold),
//               ),
//             ],
//           ),
//         );
//       }
//       return SizedBox();
//     }

//     return Scaffold(
//       appBar: CustomAppBar.appBar('Pilih Paket Konfirmasi',
//           isCenter: true, isLeading: true, color: Colors.black),
//       body: Container(
//         margin: EdgeInsets.only(top: 20, left: 20, right: 20),
//         child: Column(
//           children: [
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     'Paket Umroh',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 14,
//                     ),
//                   ),
//                   SizedBox(height: 8),
//                   konfirmasiPaket(),
//                   SizedBox(height: 12),
//                   Text(
//                     'Jamaah',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 14,
//                     ),
//                   ),
//                   SizedBox(height: 8),
//                   jamaahPaket(),
//                 ],
//               ),
//             ),

//             // CustomButton.mainButton('Lewati', () {
//             //   Navigator.push(
//             //       context,
//             //       MaterialPageRoute(
//             //         builder: (context) => TambahJamaah2View(),
//             //       ));
//             // }),
//             // SizedBox(height: 10),
//             CustomButton.mainButton('Selanjutnya', () async {
//               await Utils.showYesNoDialog(
//                 context: context,
//                 title: "Pilih Paket",
//                 desc: 'Apakah Anda yakin ingin mengajukan paket ini?',
//                 yesCallback: () async {
//                   Navigator.pop(context);
//                   try {
//                     SharedPreferences prefs =
//                         await SharedPreferences.getInstance();
//                     final roles = prefs.getString(Constant.kSetPrefRoles);

//                     final result = await context
//                         .read<PaketProvider>()
//                         .pilihPaket(
//                             packageScheduleid: "${jamaahP.getTanggalUmrohIdV}",
//                             bookingMemberId:
//                                 "${detailJamaahP?.bookingMemberId ?? 0}",
//                             paketId: "${detailP?.id ?? 0}");
//                     if (result.success == true) {
//                       jamaahP.setPaketUmrohIdV = null;
//                       jamaahP.setPaketUmrohNameV = null;
//                       jamaahP.setPaketUmrohHargaV = null;
//                       jamaahP.setTanggalUmrohIdV = null;
//                       jamaahP.setPaketUmrohIndexV = null;
//                       jamaahP.setTanggalUmrohNameV = null;
//                       paketP.paketDetailModel = PaketDetailModel();
//                       await Utils.showSuccess(msg: result.message);
//                       Future.delayed(Duration(seconds: 2), () {
//                         Navigator.pushReplacementNamed(context, '/home',
//                             arguments: roles);
//                       });
//                     } else {
//                       Utils.showFailed(msg: result.message);
//                     }
//                   } catch (e) {
//                     Utils.showFailed(
//                         msg: e.toString().toLowerCase().contains("doctype")
//                             ? "Maaf, Terjadi Galat!"
//                             : "$e");
//                   }
//                 },
//                 noCallback: () {
//                   Navigator.pop(context);
//                 },
//               );
//             }),
//             SizedBox(height: 16),
//           ],
//         ),
//       ),
//     );
//   }
// }
