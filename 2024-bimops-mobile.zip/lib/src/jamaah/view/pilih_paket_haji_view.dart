// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/auth/provider/auth_provider.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:chatour/src/jamaah/view/konfirmasi_paket_view.dart';
// import 'package:chatour/utils/Utils.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../../common/base/base_state.dart';
// import '../../../common/component/custom_container.dart';
// import '../../../common/component/custom_dropdown.dart';
// import '../../paket/model/paket_detail_model.dart';
// import '../../paket/provider/paket_provider.dart';

// class PilihPaketHajiView extends StatefulWidget {
//   final int nominalTabungan;

//   const PilihPaketHajiView({super.key, required this.nominalTabungan});
//   @override
//   State<PilihPaketHajiView> createState() => _PilihPaketHajiViewState();
// }

// class _PilihPaketHajiViewState extends BaseState<PilihPaketHajiView> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     // await context.read<JamaahProvider>().fetchJamaah(withLoading: true);

//     context.read<PaketProvider>().clearFilter();
//     await context.read<PaketProvider>().fetchPaketHaji(withLoading: true);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final detailP = context.watch<PaketProvider>().paketDetailModel.data;
//     final detail = context.watch<PaketProvider>().paketDetailModel;
//     FocusManager.instance.primaryFocus?.unfocus();
//     final auth = context.watch<AuthProvider>();
//     final jamaahP = context.watch<JamaahProvider>();
//     final paketP = context.watch<PaketProvider>();
//     final paket = context.watch<PaketProvider>().paketHajiModel.data;
//     final schedule = context.watch<PaketProvider>().scheduleModel.data;
//     final paketDetail = context.watch<PaketProvider>().paketDetailModel.data;
//     final paketDetailModel = context.watch<PaketProvider>().paketDetailModel;

//     Widget textField({
//       required TextEditingController controller,
//       Widget? suffixIcon,
//       String? hintText,
//       bool ReadOnly = false,
//       Function()? onTap,
//     }) {
//       return Column(
//         children: [
//           SizedBox(height: 6),
//           TextFormField(
//             cursorColor: Constant.primaryColor,
//             controller: controller,
//             style: Constant.primaryTextStyle,
//             readOnly: ReadOnly,
//             decoration: InputDecoration(
//               isDense: true,
//               contentPadding: EdgeInsets.fromLTRB(14, 14, 14, 14),
//               hintText: hintText ?? "",
//               suffixIcon: Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: suffixIcon,
//               ),
//               suffixIconConstraints:
//                   BoxConstraints(maxHeight: 30, maxWidth: 30),
//               border: OutlineInputBorder(
//                   borderSide: BorderSide.none,
//                   borderRadius: BorderRadius.circular(10)),
//               filled: true,
//               fillColor: Colors.grey.shade200,
//             ),
//           ),
//           SizedBox(
//             height: 10,
//           )
//         ],
//       );
//     }

//     Widget detailPaket() {
//       if (jamaahP.getPaketUmrohNameV != null) {
//         final detailPaketApproval =
//             context.watch<PaketProvider>().paketDetailModel.data;
//         return CustomContainer.mainCard(
//           isShadow: true,
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Icon(Icons.calendar_today_outlined, size: 20),
//                   SizedBox(width: 5),
//                   Expanded(
//                     child: Text(
//                       '${detailP?.name ?? "-"} ${detailP?.duration ?? "-"} Hari',
//                       overflow: TextOverflow.ellipsis,
//                       maxLines: 2,
//                       style: Constant.primaryTextStyle
//                           .copyWith(fontWeight: Constant.semibold),
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: 6),
//               Row(
//                 children: [
//                   // Image.asset('assets/icons/Airplane Take Off.png'),
//                   Icon(Icons.airplanemode_on_outlined, size: 20),
//                   SizedBox(width: 5),
//                   Expanded(
//                     child: Text(
//                       detailP?.cityName ?? "-",
//                       overflow: TextOverflow.ellipsis,
//                       maxLines: 2,
//                       style: Constant.primaryTextStyle
//                           .copyWith(fontWeight: Constant.semibold),
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: 6),
//               Row(
//                 children: [
//                   // Image.asset('assets/icons/Stack of Coins.png'),
//                   Icon(Icons.payment, size: 20),
//                   SizedBox(width: 5),
//                   Expanded(
//                     child: Text(
//                       '${detailP?.price ?? ""}',
//                       overflow: TextOverflow.ellipsis,
//                       maxLines: 2,
//                       style: Constant.primaryTextStyle.copyWith(
//                           fontWeight: Constant.semibold, fontSize: 14),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         );
//       }
//       return SizedBox();
//     }

//     int packagePrice = int.parse(jamaahP.paketUmrohHargaV ?? "0");

//     return Scaffold(
//       appBar: CustomAppBar.appBar('Pilih Paket',
//           isCenter: true, isLeading: true, color: Colors.black),
//       body: WillPopScope(
//         onWillPop: () async {
//           jamaahP.setPaketUmrohIdV = null;
//           jamaahP.setPaketUmrohNameV = null;
//           jamaahP.setPaketUmrohHargaV = null;
//           jamaahP.setTanggalUmrohIdV = null;
//           jamaahP.setPaketUmrohIndexV = null;
//           jamaahP.setTanggalUmrohNameV = null;
//           paketP.paketDetailModel = PaketDetailModel();
//           return true;
//         },
//         child: Container(
//           margin: EdgeInsets.only(top: 20, left: 20, right: 20),
//           child: Column(
//             children: [
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       'Pilih Paket Umroh',
//                       style:
//                           TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
//                     ),
//                     SizedBox(height: 6),
//                     CustomDropdown.searchDropdown(
//                       hintText: 'Pilih Paket Umroh',
//                       // selectedItem: jamaahP.getPaketUmrohIdV == null
//                       //     ? null
//                       //     : paket?[jamaahP.getPaketUmrohIndexV ?? 0]?.name ??
//                       //         "",
//                       list: (paket ?? [])
//                           .map((e) => "${e?.name ?? "-"}\n${e?.price ?? "-"}")
//                           .toList(),
//                       onChanged: (val) {
//                         jamaahP.setPaketUmrohNameV = val;
//                         jamaahP.setPaketUmrohIdV = ((paket ?? [])
//                                     .firstWhere((element) =>
//                                         "${element?.name}\n${element?.price}" ==
//                                         val)
//                                     ?.id ??
//                                 0)
//                             .toString();
//                         int id = ((paket ?? [])
//                                 .firstWhere((element) =>
//                                     "${element?.name}\n${element?.price}" ==
//                                     val)
//                                 ?.id ??
//                             0);
//                         jamaahP.setPaketUmrohIndexV = ((paket ?? [])
//                             .indexWhere((element) => element?.id == id));
//                         jamaahP.setPaketUmrohHargaV = ((paket ?? [])
//                                     .firstWhere((element) =>
//                                         "${element?.name}\n${element?.price}" ==
//                                         val)
//                                     ?.price ??
//                                 0)
//                             .toString()
//                             .replaceAll("Rp ", "")
//                             .replaceAll(".", "");
//                         setState(() {});
//                         context.read<PaketProvider>().fetchDetailPaket(
//                             paketId: jamaahP.getPaketUmrohIdV ?? "",
//                             withLoading: true);

//                         context.read<PaketProvider>().fetchSchedule(
//                             packageId: jamaahP.getPaketUmrohIdV ?? "",
//                             withLoading: true);
//                       },
//                     ),
//                     SizedBox(height: 8),
//                     jamaahP.getPaketUmrohNameV == null
//                         ? SizedBox()
//                         : CustomDropdown.searchDropdown(
//                             hintText: 'Pilih Tanggal Keberangkatan',
//                             selectedItem: jamaahP.getTanggalUmrohNameV,
//                             list: (schedule ?? [])
//                                 .map((e) => e?.shortDate ?? "-")
//                                 .toList(),
//                             onChanged: (val) {
//                               jamaahP.setTanggalUmrohNameV = val;
//                               jamaahP.setTanggalUmrohIdV = ((schedule ?? [])
//                                           .firstWhere((element) =>
//                                               element?.shortDate == val)
//                                           ?.id ??
//                                       0)
//                                   .toString();
//                               setState(() {});
//                             },
//                           ),
//                     SizedBox(height: 15),
//                     detailPaket(),
//                   ],
//                 ),
//               ),

//               // CustomButton.mainButton('Lewati', () {
//               //   Navigator.push(
//               //       context,
//               //       MaterialPageRoute(
//               //         builder: (context) => TambahJamaah2View(),
//               //       ));
//               // }),
//               // SizedBox(height: 10),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     'Saldo Anda',
//                     overflow: TextOverflow.ellipsis,
//                     maxLines: 2,
//                     style: Constant.primaryTextStyle
//                         .copyWith(fontWeight: Constant.semibold, fontSize: 12),
//                   ),
//                   Row(
//                     children: [
//                       Expanded(
//                         child: Text(
//                           '${Utils.thousandSeparator(widget.nominalTabungan)}',
//                           overflow: TextOverflow.ellipsis,
//                           maxLines: 2,
//                           style: Constant.primaryTextStyle.copyWith(
//                               fontWeight: FontWeight.w900, fontSize: 16),
//                         ),
//                       ),
//                       Text(
//                         widget.nominalTabungan >= packagePrice
//                             ? ""
//                             : "Saldo Tidak Cukup",
//                         style: TextStyle(
//                           color: Colors.red,
//                         ),
//                       )
//                     ],
//                   ),
//                   SizedBox(height: 12),
//                   CustomButton.mainButton(
//                     'Selanjutnya',
//                     () {
//                       if (jamaahP.paketUmrohHargaV != null &&
//                           jamaahP.paketUmrohHargaV != "" &&
//                           jamaahP.paketUmrohHargaV != "null" &&
//                           jamaahP.paketUmrohHargaV != "-1" &&
//                           widget.nominalTabungan >= packagePrice) {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => KonfirmasiPaketView(
//                                     paketId: jamaahP.paketUmrohIdV ?? "0",
//                                     paketDetailModel: paketDetailModel)));
//                       } else {
//                         return null;
//                       }
//                     },
//                     color: jamaahP.paketUmrohNameV != null &&
//                             jamaahP.paketUmrohNameV != "" &&
//                             jamaahP.tanggalUmrohNameV != null &&
//                             jamaahP.tanggalUmrohNameV != "" &&
//                             widget.nominalTabungan >= packagePrice
//                         ? Constant.primaryColor
//                         : Colors.grey,
//                   ),
//                 ],
//               ),
//               SizedBox(height: 16),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
