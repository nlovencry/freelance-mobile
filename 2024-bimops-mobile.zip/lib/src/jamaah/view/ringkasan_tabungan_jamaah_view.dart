// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/view/tabungan_jamaah_view.dart';
// import 'package:firebase_crashlytics/firebase_crashlytics.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';

// import '../../../common/base/base_state.dart';
// import '../../../common/helper/safe_network_image.dart';
// import '../../../utils/utils.dart';
// import '../model/add_jamaah_local_model.dart';
// import '../provider/jamaah_provider.dart';

// class RingkasanTabunganJamaahView extends StatefulWidget {
//   const RingkasanTabunganJamaahView({super.key});

//   @override
//   State<RingkasanTabunganJamaahView> createState() =>
//       _RingkasanTabunganJamaahViewState();
// }

// class _RingkasanTabunganJamaahViewState
//     extends BaseState<RingkasanTabunganJamaahView> {
//   @override
//   Widget build(BuildContext context) {
//     final jamaahP = context.watch<JamaahProvider>();

//     final listJamaahLocal = context.watch<JamaahProvider>().listJamaahLocal;

//     final listJamaahLocalFiles =
//         context.watch<JamaahProvider>().listJamaahLocalFiles;
//     // Widget dataPaket() {
//     //   return Column(
//     //     mainAxisSize: MainAxisSize.min,
//     //     crossAxisAlignment: CrossAxisAlignment.start,
//     //     children: [
//     //       CustomContainer.mainCard(
//     //         isShadow: true,
//     //         height: 50,
//     //         width: 100.w,
//     //         margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//     //         child: Text(jamaahP.paketUmrohNameV ?? "-"),
//     //       ),
//     //       SizedBox(
//     //         height: 2,
//     //       ),
//     //       CustomContainer.mainCard(
//     //         isShadow: true,
//     //         height: 50,
//     //         width: 100.w,
//     //         margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//     //         child: Text(jamaahP.tanggalUmrohC.text == ""
//     //             ? "-"
//     //             : jamaahP.tanggalUmrohC.text),
//     //       ),
//     //     ],
//     //   );
//     // }

//     Widget jenisTabungan() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         height: 50,
//         width: 100.w,
//         margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//         child: Row(
//           children: [
//             Icon(
//               Icons.verified,
//               color: Constant.primaryColor,
//             ),
//             SizedBox(
//               width: 8,
//             ),
//             Text(
//                 'Tabungan ${jamaahP.tabunganIndividu ? "Individu" : "Keluarga/Kelompok"}'),
//           ],
//         ),
//       );
//     }

//     Widget cardJamaah(int index) {
//       // final item = jamaahList?[index];
//       final item = listJamaahLocal[index];
//       final itemFiles = listJamaahLocalFiles[index];
//       return GestureDetector(
//         onTap: () {
//           // Navigator.push(
//           //     context,
//           //     MaterialPageRoute(
//           //       builder: (context) => TambahJamaah4View(),
//           //     ));
//         },
//         child: Container(
//           padding: EdgeInsets.all(8),
//           decoration: BoxDecoration(
//               border: Border.all(width: 1, color: Constant.primaryColor),
//               borderRadius: BorderRadius.circular(12)),
//           child: Row(
//             children: [
//               Expanded(
//                 flex: 2,
//                 child: itemFiles.photo == null
//                     ? CircleAvatar(
//                         radius: 26,
//                         backgroundImage: AssetImage('assets/images/avatar.png'),
//                       )
//                     : CircleAvatar(
//                         radius: 26,
//                         backgroundImage: FileImage(itemFiles.photo!),
//                       ),
//               ),
//               SizedBox(width: 10),
//               Expanded(
//                 flex: 8,
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       children: [
//                         Expanded(
//                             child: Text(
//                           '${item.email}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 11),
//                         )),
//                         Text(
//                           item.isLeader == "1" ? "Leader" : "",
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 11),
//                         )
//                       ],
//                     ),
//                     Text(
//                       item.name ?? "-",
//                       style: Constant.primaryTextStyle.copyWith(
//                           fontSize: 15, fontWeight: Constant.semibold),
//                     ),
//                     Text(
//                       '${item.gender == "1" ? "Laki-laki" : "Perempuan"}',
//                       style: Constant.primaryTextStyle.copyWith(fontSize: 11),
//                     )
//                   ],
//                 ),
//               ),
//               Expanded(flex: 1, child: Icon(Icons.arrow_forward_ios, size: 20))
//             ],
//           ),
//         ),
//       );
//     }

//     Widget dataJamaah() {
//       // if (listJamaahLocal.isNotEmpty) {
//       return ListView.separated(
//         physics: NeverScrollableScrollPhysics(),
//         shrinkWrap: true,
//         itemBuilder: (context, index) => cardJamaah(index),
//         separatorBuilder: (context, index) => SizedBox(height: 10),
//         itemCount: listJamaahLocal.length,
//       );
//       // }
//       // return Center(
//       //     child: Text(
//       //   "Belum ada data jamaah",
//       //   style: Constant.primaryTextStyle
//       //       .copyWith(fontSize: Constant.fontSizeRegular),
//       // ));
//     }

//     Widget cek() {
//       return Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Container(
//             height: 24,
//             margin: EdgeInsets.only(top: 10),
//             child: Row(
//               children: [
//                 SizedBox(
//                   width: 20,
//                   height: 20,
//                   child: Checkbox(
//                     shape: CircleBorder(),
//                     value: jamaahP.setuju,
//                     fillColor: MaterialStateProperty.all(Constant.primaryColor),
//                     onChanged: (check) {
//                       context.read<JamaahProvider>().setuju = !jamaahP.setuju;
//                     },
//                   ),
//                 ),
//                 SizedBox(width: 8),
//                 Flexible(
//                     child:
//                         Text('Saya setuju, syarat dan ketentuan yang berlaku'))
//               ],
//             ),
//           ),
//         ],
//       );
//     }

//     // Widget simpan() {
//     //   return AlertDialog(
//     //     title: Text(
//     //       'Simpan Jamaah',
//     //       style: Constant.primaryTextStyle.copyWith(fontWeight: Constant.bold),
//     //     ),
//     //     content: Text('Apakah Anda yakin ingin menyimpan data jamaah ini?'),
//     //     actions: <Widget>[
//     //       TextButton(
//     //         onPressed: () {},
//     //         child: Text('Batal'),
//     //       ),
//     //       TextButton(
//     //         onPressed: () {},
//     //         child: Text('Ya'),
//     //       ),
//     //     ],
//     //   );
//     // }

//     return Scaffold(
//       appBar: CustomAppBar.appBar(
//         'Ringkasan Tabungan Jamaah',
//         color: Colors.black,
//         isLeading: true,
//         isCenter: true,
//       ),
//       body: WillPopScope(
//         onWillPop: () async {
//           await Utils.showYesNoDialog(
//             context: context,
//             title: "Batalkan Isi Data Jamaah",
//             desc: 'Semua data jamaah akan terhapus, Anda yakin?',
//             yesCallback: () async {
//               await context
//                   .read<JamaahProvider>()
//                   .clearJamaah(deleteAll: true)
//                   .then((value) {
//                 jamaahP.setuju = false;
//                 Navigator.of(context)
//                   ..pop()
//                   ..pop()
//                   ..pop();
//                 return true;
//               }).onError((error, stackTrace) {
//                 FirebaseCrashlytics.instance
//                     .log("Cancel Isi Data Jamaah Error : " + error.toString());
//                 Utils.showFailed(
//                     msg: error.toString().toLowerCase().contains("doctype")
//                         ? "Gagal Batalkan Isi Data Jamaah!"
//                         : "$error");
//                 return false;
//               });
//             },
//             noCallback: () {
//               Navigator.pop(context);
//             },
//           ).onError((error, stackTrace) {
//             FirebaseCrashlytics.instance
//                 .log("Cancel Isi Data Jamaah Error : " + error.toString());
//             Utils.showFailed(
//                 msg: error.toString().toLowerCase().contains("doctype")
//                     ? "Gagal Batalkan Isi Data Jamaah!"
//                     : "$error");
//             return false;
//           });
//           return false;
//         },
//         child: Container(
//           margin: EdgeInsets.only(top: 8, left: 20, right: 20),
//           child: Column(
//             children: [
//               Expanded(
//                 child: SingleChildScrollView(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       // Text('Data Paket'),
//                       // dataPaket(),
//                       // SizedBox(height: 10),
//                       Text('Jenis Tabungan'),
//                       jenisTabungan(),
//                       SizedBox(height: 10),
//                       Text('Data Jamaah'),
//                       SizedBox(height: 4),
//                       dataJamaah(),
//                       SizedBox(height: 10),
//                     ],
//                   ),
//                 ),
//               ),
//               cek(),
//               SizedBox(height: 10),
//               Padding(
//                 padding: const EdgeInsets.only(bottom: 16),
//                 child: CustomButton.mainButton(
//                   'Simpan',
//                   () async {
//                     if (jamaahP.setuju) {
//                       await context
//                           .read<JamaahProvider>()
//                           .sendJamaah()
//                           .then((value) async {
//                         await Utils.showYesNoDialog(
//                           context: context,
//                           title: "Simpan Jamaah",
//                           desc:
//                               'Apakah Anda yakin ingin menyimpan data jamaah ini?',
//                           yesCallback: () async {
//                             handleTap(() async {
//                               await context
//                                   .read<JamaahProvider>()
//                                   .confirmBooking()
//                                   .then((value) => Navigator.of(context)
//                                           .push(MaterialPageRoute(
//                                         builder: (context) =>
//                                             TabunganJamaahView(),
//                                       ))
//                                           .onError((error, stackTrace) {
//                                         FirebaseCrashlytics.instance.log(
//                                             "Tambah Jamaah Error : " +
//                                                 error.toString());
//                                         Utils.showFailed(
//                                             msg: error
//                                                     .toString()
//                                                     .toLowerCase()
//                                                     .contains("doctype")
//                                                 ? "Gagal Menambah Jamaah!"
//                                                 : "$error");
//                                       }));
//                             });
//                           },
//                           noCallback: () => Navigator.pop(context),
//                         ).onError((error, stackTrace) {
//                           FirebaseCrashlytics.instance.log(
//                               "Tambah Jamaah No Choicr Error : " +
//                                   error.toString());
//                           Utils.showFailed(
//                               msg: error
//                                       .toString()
//                                       .toLowerCase()
//                                       .contains("doctype")
//                                   ? "Gagal Menambah Jamaah!"
//                                   : "$error");
//                         });
//                       }).onError((error, stackTrace) {
//                         FirebaseCrashlytics.instance.log(
//                             "Tambah Jamaah Send API Error : " +
//                                 error.toString());

//                         Utils.showFailed(
//                             msg: error
//                                     .toString()
//                                     .toLowerCase()
//                                     .contains("doctype")
//                                 ? "Gagal Menambah Jamaah!"
//                                 : "$error");
//                       });
//                     }
//                   },
//                   color: jamaahP.setuju ? Constant.primaryColor : Colors.grey,
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
