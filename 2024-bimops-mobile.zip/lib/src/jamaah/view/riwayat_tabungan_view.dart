// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/common/helper/scroll_listener.dart';
// import 'package:chatour/src/jamaah/provider/detail_jamaah_provider.dart';
// import 'package:chatour/src/jamaah/provider/riwayat_tabungan_provider.dart';
// import 'package:chatour/utils/Utils.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';
// import 'package:url_launcher/url_launcher.dart';

// import '../../../common/component/custom_alert.dart';

// class RiwayatTabunganView extends StatefulWidget {
//   const RiwayatTabunganView({super.key, required this.id});

//   static Widget create(int id) => ChangeNotifierProvider<ScrollListener>(
//       create: (context) => ScrollListener.initialise(ScrollController()),
//       child: RiwayatTabunganView(id: id));

//   final int id;

//   @override
//   State<RiwayatTabunganView> createState() => _RiwayatTabunganViewState();
// }

// class _RiwayatTabunganViewState extends BaseState<RiwayatTabunganView> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     loading(true);
//     await context
//         .read<RiwayatTabunganProvider>()
//         .fetchRiwayatTabungan(widget.id, withLoading: false);
//     await context
//         .read<DetailJamaahProvider>()
//         .fetchDetailJamaah(widget.id, withLoading: false);
//     loading(false);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final detail =
//         context.watch<RiwayatTabunganProvider>().riwayatTabunganModel.data;
//     final title =
//         context.watch<DetailJamaahProvider>().getJamaahDetailModel.data;
//     Widget cardTabungan(int index) {
//       final item = detail?[index];
//       return CustomContainer.mainCard(
//         child: Row(
//           children: [
//             Expanded(
//                 flex: 1, child: Image.asset('assets/icons/komisi_profil.png')),
//             SizedBox(width: 12),
//             Expanded(
//               flex: 6,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     '${item?.totalBillDesc}',
//                     style: Constant.primaryTextStyle
//                         .copyWith(fontWeight: Constant.semibold),
//                   ),
//                   SizedBox(
//                     height: 2,
//                   ),
//                   Text('${item?.date}')
//                 ],
//               ),
//             ),
//             Expanded(
//               flex: 3,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 mainAxisAlignment: MainAxisAlignment.end,
//                 children: [
//                   Text(
//                     '${item?.status}',
//                     textAlign: TextAlign.right,
//                     style: TextStyle(color: Colors.cyan),
//                   ),
//                   InkWell(
//                     onTap: () {
//                       String? invoicePath = item?.invoicePath;
//                       if (invoicePath != null || invoicePath != "") {
//                         launch(invoicePath ?? "");
//                       }
//                     },
//                     child: Container(
//                       decoration: BoxDecoration(
//                           // color: Constant.primaryColor,
//                           borderRadius: BorderRadius.circular(50)),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           Icon(
//                             Icons.copy_outlined,
//                             color: Constant.primaryColor,
//                             size: 10,
//                           ),
//                           SizedBox(width: 2),
//                           Text(
//                             'Kwitansi',
//                             style: Constant.primaryTextStyle.copyWith(
//                                 color: Constant.primaryColor,
//                                 decoration: TextDecoration.underline,
//                                 fontSize: 10),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 4),
//                 ],
//               ),
//             )
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       appBar: CustomAppBar.appBar('Riwayat Tabungan ${title?.name}',
//           isCenter: true, isLeading: true, color: Colors.black),
//       body: RefreshIndicator(
//         color: Constant.primaryColor,
//         onRefresh: () async {
//           loading(true);
//           await context
//               .read<RiwayatTabunganProvider>()
//               .fetchRiwayatTabungan(widget.id, withLoading: false);
//           await context
//               .read<DetailJamaahProvider>()
//               .fetchDetailJamaah(widget.id, withLoading: false);
//           loading(false);
//         },
//         child: Padding(
//           padding: EdgeInsets.only(left: 20, right: 20, top: 10),
//           child: (detail ?? []).isNotEmpty
//               ? ListView.separated(
//                   itemBuilder: (context, index) => cardTabungan(index),
//                   separatorBuilder: (context, index) => SizedBox(height: 10),
//                   itemCount: detail?.length ?? 0)
//               : Utils.notFoundImage(),
//         ),
//       ),
//     );
//   }
// }
