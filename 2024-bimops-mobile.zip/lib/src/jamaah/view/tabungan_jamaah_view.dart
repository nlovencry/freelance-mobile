// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_alert.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/home/view/main_home.dart';
// import 'package:chatour/src/jamaah/model/detail_booking_model.dart';
// import 'package:chatour/src/jamaah/view/jamaah_view.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:sizer/sizer.dart';

// import '../../../common/helper/safe_network_image.dart';
// import '../provider/jamaah_provider.dart';

// class TabunganJamaahView extends StatefulWidget {
//   const TabunganJamaahView({super.key});

//   @override
//   State<TabunganJamaahView> createState() => _TabunganJamaahViewState();
// }

// class _TabunganJamaahViewState extends BaseState<TabunganJamaahView> {
//   String? image;

//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     await context.read<JamaahProvider>().fetchDetailBooking(withLoading: true);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final detailBookingP =
//         context.watch<JamaahProvider>().detailBookingModel.data;
//     final dataJamaahList =
//         context.watch<JamaahProvider>().detailBookingModel.data?.jamaah;

//     Widget Pemberitahuan() {
//       return CustomContainer.mainCard(
//           margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//           child: Column(
//             children: [
//               Row(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.only(top: 2),
//                     child: Icon(Icons.info),
//                   ),
//                   SizedBox(
//                     width: 10,
//                   ),
//                   Expanded(
//                     child: Column(
//                       mainAxisSize: MainAxisSize.min,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                             'Data jamaah berhasil disimpan, silakan melakukan proses transfer tabungan dengan Virtual Account dibawah.'),
//                       ],
//                     ),
//                   )
//                 ],
//               )
//             ],
//           ));
//     }

//     // Widget dataPaket() {
//     //   if (detailBookingP?.packageName != null) {
//     //     return CustomContainer.mainCard(
//     //       isShadow: true,
//     //       height: 70,
//     //       width: 100.w,
//     //       margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//     //       child: Column(
//     //         children: [
//     //           Row(
//     //             children: [
//     //               Text(detailBookingP?.packageName ?? "-"),
//     //             ],
//     //           ),
//     //           SizedBox(height: 8),
//     //           Row(
//     //             children: [
//     //               Text(detailBookingP?.packageDateDeparture ?? "-"),
//     //             ],
//     //           ),
//     //         ],
//     //       ),
//     //     );
//     //   }
//     //   return SizedBox();
//     // }

//     Widget jenisTabungan() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         height: 50,
//         width: 100.w,
//         margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//         child: Row(
//           children: [
//             Icon(
//               Icons.verified,
//               color: Constant.primaryColor,
//             ),
//             SizedBox(width: 8),
//             Text(
//                 'Tabungan ${detailBookingP?.isGroup == 1 ? "Keluarga/Kelompok" : "Individu"}'),
//           ],
//         ),
//       );
//     }

//     Widget dataVirtualAccount() {
//       if (detailBookingP?.va != null) {
//         return ListView.separated(
//             shrinkWrap: true,
//             itemCount: detailBookingP?.va?.length ?? 0,
//             separatorBuilder: (_, __) => SizedBox(height: 10),
//             itemBuilder: (context, index) {
//               final item = detailBookingP?.va?[index];
//               if (item?.vaBank == "Bank BNI") {
//                 image = "assets/icons/bni.png";
//               } else if (item?.vaBank == "Bank BCA") {
//                 image = "assets/icons/bca.png";
//               } else if (item?.vaBank == "Bank BRI") {
//                 image = "assets/icons/bri.png";
//               } else if (item?.vaBank == "Bank Mandiri") {
//                 image = "assets/icons/bank-mandiri.png";
//               }
//               return CustomContainer.mainCard(
//                   isShadow: true,
//                   margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//                   child: Row(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Expanded(
//                         flex: 2,
//                         child: ClipRRect(
//                           borderRadius: BorderRadius.circular(20),
//                           child: Container(
//                             child: Image.asset(image!),
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 12),
//                       Expanded(
//                         flex: 9,
//                         child: Column(
//                           mainAxisSize: MainAxisSize.min,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Row(
//                               children: [
//                                 Text(
//                                   '${item?.vaName ?? "-"} - Chatour',
//                                   style: Constant.primaryTextStyle
//                                       .copyWith(fontSize: 12),
//                                 ),
//                                 Spacer(),
//                                 (item?.vaName ?? "") == ""
//                                     ? SizedBox()
//                                     : InkWell(
//                                         onTap: () {
//                                           String? vaName = item?.vaName;
//                                           if (vaName != null || vaName != "") {
//                                             Clipboard.setData(new ClipboardData(
//                                                 text: vaName ?? ""));
//                                             CustomAlert.showSnackBar(
//                                                 context,
//                                                 'Nama VA berhasil disalin',
//                                                 false,
//                                                 color: Colors.black);
//                                           }
//                                         },
//                                         child: Container(
//                                           // padding: EdgeInsets.all(2),
//                                           width: 20,
//                                           height: 30,
//                                           decoration: BoxDecoration(
//                                               color: Colors.transparent,
//                                               borderRadius:
//                                                   BorderRadius.circular(50)),
//                                           child: Row(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.center,
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                             children: [
//                                               Icon(
//                                                 Icons.copy_outlined,
//                                                 color: Colors.redAccent,
//                                                 size: 15,
//                                               ),
//                                               // SizedBox(
//                                               //   width: 2,
//                                               // ),
//                                               // Text(
//                                               //   'salin',
//                                               //   style: Constant.primaryTextStyle
//                                               //       .copyWith(
//                                               //           color: Colors.white,
//                                               //           fontSize: 10),
//                                               // ),
//                                             ],
//                                           ),
//                                         ),
//                                       )
//                               ],
//                             ),
//                             // SizedBox(height: 10),
//                             Row(
//                               children: [
//                                 Text(
//                                   '${item?.vaBank ?? '-'}  ${item?.vaNumber ?? "-"}',
//                                   style: Constant.primaryTextStyle
//                                       .copyWith(fontSize: 12),
//                                 ),
//                                 Spacer(),
//                                 (item?.vaNumber ?? "") == ""
//                                     ? SizedBox()
//                                     : InkWell(
//                                         onTap: () async {
//                                           String? vaNumber = item?.vaNumber;
//                                           if (vaNumber != null ||
//                                               vaNumber != "") {
//                                             Clipboard.setData(new ClipboardData(
//                                                 text: vaNumber ?? ""));
//                                             CustomAlert.showSnackBar(
//                                                 context,
//                                                 'Nomor VA berhasil disalin',
//                                                 false,
//                                                 color: Colors.black);
//                                           }
//                                         },
//                                         child: Container(
//                                           // padding: EdgeInsets.all(2),
//                                           width: 20,
//                                           height: 30,
//                                           decoration: BoxDecoration(
//                                               color: Colors.transparent,
//                                               borderRadius:
//                                                   BorderRadius.circular(50)),
//                                           child: Row(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.center,
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                             children: [
//                                               Icon(
//                                                 Icons.copy_outlined,
//                                                 color: Colors.redAccent,
//                                                 size: 15,
//                                               ),
//                                               // SizedBox(
//                                               //   width: 2,
//                                               // ),
//                                               // Text(
//                                               //   'salin',
//                                               //   style: Constant.primaryTextStyle
//                                               //       .copyWith(
//                                               //           color: Colors.white,
//                                               //           fontSize: 10),
//                                               // ),
//                                             ],
//                                           ),
//                                         ),
//                                       )
//                               ],
//                             )
//                           ],
//                         ),
//                       ),
//                     ],
//                   )
//                   // child: ListView.separated(
//                   //   physics: NeverScrollableScrollPhysics(),
//                   //   shrinkWrap: true,
//                   //   itemCount: 5,
//                   //   itemBuilder: (context, index) {
//                   //     return Column(
//                   //       crossAxisAlignment: CrossAxisAlignment.start,
//                   //       children: [
//                   //         Row(
//                   //           crossAxisAlignment: CrossAxisAlignment.start,
//                   //           children: [
//                   //             Expanded(
//                   //               flex: 2,
//                   //               child: ClipRRect(
//                   //                 borderRadius: BorderRadius.circular(20),
//                   //                 child: Container(
//                   //                   child: Image.asset(image!),
//                   //                 ),
//                   //               ),
//                   //             ),
//                   //             SizedBox(width: 12),
//                   //             Expanded(
//                   //               flex: 9,
//                   //               child: Column(
//                   //                 mainAxisSize: MainAxisSize.min,
//                   //                 crossAxisAlignment: CrossAxisAlignment.start,
//                   //                 children: [
//                   //                   Row(
//                   //                     children: [
//                   //                       Text(
//                   //                         '${item?.vaName ?? "-"} - Chatour',
//                   //                         style: Constant.primaryTextStyle
//                   //                             .copyWith(fontSize: 12),
//                   //                       ),
//                   //                       Spacer(),
//                   //                       (item?.vaName ?? "") == ""
//                   //                           ? SizedBox()
//                   //                           : InkWell(
//                   //                               onTap: () {
//                   //                                 String? vaName =
//                   //                                     item?.vaName;
//                   //                                 if (vaName != null ||
//                   //                                     vaName != "") {
//                   //                                   Clipboard.setData(
//                   //                                       new ClipboardData(
//                   //                                           text: vaName ?? ""));
//                   //                                   CustomAlert.showSnackBar(
//                   //                                       context,
//                   //                                       'Nama VA berhasil disalin',
//                   //                                       false,
//                   //                                       color: Colors.black);
//                   //                                 }
//                   //                               },
//                   //                               child: Container(
//                   //                                 // padding: EdgeInsets.all(2),
//                   //                                 width: 20,
//                   //                                 height: 30,
//                   //                                 decoration: BoxDecoration(
//                   //                                     color: Colors.transparent,
//                   //                                     borderRadius:
//                   //                                         BorderRadius.circular(50)),
//                   //                                 child: Row(
//                   //                                   crossAxisAlignment:
//                   //                                       CrossAxisAlignment.center,
//                   //                                   mainAxisAlignment:
//                   //                                       MainAxisAlignment.center,
//                   //                                   children: [
//                   //                                     Icon(
//                   //                                       Icons.copy_outlined,
//                   //                                       color: Colors.redAccent,
//                   //                                       size: 15,
//                   //                                     ),
//                   //                                     // SizedBox(
//                   //                                     //   width: 2,
//                   //                                     // ),
//                   //                                     // Text(
//                   //                                     //   'salin',
//                   //                                     //   style: Constant.primaryTextStyle
//                   //                                     //       .copyWith(
//                   //                                     //           color: Colors.white,
//                   //                                     //           fontSize: 10),
//                   //                                     // ),
//                   //                                   ],
//                   //                                 ),
//                   //                               ),
//                   //                             )
//                   //                     ],
//                   //                   ),
//                   //                   // SizedBox(height: 10),
//                   //                   Row(
//                   //                     children: [
//                   //                       Text(
//                   //                         '${item?.vaBank ?? '-'}  ${item?.vaNumber ?? "-"}',
//                   //                         style: Constant.primaryTextStyle
//                   //                             .copyWith(fontSize: 12),
//                   //                       ),
//                   //                       Spacer(),
//                   //                       (item?.vaNumber ?? "") == ""
//                   //                           ? SizedBox()
//                   //                           : InkWell(
//                   //                               onTap: () async {
//                   //                                 String? vaNumber =
//                   //                                     item?.vaNumber;
//                   //                                 if (vaNumber != null ||
//                   //                                     vaNumber != "") {
//                   //                                   Clipboard.setData(
//                   //                                       new ClipboardData(
//                   //                                           text: vaNumber ?? ""));
//                   //                                   CustomAlert.showSnackBar(
//                   //                                       context,
//                   //                                       'Nomor VA berhasil disalin',
//                   //                                       false,
//                   //                                       color: Colors.black);
//                   //                                 }
//                   //                               },
//                   //                               child: Container(
//                   //                                 // padding: EdgeInsets.all(2),
//                   //                                 width: 20,
//                   //                                 height: 30,
//                   //                                 decoration: BoxDecoration(
//                   //                                     color: Colors.transparent,
//                   //                                     borderRadius:
//                   //                                         BorderRadius.circular(50)),
//                   //                                 child: Row(
//                   //                                   crossAxisAlignment:
//                   //                                       CrossAxisAlignment.center,
//                   //                                   mainAxisAlignment:
//                   //                                       MainAxisAlignment.center,
//                   //                                   children: [
//                   //                                     Icon(
//                   //                                       Icons.copy_outlined,
//                   //                                       color: Colors.redAccent,
//                   //                                       size: 15,
//                   //                                     ),
//                   //                                     // SizedBox(
//                   //                                     //   width: 2,
//                   //                                     // ),
//                   //                                     // Text(
//                   //                                     //   'salin',
//                   //                                     //   style: Constant.primaryTextStyle
//                   //                                     //       .copyWith(
//                   //                                     //           color: Colors.white,
//                   //                                     //           fontSize: 10),
//                   //                                     // ),
//                   //                                   ],
//                   //                                 ),
//                   //                               ),
//                   //                             )
//                   //                     ],
//                   //                   )
//                   //                 ],
//                   //               ),
//                   //             ),
//                   //           ],
//                   //         ),
//                   //         // Row(
//                   //         //   children: [
//                   //         //     Icon(
//                   //         //       Icons.person_outline,
//                   //         //       size: 18,
//                   //         //     ),
//                   //         //     SizedBox(width: 10),
//                   //         //     Text(
//                   //         //       '${item?.vaName ?? "-"} - Chatour',
//                   //         //       style: Constant.primaryTextStyle.copyWith(fontSize: 12),
//                   //         //     ),
//                   //         //     SizedBox(width: 10),
//                   //         //     Container(
//                   //         //       padding:
//                   //         //           EdgeInsets.only(left: 5, right: 5, top: 2, bottom: 2),
//                   //         //       decoration: BoxDecoration(
//                   //         //           borderRadius: BorderRadius.circular(50),
//                   //         //           color: Constant.primaryColor),
//                   //         //       child: Row(
//                   //         //         children: [
//                   //         //           Icon(
//                   //         //             Icons.copy,
//                   //         //             size: 15,
//                   //         //             color: Colors.white,
//                   //         //           ),
//                   //         //           SizedBox(
//                   //         //             width: 2,
//                   //         //           ),
//                   //         //           Text(
//                   //         //             'salin',
//                   //         //             style: Constant.primaryTextStyle
//                   //         //                 .copyWith(color: Colors.white),
//                   //         //           )
//                   //         //         ],
//                   //         //       ),
//                   //         //     )
//                   //         //   ],
//                   //         // ),
//                   //         // SizedBox(height: 10),
//                   //         // Row(
//                   //         //   children: [
//                   //         //     Icon(
//                   //         //       Icons.atm,
//                   //         //       size: 18,
//                   //         //     ),
//                   //         //     SizedBox(width: 10),
//                   //         //     Text(
//                   //         //       '${item?.vaBank ?? '-'}  ${item?.vaNumber ?? "-"}',
//                   //         //       style: Constant.primaryTextStyle.copyWith(fontSize: 12),
//                   //         //     ),
//                   //         //     SizedBox(width: 10),
//                   //         //     Container(
//                   //         //       padding:
//                   //         //           EdgeInsets.only(left: 5, right: 5, top: 2, bottom: 2),
//                   //         //       decoration: BoxDecoration(
//                   //         //           borderRadius: BorderRadius.circular(50),
//                   //         //           color: Constant.primaryColor),
//                   //         //       child: Row(
//                   //         //         children: [
//                   //         //           Icon(
//                   //         //             Icons.copy,
//                   //         //             size: 15,
//                   //         //             color: Colors.white,
//                   //         //           ),
//                   //         //           SizedBox(
//                   //         //             width: 2,
//                   //         //           ),
//                   //         //           Text(
//                   //         //             'salin',
//                   //         //             style: Constant.primaryTextStyle
//                   //         //                 .copyWith(color: Colors.white),
//                   //         //           )
//                   //         //         ],
//                   //         //       ),
//                   //         //     )
//                   //         //   ],
//                   //         // ),
//                   //       ],
//                   //     );
//                   //   },
//                   //   separatorBuilder: (context, index) {
//                   //     return Column(
//                   //       children: [
//                   //         SizedBox(height: 4),
//                   //         Divider(color: Constant.textColor),
//                   //         SizedBox(height: 8),
//                   //       ],
//                   //     );
//                   //   },
//                   // )
//                   // child: Column(
//                   //   children: [
//                   //     Row(
//                   //       children: [
//                   //         ImageIcon(AssetImage('assets/icons/bank-account.png')),
//                   //         SizedBox(
//                   //           width: 8
//                   //         ),
//                   //         Text('Bank BRI'),
//                   //       ],
//                   //     ),
//                   //     Row(
//                   //       children: [
//                   //         Icon(Icons.credit_card),
//                   //         SizedBox(
//                   //           width: 8
//                   //         ),
//                   //         Text('9883700951944452'),
//                   //         SizedBox(
//                   //           width: 3,
//                   //         ),
//                   //         IconButton(
//                   //           onPressed: () {},
//                   //           icon: Icon(Icons.copy),
//                   //         ),
//                   //       ],
//                   //     ),
//                   //     Row(
//                   //       children: [
//                   //         Icon(Icons.money, size: 20,),
//                   //         // ImageIcon(
//                   //         //   AssetImage('assets/icons/account.png'),
//                   //         //   size: 20,
//                   //         // ),
//                   //         SizedBox(
//                   //           width: 8
//                   //         ),
//                   //         Text('Atas nama : Chatour - Muhammad Firdaus'),
//                   //         SizedBox(
//                   //           width: 2,
//                   //         ),
//                   //         IconButton(
//                   //           onPressed: () {},
//                   //           icon: Icon(Icons.copy),
//                   //         ),
//                   //       ],
//                   //     ),
//                   //   ],
//                   // ),
//                   );
//             });
//       }
//       return SizedBox();
//     }

//     Widget dataJamaah() {
//       return ListView.builder(
//         shrinkWrap: true,
//         physics: NeverScrollableScrollPhysics(),
//         itemCount: dataJamaahList?.length ?? 0,
//         itemBuilder: (context, index) {
//           final item = dataJamaahList?[index];
//           final itemVa2 = detailBookingP?.jamaah?[index]?.va;
//           if (detailBookingP?.isGroup == 1) {
//             DetailBookingModelDataVa? itemVa;
//             if (detailBookingP?.va != null) {
//               itemVa = detailBookingP?.va?[0];
//             }
//             return CustomContainer.mainCard(
//               margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Expanded(
//                     flex: 2,
//                     child: SafeNetworkImage.circle(
//                       url: item?.photoPath ?? "=",
//                       radius: 60,
//                       errorBuilder: CircleAvatar(
//                         radius: 26,
//                         backgroundImage: AssetImage('assets/images/avatar.png'),
//                       ),
//                     ),
//                   ),
//                   SizedBox(width: 8),
//                   Expanded(
//                     flex: 8,
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Expanded(
//                                 child: Text(
//                               'NIK ${item?.nik ?? "-"}',
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontSize: 11),
//                             )),
//                             Text(
//                               item?.isLeader == true ? 'Leader' : '',
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontSize: 11),
//                             )
//                           ],
//                         ),
//                         Text(
//                           item?.name ?? "-",
//                           style: Constant.primaryTextStyle.copyWith(
//                               fontSize: 15, fontWeight: Constant.semibold),
//                         ),
//                         Text(
//                           '${item?.age} - ${item?.gender == true ? "Laki-laki" : "Perempuan"}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 11),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           } else {
//             return CustomContainer.mainCard(
//               margin: EdgeInsets.only(top: 8, left: 2, right: 2),
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Expanded(
//                     flex: 2,
//                     child: SafeNetworkImage.circle(
//                       url: item?.photoPath ?? "=",
//                       radius: 60,
//                       errorBuilder: CircleAvatar(
//                         radius: 26,
//                         backgroundImage: AssetImage('assets/images/avatar.png'),
//                       ),
//                     ),
//                   ),
//                   SizedBox(width: 8),
//                   Expanded(
//                     flex: 8,
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Expanded(
//                                 child: Text(
//                               'NIK ${item?.nik ?? "-"}',
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontSize: 11),
//                             )),
//                             Text(
//                               item?.isLeader == true ? 'Leader' : '',
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontSize: 11),
//                             )
//                           ],
//                         ),
//                         Text(
//                           item?.name ?? "-",
//                           style: Constant.primaryTextStyle.copyWith(
//                               fontSize: 15, fontWeight: Constant.semibold),
//                         ),
//                         ListView.separated(
//                           shrinkWrap: true,
//                           physics: NeverScrollableScrollPhysics(),
//                           itemCount: itemVa2?.length ?? 0,
//                           separatorBuilder: (_, __) => SizedBox(height: 4),
//                           itemBuilder: (context, index) {
//                             final itemVa3 = itemVa2?[index];
//                             return Row(
//                               children: [
//                                 Expanded(
//                                   flex: 9,
//                                   child: Text(
//                                     detailBookingP?.isGroup == 1
//                                         ? '${item?.age} - ${item?.gender == true ? "Laki-laki" : "Perempuan"}'
//                                         : 'Virtual Account ${itemVa3?.vaBank ?? "-"} :\n${itemVa3?.vaNumber ?? "-"}',
//                                     style: Constant.primaryTextStyle
//                                         .copyWith(fontSize: 11),
//                                   ),
//                                 ),
//                                 (itemVa3?.vaNumber ?? "") == ""
//                                     ? SizedBox()
//                                     : InkWell(
//                                         onTap: () {
//                                           String? vaNumber = itemVa3?.vaNumber;
//                                           if (vaNumber != null ||
//                                               vaNumber != "") {
//                                             Clipboard.setData(new ClipboardData(
//                                                 text: vaNumber ?? ""));
//                                             CustomAlert.showSnackBar(
//                                                 context,
//                                                 'Nomor VA berhasil disalin',
//                                                 false,
//                                                 color: Colors.black);
//                                           }
//                                         },
//                                         child: Container(
//                                           width: 20,
//                                           height: 30,
//                                           decoration: BoxDecoration(
//                                               color: Colors.transparent,
//                                               borderRadius:
//                                                   BorderRadius.circular(50)),
//                                           child: Row(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.center,
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                             children: [
//                                               Icon(
//                                                 Icons.copy_outlined,
//                                                 color: Colors.redAccent,
//                                                 size: 15,
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ),
//                               ],
//                             );
//                           },
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           }
//         },
//       );
//     }

//     return Scaffold(
//         appBar: CustomAppBar.appBar(
//           'Tabungan Jamaah',
//           color: Colors.black,
//           isLeading: true,
//           isCenter: true,
//         ),
//         body: WillPopScope(
//           onWillPop: () async {
//             SharedPreferences prefs = await SharedPreferences.getInstance();
//             var roles = prefs.getString(Constant.kSetPrefRoles);
//             Navigator.pushReplacementNamed(context, '/home', arguments: roles);
//             return true;
//           },
//           child: RefreshIndicator(
//             onRefresh: () async {
//               getData();
//             },
//             child: Container(
//               margin: EdgeInsets.only(top: 8, left: 8, right: 8),
//               child: Column(
//                 children: [
//                   Expanded(
//                     child: SingleChildScrollView(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Pemberitahuan(),
//                           SizedBox(height: 10),
//                           if (detailBookingP?.packageName != null)
//                             //   Text('Data Paket'),
//                             // dataPaket(),
//                             // SizedBox(height: 10),
//                             Text('Jenis Tabungan'),
//                           jenisTabungan(),
//                           SizedBox(height: 10),
//                           if (detailBookingP?.va != null)
//                             Text('Data Virtual Account'),
//                           dataVirtualAccount(),
//                           SizedBox(height: 10),
//                           Text('Data Jamaah'),
//                           dataJamaah(),
//                           SizedBox(height: 10),
//                         ],
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 5),
//                   CustomButton.mainButton('Kembali ke Beranda', () async {
//                     SharedPreferences prefs =
//                         await SharedPreferences.getInstance();
//                     var roles = prefs.getString(Constant.kSetPrefRoles);
//                     Navigator.pushReplacementNamed(context, '/home',
//                         arguments: roles);
//                   }),
//                   SizedBox(height: 15)
//                 ],
//               ),
//             ),
//           ),
//         ));
//   }
// }
