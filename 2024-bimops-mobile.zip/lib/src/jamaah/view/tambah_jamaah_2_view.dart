// import 'dart:developer';

// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:chatour/src/jamaah/view/ringkasan_tabungan_jamaah_view.dart';
// import 'package:chatour/src/jamaah/view/tambah_jamaah_3_view.dart';
// import 'package:chatour/src/jamaah/view/tambah_jamaah_4_view.dart';
// import 'package:date_format/date_format.dart';
// import 'package:firebase_crashlytics/firebase_crashlytics.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../../common/helper/safe_network_image.dart';
// import '../../../utils/utils.dart';

// class TambahJamaah2View extends StatefulWidget {
//   @override
//   State<TambahJamaah2View> createState() => _TambahJamaah2ViewState();
// }

// class _TambahJamaah2ViewState extends BaseState<TambahJamaah2View> {
//   bool? isChecked = false;
//   bool? isChecked2 = false;

//   @override
//   void initState() {
//     // getData();
//     super.initState();
//   }

//   // getData() async {
//   //   await context.read<JamaahProvider>().fetchJamaah(withLoading: true);
//   // }

//   @override
//   Widget build(BuildContext context) {
//     FocusManager.instance.primaryFocus?.unfocus();
//     final jamaahP = context.watch<JamaahProvider>();
//     final listJamaahLocal = context.watch<JamaahProvider>().listJamaahLocal;
//     final listJamaahLocalFiles =
//         context.watch<JamaahProvider>().listJamaahLocalFiles;

//     log("LIST LOCAL LENGTH : ${listJamaahLocal.length}");
//     log("LIST TEAM LEADER TRUE : ${jamaahP.listJamaahLocal.where((element) => element.isLeader == "1").toList()}");

//     Widget jenisTabungan() {
//       return Container(
//         height: 80,
//         margin: EdgeInsets.only(top: 10),
//         decoration: BoxDecoration(
//             border: Border.all(
//                 width: 1,
//                 color: listJamaahLocal.isEmpty
//                     ? Constant.primaryColor
//                     : Colors.grey),
//             borderRadius: BorderRadius.circular(12)),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Container(
//               height: 24,
//               child: Row(
//                 children: [
//                   Radio(
//                     value: true,
//                     groupValue: jamaahP.tabunganIndividu,
//                     activeColor: listJamaahLocal.isEmpty
//                         ? Constant.primaryColor
//                         : Colors.grey,
//                     onChanged: (value) {
//                       if (listJamaahLocal.isEmpty) {
//                         context.read<JamaahProvider>().setTabunganIndividu =
//                             value;
//                       }
//                     },
//                   ),
//                   Text('Tabungan Individu')
//                 ],
//               ),
//             ),
//             Container(
//               margin: EdgeInsets.only(top: 6),
//               height: 24,
//               child: Row(
//                 children: [
//                   Radio(
//                     value: false,
//                     groupValue: jamaahP.tabunganIndividu,
//                     activeColor: listJamaahLocal.isEmpty
//                         ? Constant.primaryColor
//                         : Colors.grey,
//                     onChanged: (value) {
//                       if (listJamaahLocal.isEmpty) {
//                         context.read<JamaahProvider>().setTabunganIndividu =
//                             value;
//                       }
//                     },
//                   ),
//                   Text('Tabungan Keluarga / Kelompok')
//                 ],
//               ),
//             )
//           ],
//         ),
//       );
//     }

//     Widget cardJamaah(int index) {
//       // final item = jamaahList?[index];
//       final item = listJamaahLocal[index];

//       return GestureDetector(
//         onTap: () {
//           Navigator.push(
//               context,
//               MaterialPageRoute(
//                 builder: (context) => TambahJamaah3View(
//                   addJamaahLocalModel: item,
//                   addJamaahLocalFilesModel: listJamaahLocalFiles.isEmpty
//                       ? null
//                       : listJamaahLocalFiles[index],
//                   index: index,
//                 ),
//               ));
//         },
//         child: Container(
//           padding: EdgeInsets.all(8),
//           decoration: BoxDecoration(
//               border: Border.all(width: 1, color: Constant.primaryColor),
//               borderRadius: BorderRadius.circular(12)),
//           child: Row(
//             children: [
//               Expanded(
//                 flex: 2,
//                 child: listJamaahLocalFiles.isEmpty ||
//                         listJamaahLocalFiles[index].photo == null
//                     ? CircleAvatar(
//                         radius: 26,
//                         backgroundImage: AssetImage('assets/images/avatar.png'),
//                       )
//                     : CircleAvatar(
//                         radius: 26,
//                         backgroundImage:
//                             FileImage(listJamaahLocalFiles[index].photo!),
//                       ),
//               ),
//               SizedBox(width: 10),
//               Expanded(
//                 flex: 8,
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       children: [
//                         Expanded(
//                             child: Text(
//                           '${item.name} ${item.email}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 11),
//                         )),
//                         Text(
//                           '${item.isLeader == "1" ? "Leader" : ""}',
//                           style:
//                               Constant.primaryTextStyle.copyWith(fontSize: 11),
//                         )
//                       ],
//                     ),
//                     Text(
//                       item.name ?? "-",
//                       style: Constant.primaryTextStyle.copyWith(
//                           fontSize: 15, fontWeight: Constant.semibold),
//                     ),
//                     Text(
//                       '${item.gender == "1" ? "Laki-laki" : "Perempuan"}',
//                       style: Constant.primaryTextStyle.copyWith(fontSize: 11),
//                     )
//                   ],
//                 ),
//               ),
//               Expanded(
//                 flex: 1,
//                 // child: SizedBox()
//                 child: InkWell(
//                   onTap: () async {
//                     await Utils.showYesNoDialog(
//                       context: context,
//                       title: "Hapus Jamaah",
//                       desc: 'Data Jamaah ini akan terhapus, Anda yakin?',
//                       yesCallback: () async {
//                         await context
//                             .read<JamaahProvider>()
//                             .deleteJamaah(index)
//                             .then((value) async {
//                           // await Utils.showSuccess(msg: "Sukses Menambah Jamaah");
//                           // Future.delayed(Duration(seconds: 3), () {
//                           Navigator.pop(context);
//                           // });
//                         }).onError((error, stackTrace) {
//                           FirebaseCrashlytics.instance.log(
//                               "Hapus Jamaah Local Error : " + error.toString());
//                           Utils.showFailed(
//                               msg: error
//                                       .toString()
//                                       .toLowerCase()
//                                       .contains("doctype")
//                                   ? "Gagal Hapus Jamaah!"
//                                   : "$error");
//                         });
//                       },
//                       noCallback: () {
//                         Navigator.pop(context);
//                       },
//                     );
//                   },
//                   child: Container(
//                       margin: EdgeInsets.only(right: 8),
//                       padding: EdgeInsets.fromLTRB(0, 8, 8, 8),
//                       child: Icon(Icons.delete,
//                           size: 20, color: Constant.primaryColor)),
//                 ),
//                 // child: Icon(Icons.arrow_forward_ios, size: 20),
//               )
//             ],
//           ),
//         ),
//       );
//     }

//     return Scaffold(
//       appBar: CustomAppBar.appBar('Tambah Jamaah Tabungan',
//           isCenter: true, isLeading: true, color: Colors.black),
//       body: WillPopScope(
//         onWillPop: () async {
//           if (jamaahP.listJamaahLocal.isEmpty) {
//             return true;
//           }
//           await Utils.showYesNoDialog(
//             context: context,
//             title: "Batalkan Isi Data Jamaah",
//             desc: 'Semua data jamaah akan terhapus, Anda yakin?',
//             yesCallback: () async {
//               await context
//                   .read<JamaahProvider>()
//                   .clearJamaah(deleteAll: true)
//                   .then((value) {
//                 Navigator.of(context)
//                   ..pop()
//                   ..pop();
//                 return true;
//               }).onError((error, stackTrace) {
//                 FirebaseCrashlytics.instance
//                     .log("Isi Data Jamaah Error : " + error.toString());
//                 Utils.showFailed(
//                     msg: error.toString().toLowerCase().contains("doctype")
//                         ? "Gagal Batalkan Isi Data Jamaah!"
//                         : "$error");
//                 return false;
//               });
//             },
//             noCallback: () {
//               Navigator.pop(context);
//             },
//           );
//           return false;
//         },
//         child: Container(
//           margin: EdgeInsets.only(top: 20, left: 20, right: 20),
//           child: Column(
//             children: [
//               Expanded(
//                 child: SingleChildScrollView(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text('Jenis Tabungan'),
//                       jenisTabungan(),
//                       SizedBox(height: 10),
//                       Text('Data Jamaah'),
//                       SizedBox(height: 10),
//                       listJamaahLocal.isNotEmpty
//                           ? ListView.separated(
//                               physics: NeverScrollableScrollPhysics(),
//                               shrinkWrap: true,
//                               itemBuilder: (context, index) =>
//                                   cardJamaah(index),
//                               separatorBuilder: (context, index) =>
//                                   SizedBox(height: 10),
//                               itemCount: listJamaahLocal.length,
//                             )
//                           : Center(
//                               child: Text(
//                               "Belum ada data jamaah",
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontSize: Constant.fontSizeRegular),
//                             )),
//                       SizedBox(height: 10),
//                       Container(
//                           width: double.infinity,
//                           child: CustomButton.secondaryButton('Tambah Jamaah',
//                               () async {
//                             dynamic f = await Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                   builder: (context) => TambahJamaah3View(),
//                                 ));
//                             if (f != null) {
//                               // getData();
//                             }
//                           }))
//                     ],
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.only(bottom: 16, top: 10),
//                 child: CustomButton.mainButton(
//                     'Selanjutnya',
//                     () => handleTap(() async {
//                           if (listJamaahLocal.isNotEmpty) {
//                             loading(true);
//                             await context
//                                 .read<JamaahProvider>()
//                                 .createBooking(
//                                     packageId: "${jamaahP.paketUmrohIdV}",
//                                     isGroup: !jamaahP.tabunganIndividu)
//                                 .then((value) async {
//                               loading(false);
//                               Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                     builder: (context) =>
//                                         RingkasanTabunganJamaahView(),
//                                   ));
//                             }).onError((error, stackTrace) {
//                               FirebaseCrashlytics.instance.log(
//                                   "Create Booking Add Jamaah Error : " +
//                                       error.toString());
//                               Utils.showFailed(
//                                   msg: error
//                                           .toString()
//                                           .toLowerCase()
//                                           .contains("doctype")
//                                       ? "Gagal Menambah Jamaah!"
//                                       : "$error");
//                             });
//                             loading(false);
//                           }
//                         }),
//                     color: listJamaahLocal.isNotEmpty
//                         ? Constant.primaryColor
//                         : Colors.grey),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
