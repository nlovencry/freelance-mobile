// import 'dart:developer';
// import 'dart:io';

// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/auth/provider/auth_provider.dart';
// import 'package:chatour/src/jamaah/model/add_jamaah_local_model.dart';
// import 'package:chatour/src/jamaah/provider/jamaah_provider.dart';
// import 'package:firebase_crashlytics/firebase_crashlytics.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';
// import 'package:path/path.dart' as p;

// import '../../../common/component/custom_date_picker.dart';
// import '../../../common/component/custom_dropdown.dart';
// import '../../../common/component/custom_image_picker.dart';
// import '../../../common/component/custom_textfield.dart';
// import '../../../utils/utils.dart';
// import '../../profil/provider/profile_provider.dart';
// import '../../region/model/region_model.dart';
// import '../../region/provider/region_provider.dart';

// class TambahJamaah3View extends StatefulWidget {
//   TambahJamaah3View(
//       {super.key,
//       this.addJamaahLocalModel,
//       this.addJamaahLocalFilesModel,
//       this.index});

//   final AddJamaahLocalModel? addJamaahLocalModel;
//   final AddJamaahLocalFilesModel? addJamaahLocalFilesModel;
//   final int? index;

//   @override
//   State<TambahJamaah3View> createState() => _TambahJamaah3ViewState();
// }

// class _TambahJamaah3ViewState extends BaseState<TambahJamaah3View> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     await Utils.showLoading();
//     await context.read<ProfileProvider>().fetchBank();
//     await context.read<RegionProvider>().fetchProvince();

//     setData();
//     await Utils.dismissLoading();
//   }

//   setData() async {
//     log("ADD JAMAAH LOCAL CITY: ${widget.addJamaahLocalModel?.cityId}");
//     log("ADD JAMAAH LOCAL DISTRICT: ${widget.addJamaahLocalModel?.districtId}");
//     log("ADD JAMAAH LOCAL SUBDISTRICT: ${widget.addJamaahLocalModel?.subDistrictId}");
//     log("ADD JAMAAH LOCAL PROVINCE: ${widget.addJamaahLocalModel?.provinceId}");
//     loading(true);
//     if (widget.addJamaahLocalModel != null) {
//       if (widget.addJamaahLocalModel?.provinceId.toString() != "null") {
//         await context
//             .read<RegionProvider>()
//             .fetchCity(widget.addJamaahLocalModel?.provinceId ?? "");
//       }
//       if (widget.addJamaahLocalModel?.cityId.toString() != "null") {
//         await context
//             .read<RegionProvider>()
//             .fetchDistrict(widget.addJamaahLocalModel?.cityId ?? "");
//       }
//       // await context.read<RegionProvider>().fetchSubDistrict(
//       //     widget.addJamaahLocalModel?.subDistrictId ?? "",
//       //     widget.addJamaahLocalModel?.cityId ?? "");
//     }

//     final listProvince = context.read<RegionProvider>().provinceModel.data;
//     final listCity = context.read<RegionProvider>().cityModel.data;
//     final listDistrict = context.read<RegionProvider>().districtModel.data;
//     final listSubDistrict =
//         context.read<RegionProvider>().subDistrictModel.data;
//     await context.read<JamaahProvider>().loadJamaahData(
//         widget.addJamaahLocalModel,
//         widget.addJamaahLocalFilesModel,
//         listProvince,
//         listCity,
//         listDistrict,
//         listSubDistrict);
//     loading(false);
//   }

//   String gender = 'Laki-laki';
//   bool? isChecked = false;

//   @override
//   Widget build(BuildContext context) {
//     final auth = context.watch<AuthProvider>();
//     final jamaahP = context.watch<JamaahProvider>();

//     final listBank =
//         context.watch<ProfileProvider>().bankModel.data?.banks ?? [];

//     final listProvince = context.watch<RegionProvider>().provinceModel.data;
//     final listCity = context.watch<RegionProvider>().cityModel.data;
//     final listDistrict = context.watch<RegionProvider>().districtModel.data;
//     final listSubDistrict =
//         context.watch<RegionProvider>().subDistrictModel.data;

//     Widget textField(
//         {required TextEditingController controller,
//         Widget? suffixIcon,
//         String? hintText}) {
//       return Column(
//         children: [
//           SizedBox(
//             height: 6,
//           ),
//           TextFormField(
//             cursorColor: Constant.primaryColor,
//             controller: controller,
//             style: Constant.primaryTextStyle,
//             decoration: InputDecoration(
//               isDense: true,
//               contentPadding: EdgeInsets.fromLTRB(14, 14, 14, 14),
//               hintText: hintText ?? "",
//               suffixIcon: Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: suffixIcon,
//               ),
//               suffixIconConstraints:
//                   BoxConstraints(maxHeight: 30, maxWidth: 30),
//               border: OutlineInputBorder(
//                   borderSide: BorderSide.none,
//                   borderRadius: BorderRadius.circular(10)),
//               filled: true,
//               fillColor: Colors.grey.shade200,
//             ),
//           ),
//           SizedBox(
//             height: 10,
//           )
//         ],
//       );
//     }

//     Widget form() {
//       return Form(
//         key: jamaahP.jamaahKey,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             SizedBox(height: 20),
//             CustomTextField.normalTextField(
//               controller: jamaahP.NIKC,
//               labelText: "NIK",
//               hintText: "NIK",
//               textInputType: TextInputType.number,
//               maxLength: 16,
//               inputFormatters: [
//                 FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                 FilteringTextInputFormatter.digitsOnly
//               ],
//               validator: (value) {
//                 if (value == null || value.isEmpty) {
//                   return "Maaf, NIK wajib diisi";
//                 }
//                 if (value.isNotEmpty && value.length < 6) {
//                   return "NIK harus 16 digit";
//                 }
//                 return null;
//               },
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.namaLengkapC,
//               labelText: "Nama Lengkap",
//               hintText: "Nama Lengkap",
//               textInputType: TextInputType.text,
//               textCapitalization: TextCapitalization.words,
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.namaIbuKandungC,
//               labelText: "Nama Ibu Kandung",
//               hintText: "Nama Ibu Kandung",
//               textInputType: TextInputType.text,
//               textCapitalization: TextCapitalization.words,
//               required: false,
//             ),
//             CustomTextField.normalTextField(
//               controller: jamaahP.emailC,
//               labelText: "Email",
//               hintText: "Email",
//               required: false,
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.noTelpC,
//               labelText: "No. Telp",
//               hintText: "No. Telp",
//               textInputType: TextInputType.phone,
//               prefix: Container(
//                   margin: EdgeInsets.fromLTRB(12, 12, 0, 0),
//                   child: Text("62  |")),
//               inputFormatters: [
//                 FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                 FilteringTextInputFormatter.digitsOnly,
//                 // FilteringTextInputFormatter.allow(RegExp(r'^(0|[1-9][0-9]*)$')),
//               ],
//               required: false,
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.tempatLahirC,
//               labelText: "Tempat Lahir",
//               hintText: "Tempat Lahir",
//               required: false,
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.tanggalLahirC,
//               labelText: "Tanggal Lahir",
//               hintText: "Tanggal Lahir",
//               readOnly: true,
//               onTap: () async {
//                 await jamaahP.setTanggalLahir(
//                     await CustomDatePicker.pickDate(context, DateTime.now()));
//                 FocusManager.instance.primaryFocus?.unfocus();
//               },
//               suffixIcon: Icon(Icons.calendar_month),
//               suffixIconColor: Colors.black,
//               required: false,
//             ),
//             // textField(
//             //     controller: auth.tanggalLahir,
//             //     suffixIcon: Image.asset('assets/icons/calendar.png')),
//             SizedBox(height: 10),
//             Padding(
//               padding: const EdgeInsets.only(left: 20, right: 20),
//               child: Text(
//                 "Jenis Kelamin",
//                 style: Constant.primaryTextStyle.copyWith(
//                   fontSize: 14,
//                   fontWeight: Constant.medium,
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 8),
//               child: Row(
//                 children: [
//                   Radio(
//                     value: true,
//                     groupValue: jamaahP.gender,
//                     activeColor: Constant.primaryColor,
//                     onChanged: (value) =>
//                         context.read<JamaahProvider>().gender = value,
//                   ),
//                   Text(
//                     'Laki-laki',
//                     style: Constant.primaryTextStyle,
//                   ),
//                   Radio(
//                     value: false,
//                     groupValue: jamaahP.gender,
//                     activeColor: Constant.primaryColor,
//                     onChanged: (value) =>
//                         context.read<JamaahProvider>().gender = value,
//                   ),
//                   Text(
//                     'Perempuan',
//                     style: Constant.primaryTextStyle,
//                   ),
//                 ],
//               ),
//             ),
//             CustomTextField.normalTextField(
//               controller: jamaahP.alamatC,
//               labelText: "Alamat",
//               hintText: "Alamat",
//               required: false,
//             ),
//             SizedBox(height: 10),
//             CustomDropdown.normalDropdown(
//               labelText: "Provinsi",
//               hintText: "Pilih Provinsi",
//               selectedItem: widget.addJamaahLocalModel?.provinceId == null
//                   ? null
//                   : jamaahP.provinsiNameV,
//               list: (listProvince ?? [])
//                   .map((e) => DropdownMenuItem(
//                       value: e?.province, child: Text(e?.province ?? "")))
//                   .toList(),
//               onChanged: (val) {
//                 jamaahP.kotaNameV = null;
//                 jamaahP.kotaIdV = null;
//                 jamaahP.provinsiNameV = val;
//                 jamaahP.kecamatanIdV = null;
//                 jamaahP.kecamatanNameV = null;
//                 jamaahP.desaNameV = null;
//                 jamaahP.desaIdV = null;
//                 jamaahP.provinsiIdV = (listProvince ?? [])
//                     .firstWhere((element) => element?.province == val)
//                     ?.provinceId;
//                 setState(() {});
//                 context.read<RegionProvider>().cityModel = CityModel();
//                 context
//                     .read<RegionProvider>()
//                     .fetchCity(jamaahP.provinsiIdV ?? "", withLoading: true);
//               },
//             ),
//             SizedBox(height: 10),
//             CustomDropdown.normalDropdown(
//               labelText: "Kabupaten / Kota",
//               selectedItem: widget.addJamaahLocalModel?.cityId == null
//                   ? null
//                   : jamaahP.kotaNameV,
//               hintText: "Pilih Kabupaten / Kota",
//               list: (listCity ?? [])
//                   .map((e) => DropdownMenuItem(
//                       value: e?.cityName, child: Text(e?.cityName ?? "")))
//                   .toList(),
//               onChanged: (val) {
//                 jamaahP.kecamatanIdV = null;
//                 jamaahP.kecamatanNameV = null;
//                 jamaahP.kotaNameV = val;
//                 jamaahP.kotaIdV = (listCity ?? [])
//                     .firstWhere((element) => element?.cityName == val)
//                     ?.cityId;
//                 setState(() {});

//                 context.read<RegionProvider>().districtModel = DistrictModel();
//                 context
//                     .read<RegionProvider>()
//                     .fetchDistrict(jamaahP.kotaIdV ?? "", withLoading: true);
//               },
//             ),
//             SizedBox(height: 10),
//             CustomDropdown.normalDropdown(
//               labelText: "Kecamatan",
//               selectedItem: widget.addJamaahLocalModel?.districtId == null
//                   ? null
//                   : jamaahP.kecamatanNameV,
//               hintText: "Pilih Kecamatan",
//               list: (listDistrict ?? [])
//                   .map((e) => DropdownMenuItem(
//                       value: e?.districtName,
//                       child: Text(e?.districtName ?? "")))
//                   .toList(),
//               onChanged: (val) {
//                 jamaahP.desaNameV = null;
//                 jamaahP.desaIdV = null;
//                 jamaahP.kecamatanNameV = val;
//                 jamaahP.kecamatanIdV = (listDistrict ?? [])
//                     .firstWhere((element) => element?.districtName == val)
//                     ?.districtId;
//                 setState(() {});

//                 context.read<RegionProvider>().subDistrictModel =
//                     SubDistrictModel();
//                 // context.read<RegionProvider>().fetchSubDistrict(
//                 //     jamaahP.kecamatanIdV ?? "", jamaahP.kotaIdV ?? "");
//               },
//             ),
//             // SizedBox(height: 10),
//             // CustomDropdown.normalDropdown(
//             //   labelText: "Kelurahan / Desa",
//             //   selectedItem: jamaahP.desaNameV,
//             //   hintText: "Pilih Kelurahan / Desa",
//             //   list: (listSubDistrict ?? [])
//             //       .map((e) => DropdownMenuItem(
//             //           value: e?.subdistrictName,
//             //           child: Text(e!.subdistrictName!)))
//             //       .toList(),
//             //   onChanged: (val) {
//             //     jamaahP.desaNameV = val;
//             //     jamaahP.desaIdV = (listSubDistrict ?? [])
//             //         .firstWhere((element) => element?.subdistrictName == val)
//             //         ?.subdistrictId;
//             //     setState(() {});
//             //   },
//             // ),
//             SizedBox(height: 10),
//             CustomDropdown.normalDropdown(
//               labelText: "Bank Rekening",
//               hintText: "Pilih Bank Rekening",
//               list: listBank
//                   .map((e) =>
//                       DropdownMenuItem<String>(value: e, child: Text(e ?? "")))
//                   .toList(),
//               selectedItem:
//                   widget.addJamaahLocalModel?.accBank.toString() == "null"
//                       ? null
//                       : jamaahP.bankRekV,
//               onChanged: (val) {
//                 jamaahP.bankRekV = val;
//                 setState(() {});
//               },
//               required: false,
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.noRekC,
//               labelText: "Nomor Rekening",
//               hintText: "Nomor Rekening",
//               textInputType: TextInputType.number,
//               inputFormatters: [
//                 FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                 FilteringTextInputFormatter.digitsOnly
//               ],
//               required: false,
//             ),
//             SizedBox(height: 10),
//             CustomTextField.normalTextField(
//               controller: jamaahP.atasNamaRekC,
//               labelText: "Atas Nama Rekening",
//               hintText: "Atas Nama Rekening",
//               textCapitalization: TextCapitalization.words,
//               required: false,
//             ),
//             SizedBox(height: 14),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               child: Row(
//                 children: [
//                   Icon(Icons.image, size: 24),
//                   Expanded(
//                       child: CustomButton.secondaryButton(
//                           jamaahP.pasPhotoPic != null
//                               ? p.basename(jamaahP.pasPhotoPic!.path)
//                               : 'Upload Pas Foto', () async {
//                     var file = await CustomImagePicker.cameraOrGallery(context);
//                     if (file != null) {
//                       jamaahP.pasPhotoPic = File(file.path);
//                     }
//                   }, margin: EdgeInsets.only(left: 10)))
//                 ],
//               ),
//             ),
//             SizedBox(height: 14),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               child: Row(
//                 children: [
//                   Icon(Icons.image, size: 24),
//                   Expanded(
//                       child: CustomButton.secondaryButton(
//                           jamaahP.ktpPic != null
//                               ? p.basename(jamaahP.ktpPic!.path)
//                               : 'Upload Foto KTP', () async {
//                     var file = await CustomImagePicker.cameraOrGallery(context);
//                     if (file != null) {
//                       jamaahP.ktpPic = File(file.path);
//                     }
//                   }, margin: EdgeInsets.only(left: 10)))
//                 ],
//               ),
//             ),
//             SizedBox(height: 12),
//             (((jamaahP.tabunganIndividu ?? true) == true ||
//                         jamaahP.listJamaahLocal
//                                 .where((element) => element.isLeader == "1")
//                                 .toList()
//                                 .isNotEmpty &&
//                             jamaahP.listJamaahLocal[widget.index ?? 0]
//                                     .isLeader ==
//                                 "0") ||
//                     (widget.index == null &&
//                         jamaahP.listJamaahLocal
//                             .where((element) => element.isLeader == "1")
//                             .toList()
//                             .isNotEmpty))
//                 ? SizedBox()
//                 : Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 20),
//                     child: Row(
//                       children: [
//                         SizedBox(
//                           width: 20,
//                           height: 20,
//                           child: Checkbox(
//                             value: jamaahP.teamleader,
//                             shape: CircleBorder(),
//                             fillColor: MaterialStateProperty.all(
//                                 Constant.primaryColor),
//                             onChanged: (check) {
//                               setState(() {
//                                 jamaahP.teamleader = check;
//                               });
//                             },
//                           ),
//                         ),
//                         SizedBox(width: 12),
//                         Text('Team Leader')
//                       ],
//                     ),
//                   ),
//             SizedBox(height: 24),
//             CustomButton.mainButton(
//                 'Simpan',
//                 () => handleTap(() async {
//                       if (widget.index != null) {
//                         await context
//                             .read<JamaahProvider>()
//                             .editJamaah(widget.index ?? 0)
//                             .then((value) async {
//                           // await Utils.showSuccess(msg: "Sukses Menambah Jamaah");
//                           // Future.delayed(Duration(seconds: 3), () {
//                           Navigator.pop(context, true);
//                           // });
//                         }).onError((error, stackTrace) {
//                           FirebaseCrashlytics.instance.log(
//                               "Edit Jamaah Local Error : " + error.toString());
//                           Utils.showFailed(
//                               msg: error
//                                       .toString()
//                                       .toLowerCase()
//                                       .contains("doctype")
//                                   ? "Gagal Edit Jamaah!"
//                                   : "$error");
//                         });
//                       } else {
//                         await context
//                             .read<JamaahProvider>()
//                             .addJamaah()
//                             .then((value) async {
//                           // await Utils.showSuccess(msg: "Sukses Menambah Jamaah");
//                           // Future.delayed(Duration(seconds: 3), () {
//                           Navigator.pop(context, true);
//                           // });
//                         }).onError((error, stackTrace) {
//                           FirebaseCrashlytics.instance.log(
//                               "Tambah Jamaah Local Error : " +
//                                   error.toString());
//                           Utils.showFailed(
//                               msg: error
//                                       .toString()
//                                       .toLowerCase()
//                                       .contains("doctype")
//                                   ? "Gagal Menambah Jamaah!"
//                                   : "$error");
//                         });
//                       }
//                     }),
//                 margin: EdgeInsets.symmetric(horizontal: 20)),
//             SizedBox(height: 24),
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       appBar: CustomAppBar.appBar(
//           widget.index != null ? 'Edit Data Jamaah' : 'Masukkan Data Jamaah',
//           isLeading: true,
//           isCenter: true,
//           color: Colors.black),
//       body: WillPopScope(
//           onWillPop: () async {
//             if (widget.index != null) {
//               jamaahP.clearJamaah();
//               return true;
//             }
//             await Utils.showYesNoDialog(
//               context: context,
//               title: "Batalkan Isi Data Jamaah",
//               desc: 'Apakah Anda yakin ingin membatalkan isi data jamaah?',
//               yesCallback: () async {
//                 await context
//                     .read<JamaahProvider>()
//                     .clearJamaah()
//                     .then((value) {
//                   Navigator.of(context)
//                     ..pop()
//                     ..pop();
//                   return true;
//                 }).onError((error, stackTrace) {
//                   FirebaseCrashlytics.instance
//                       .log("Cancel Tambah Jamaah Error : " + error.toString());
//                   Utils.showFailed(
//                       msg: error.toString().toLowerCase().contains("doctype")
//                           ? "Gagal Batalkan Isi Data Jamaah!"
//                           : "$error");
//                   return false;
//                 });
//               },
//               noCallback: () {
//                 Navigator.pop(context);
//               },
//             );
//             return false;
//           },
//           child: ListView(children: [form()])),
//     );
//   }
// }
