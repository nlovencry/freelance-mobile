// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/auth/provider/auth_provider.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// class TambahJamaah4View extends StatefulWidget {
//   @override
//   State<TambahJamaah4View> createState() => _TambahJamaah4ViewState();
// }

// class _TambahJamaah4ViewState extends State<TambahJamaah4View> {
//   String gender = 'Laki-laki';
//   bool? isChecked = false;

//   @override
//   Widget build(BuildContext context) {
//     final auth = context.watch<AuthProvider>();

//     Widget textField(
//         {required TextEditingController controller,
//         Widget? suffixIcon,
//         String? hintText}) {
//       return Column(
//         children: [
//           SizedBox(
//             height: 6,
//           ),
//           TextFormField(
//             cursorColor: Constant.primaryColor,
//             controller: controller,
//             style: Constant.primaryTextStyle,
//             decoration: InputDecoration(
//               isDense: true,
//               contentPadding: EdgeInsets.fromLTRB(14, 14, 14, 14),
//               hintText: hintText ?? "",
//               suffixIcon: Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: suffixIcon,
//               ),
//               suffixIconConstraints:
//                   BoxConstraints(maxHeight: 30, maxWidth: 30),
//               border: OutlineInputBorder(
//                   borderSide: BorderSide.none,
//                   borderRadius: BorderRadius.circular(10)),
//               filled: true,
//               fillColor: Colors.grey.shade200,
//             ),
//           ),
//           SizedBox(
//             height: 10,
//           )
//         ],
//       );
//     }

//     Widget form() {
//       return Container(
//         margin: EdgeInsets.only(top: 20, left: 20, right: 20),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('NIK'),
//             textField(controller: auth.NIKC),
//             Text('Nama Lengkap Sesuai KTP'),
//             textField(controller: auth.namaLengkap),
//             Text('Nama Ibu Kandung'),
//             textField(controller: auth.namaIbuKAndung),
//             Text('Email'),
//             textField(controller: auth.Email),
//             Text('No. Telp'),
//             textField(controller: auth.noTelp),
//             Text('Tempat Lahir'),
//             textField(controller: auth.tempatLahir),
//             Text('Tanggal Lahir'),
//             textField(
//                 controller: auth.tanggalLahir,
//                 suffixIcon: Image.asset('assets/icons/calendar.png')),
//             Row(
//               children: [
//                 Radio(
//                   value: 'Laki-laki',
//                   groupValue: gender,
//                   activeColor: Constant.primaryColor,
//                   onChanged: (value) {
//                     setState(() {
//                       gender = value.toString();
//                     });
//                   },
//                 ),
//                 Text(
//                   'Laki-laki',
//                   style: Constant.primaryTextStyle,
//                 ),
//                 Radio(
//                   value: "Perempuan",
//                   groupValue: gender,
//                   activeColor: Constant.primaryColor,
//                   onChanged: (value) {
//                     setState(() {
//                       gender = value.toString();
//                     });
//                   },
//                 ),
//                 Text(
//                   'Perempuan',
//                   style: Constant.primaryTextStyle,
//                 ),
//               ],
//             ),
//             Text('Alamat'),
//             textField(controller: auth.alamat),
//             Text('Provinsi'),
//             textField(controller: auth.provinsi),
//             Text('Kabupaten / Kota'),
//             textField(controller: auth.kabupaten),
//             Text('Kecamatan'),
//             textField(controller: auth.kecamatan),
//             Text('Kelurahan / Desa'),
//             textField(controller: auth.kelurahan),
//             Text('Bank Rekening'),
//             textField(controller: auth.bank),
//             Text('Nomor Rekening'),
//             textField(controller: auth.nomorRekening),
//             Text('Atas Nama Rekening'),
//             textField(controller: auth.atasNamaRekening),
//             SizedBox(
//               height: 14,
//             ),
//             Row(
//               children: [
//                 Icon(
//                   Icons.image,
//                   size: 24,
//                 ),
//                 Expanded(
//                     child: CustomButton.secondaryButton(
//                         'Upload Pas Foto', () {},
//                         margin: EdgeInsets.only(left: 10)))
//               ],
//             ),
//             SizedBox(
//               height: 14,
//             ),
//             Row(
//               children: [
//                 Icon(
//                   Icons.image,
//                   size: 24,
//                 ),
//                 Expanded(
//                     child: CustomButton.secondaryButton(
//                         'Upload Foto KTP', () {},
//                         margin: EdgeInsets.only(left: 10)))
//               ],
//             ),
//             Row(
//               children: [
//                 Checkbox(
//                   value: isChecked,
//                   shape: CircleBorder(),
//                   fillColor: MaterialStateProperty.all(Constant.primaryColor),
//                   onChanged: (check) {
//                     setState(() {
//                       isChecked = check;
//                     });
//                   },
//                 ),
//                 Text('Team Leader')
//               ],
//             ),
//             SizedBox(
//               height: 24,
//             ),
//             CustomButton.mainButton('Simpan', () {})
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       appBar: CustomAppBar.appBar('Data Jamaah',
//           isLeading: true, isCenter: true, color: Colors.black),
//       body: ListView(
//         children: [form()],
//       ),
//     );
//   }
// }
