// import 'dart:convert';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/komisi/model/riwayat_penarikan_komisi_detail_model.dart';
// import 'package:flutter/material.dart';

// class DetailPenarikanKomisiProvider extends BaseController with ChangeNotifier {
//   RiwayatPenarikanKomisiDetailModel _riwayatPenarikanKomisiDetailModel =
//       RiwayatPenarikanKomisiDetailModel();
//   RiwayatPenarikanKomisiDetailModel get riwayatPenarikanKomisiDetailModel =>
//       this._riwayatPenarikanKomisiDetailModel;

//   set riwayatPenarikanKomisiDetailModel(
//           RiwayatPenarikanKomisiDetailModel value) =>
//       this._riwayatPenarikanKomisiDetailModel = value;

//   Future<void> fetchDetailKomisi(int id) async {
//     loading(true);
//     final response =
//         await get(Constant.BASE_API_FULL + '/agen/commission/submission-detail/${id}');

//     if (response.statusCode == 200) {
//       final model = RiwayatPenarikanKomisiDetailModel.fromJson(jsonDecode(response.body));
//       riwayatPenarikanKomisiDetailModel = model;
//       notifyListeners();
//       loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }
// }
