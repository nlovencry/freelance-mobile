// import 'dart:convert';

// import 'package:chatour/src/komisi/model/komisi_model.dart';
// import 'package:flutter/material.dart';

// import '../../../common/base/base_controller.dart';
// import '../../../common/base/base_response.dart';
// import '../../../common/helper/constant.dart';
// import '../model/komisi_detail_model.dart';

// class KomisiProvider extends BaseController with ChangeNotifier {
//   KomisiModel _komisiModel = KomisiModel();
//   KomisiModel get komisiModel => this._komisiModel;

//   set komisiModel(KomisiModel value) {
//     this._komisiModel = value;
//     String v = komisiModel.data?.commissionBalance?.replaceAll(".", "") ?? "";
//     v = v.replaceAll("Rp", "");
//     v = v.trim();
//     allNominalPenarikan = int.parse(v);
//     notifyListeners();
//   }

//   KomisiDetailModel _komisiDetailModel = KomisiDetailModel();
//   KomisiDetailModel get komisiDetailModel => this._komisiDetailModel;

//   set komisiDetailModel(KomisiDetailModel value) {
//     this._komisiDetailModel = value;
//     notifyListeners();
//   }

//   int allNominalPenarikan = 0;
//   int get getNominalPenarikan => this.allNominalPenarikan;

//   bool _komisi0 = false;
//   bool get komisi0 => this._komisi0;

//   set komisi0(bool value) {
//     this._komisi0 = value;
//     notifyListeners();
//   }

//   set setNominalPenarikan(int allNominalPenarikan) {
//     this.allNominalPenarikan = allNominalPenarikan;
//     notifyListeners();
//   }

//   Future<void> fetchKomisi({bool withLoading = false}) async {
//     if (withLoading) loading(true);
//     final response =
//         await get(Constant.BASE_API_FULL + '/agen/commission/list');

//     if (response.statusCode == 200) {
//       final model = KomisiModel.fromJson(jsonDecode(response.body));
//       komisiModel = model;
//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   Future<void> fetchDetailKomisi(
//       {bool withLoading = false, required int adminId}) async {
//     if (withLoading) loading(true);
//     Map<String, String> param = {'admin_id': adminId.toString()};
//     final response = await get(
//         Constant.BASE_API_FULL + '/agen/commission/detail',
//         query: param);

//     if (response.statusCode == 200) {
//       final model = KomisiDetailModel.fromJson(jsonDecode(response.body));
//       komisiDetailModel = model;
//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }
// }
