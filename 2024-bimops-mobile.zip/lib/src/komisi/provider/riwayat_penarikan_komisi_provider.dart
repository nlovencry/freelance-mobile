// import 'dart:convert';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/komisi/model/riwayat_penarikan_komisi_detail_model.dart';
// import 'package:chatour/src/komisi/model/riwayat_penarikan_komisi_model.dart';
// import 'package:flutter/material.dart';

// class RiwayatPenarikanKomisiProvider extends BaseController
//     with ChangeNotifier {
//   RiwayatPenarikanKomisiModel _riwayat = RiwayatPenarikanKomisiModel();
//   RiwayatPenarikanKomisiModel get riwayat => this._riwayat;

//   set riwayat(RiwayatPenarikanKomisiModel value) {
//     this._riwayat = value;
//     notifyListeners();
//   }

//   Future<void> fetchRiwayatPenarikan(
//       {bool withLoading = false, int? adminId}) async {
//     if (withLoading) loading(true);
//     Map<String, String> param = {};
//     if (adminId != null) {
//       param.addAll({'admin_id': adminId.toString()});
//     }
//     final response = await get(
//         Constant.BASE_API_FULL + '/agen/commission/submission-history',
//         query: adminId != null ? param : null);

//     if (response.statusCode == 200) {
//       final model =
//           RiwayatPenarikanKomisiModel.fromJson(jsonDecode(response.body));
//       riwayat = model;
//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }
// }
