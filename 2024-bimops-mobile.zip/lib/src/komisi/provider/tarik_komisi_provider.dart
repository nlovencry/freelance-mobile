// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/base/base_response.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';

// class TarikKomisiProvider extends BaseController with ChangeNotifier {
//   TextEditingController nominal = TextEditingController();

//   GlobalKey<FormState> tarikKomisiKey = GlobalKey<FormState>();

//   int nominalPenarikan = 0;
//   int get getNominalPenarikan => this.nominalPenarikan;

//   set setNominalPenarikan(int nominalPenarikan) {
//     this.nominalPenarikan = nominalPenarikan;
//     notifyListeners();
//   }

//   Future<void> tarikKomisi() async {
//     loading(true);
//     if (tarikKomisiKey.currentState!.validate()) {
//       String amount = nominal.text.replaceAll(".", "");
//       Map<String, String> param = {
//         'amount': amount,
//         'payment_method': '1',
//         // 'bank_account_no': '123456',
//         // 'bank_account_name': 'Budi darmawan',
//         // 'bank_name': 'mandiri'
//       };
//       final response = BaseResponse.from(await post(
//           Constant.BASE_API_FULL + '/agen/commission/submission',
//           body: param));

//       if (response.success) {
//         loading(false);
//       } else {
//         loading(false);
//         throw Exception(response.message);
//       }
//       nominal.clear();
//     } else {
//       loading(false);
//       throw 'Harap Lengkapi Form';
//     }
//   }
// }
