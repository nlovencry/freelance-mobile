// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/common/helper/safe_network_image.dart';
// import 'package:chatour/common/helper/scroll_listener.dart';
// import 'package:chatour/src/komisi/provider/detail_penarikan_komisi_provider.dart';
// import 'package:chatour/src/komisi/provider/riwayat_penarikan_komisi_provider.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../../common/base/base_state.dart';
// import '../provider/komisi_provider.dart';

// class DetailPenarikanKomisiView extends StatefulWidget {
//   // const DetailPenarikanKomisiView({super.key, required this.adminId});
//   // final String adminId;

//   const DetailPenarikanKomisiView({super.key, required this.id});

//   static Widget create(int id) => ChangeNotifierProvider<ScrollListener>(
//       create: (context) => ScrollListener.initialise(ScrollController()),
//       child: DetailPenarikanKomisiView(id: id));

//   final int id;

//   @override
//   State<DetailPenarikanKomisiView> createState() =>
//       _DetailPenarikanKomisiViewState();
// }

// class _DetailPenarikanKomisiViewState
//     extends BaseState<DetailPenarikanKomisiView> {
//   getData() async {
//     loading(true);
//     context.read<DetailPenarikanKomisiProvider>().fetchDetailKomisi(widget.id);
//     // context.read<KomisiProvider>().fetchDetailKomisi(adminId: widget.adminId);
//     loading(false);
//   }

//   @override
//   void initState() {
//     getData();
//     // TODO: implement initState
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final detailKomisi = context
//         .watch<DetailPenarikanKomisiProvider>()
//         .riwayatPenarikanKomisiDetailModel
//         .data;
//     // final
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Detail Penarikan Komisi',
//         color: Colors.black,
//         // action: [
//         //   Padding(
//         //     padding: const EdgeInsets.only(right: 8),
//         //     child: Icon(Icons.list),
//         //   )
//         // ],
//         isLeading: true,
//         isCenter: true,
//       );
//     }

//     Widget rowAgen(String txt1, String txt2) {
//       return Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Expanded(
//             flex: 5,
//             child: Text(txt1, style: Constant.primaryTextStyle),
//           ),
//           SizedBox(width: 8),
//           Expanded(
//             flex: 5,
//             child: Text(
//               txt2,
//               overflow: TextOverflow.ellipsis,
//               maxLines: 2,
//               textAlign: TextAlign.right,
//               style: Constant.primaryTextStyle
//                   .copyWith(fontWeight: Constant.semibold),
//             ),
//           ),
//         ],
//       );
//     }

//     Widget cardAgen() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         margin: EdgeInsets.only(top: 8, left: 4, right: 4),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             rowAgen('Nama', detailKomisi?.name ?? "-"),
//             SizedBox(height: 8),
//             rowAgen('ID Agen', "${detailKomisi?.id ?? 0}"),
//             SizedBox(height: 8),
//             rowAgen('Tanggal Pengajuan', detailKomisi?.submissionDate ?? "-"),
//             SizedBox(height: 8),
//             rowAgen('Nominal Penarikan', detailKomisi?.amount ?? "Rp 0"),
//             SizedBox(height: 8),
//             rowAgen('Status', detailKomisi?.status ?? "-"),
//           ],
//         ),
//       );
//     }

//     Widget cardRekening() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         margin: EdgeInsets.only(top: 8, left: 4, right: 4),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             rowAgen("Nama Bank", "${detailKomisi?.bankName ?? "-"}"),
//             SizedBox(height: 8),
//             rowAgen(
//                 "Pemilik Rekening", "${detailKomisi?.bankAccountName ?? "-"}"),
//             SizedBox(height: 8),
//             rowAgen("No Rekening", "${detailKomisi?.bankAccountNo ?? "-"}"),
//           ],
//         ),
//       );
//     }

//     Widget cardPembayaran() {
//       return CustomContainer.mainCard(
//         isShadow: true,
//         margin: EdgeInsets.only(top: 8, left: 4, right: 4),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Row(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Expanded(
//                   flex: 5,
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text('Tanggal Pembayaran',
//                           style: Constant.primaryTextStyle),
//                       SizedBox(height: 8),
//                       Text('Bukti Pembayaran',
//                           style: Constant.primaryTextStyle),
//                     ],
//                   ),
//                 ),
//                 SizedBox(width: 8),
//                 Expanded(
//                   flex: 5,
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.end,
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     children: [
//                       Row(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           Flexible(
//                             child: Text(
//                               '${detailKomisi?.paymentDate ?? "-"}',
//                               overflow: TextOverflow.ellipsis,
//                               maxLines: 2,
//                               textAlign: TextAlign.right,
//                               style: Constant.primaryTextStyle
//                                   .copyWith(fontWeight: Constant.bold),
//                             ),
//                           ),
//                         ],
//                       ),
//                       Row(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           Flexible(
//                             child: SafeNetworkImage(
//                               width: 96,
//                               height: 96,
//                               url: detailKomisi?.proofOfPayments ?? "-",
//                               errorBuilder: Image.asset(
//                                   'assets/images/Image.png',
//                                   height: 96,
//                                   width: 96),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       body: RefreshIndicator(
//         color: Constant.primaryColor,
//         onRefresh: () async {
//           // await context.watch<KomisiProvider>().fetchDetailKomisi(adminId: widget.adminId);
//         },
//         child: ListView(
//           children: [
//             header(),
//             cardAgen(),
//             cardRekening(),
//             cardPembayaran(),
//           ],
//         ),
//       ),
//     );
//   }
// }
