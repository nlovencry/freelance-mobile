// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/komisi/view/tarik_komisi_view.dart';
// import 'package:chatour/utils/Utils.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';

// import '../../../common/base/base_state.dart';
// import '../provider/komisi_provider.dart';
// import 'detail_penarikan_komisi_view.dart';
// import 'riwayat_penarikan_komisi_view.dart';

// class KomisiSubAgenView extends StatefulWidget {
//   const KomisiSubAgenView({super.key, required this.adminId});

//   final int adminId;

//   @override
//   State<KomisiSubAgenView> createState() => _KomisiSubAgenViewState();
// }

// class _KomisiSubAgenViewState extends BaseState<KomisiSubAgenView> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     loading(true);
//     await context
//         .read<KomisiProvider>()
//         .fetchDetailKomisi(adminId: widget.adminId);
//     loading(false);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final komisiP = context.watch<KomisiProvider>().komisiDetailModel.data;
//     final komisiZ = context.watch<KomisiProvider>();
//     // PreferredSizeWidget header() {
//     //   return CustomAppBar.appBar(
//     //     'Komisi Agen',
//     //     action: [
//     //       GestureDetector(
//     //         child: Padding(
//     //           padding: const EdgeInsets.only(right: 8),
//     //           child: Icon(Icons.access_time_rounded),
//     //         ),
//     //         onTap: () {
//     //           Navigator.push(context, MaterialPageRoute(builder: (c) {
//     //             return RiwayatPenarikanKomisiView();
//     //           }));
//     //         },
//     //       )
//     //     ],
//     //     isLeading: false,
//     //     isCenter: true,
//     //   );
//     // }

//     Widget header() {
//       // return SafeArea(
//       return AppBar(
//         centerTitle: true,
//         elevation: 0,
//         backgroundColor: Colors.transparent,
//         title: Text(
//             'Komisi ${(komisiP?.detail ?? []).isEmpty ? "Sub Agen" : (komisiP?.detail?.first?.name ?? "Sub Agen")}'),
//         actions: [
//           GestureDetector(
//             onTap: () {
//               Navigator.of(context).push(MaterialPageRoute(
//                 builder: (context) =>
//                     RiwayatPenarikanKomisiView(adminId: widget.adminId),
//               ));
//             },
//             child: Padding(
//               padding: EdgeInsets.only(right: 8),
//               child: SizedBox(
//                 width: 30,
//                 height: 30,
//                 child: FittedBox(
//                   child: Image.asset(
//                     'assets/icons/histori 1.png',
//                     fit: BoxFit.cover,
//                   ),
//                 ),
//               ),
//             ),
//           )
//         ],
//         // child: Container(
//         //   margin: EdgeInsets.only(top: 10),
//         //   // width: double.infinity,
//         //   height: 56,
//         //   child: Row(
//         //     mainAxisAlignment: MainAxisAlignment.center,
//         //     children: [
//         //       // Expanded(
//         //       //   flex: 1,
//         //       //   child: Text(''),
//         //       // ),
//         //       Expanded(
//         //         flex: 9,
//         //         child: Row(
//         //           mainAxisAlignment: MainAxisAlignment.end,
//         //           children: [
//         //             Text(
//         //               'Komisi Agen',
//         //               style: Constant.primaryTextStyle
//         //                   .copyWith(fontSize: 18, color: Colors.white),
//         //             ),
//         //           ],
//         //         ),
//         //       ),
//         //       Expanded(
//         //         flex: 5,
//         //         child: Row(
//         //           mainAxisAlignment: MainAxisAlignment.end,
//         //           children: [
//         //             Container(
//         //               height: 30,
//         //               width: 30,
//         //               child: Image.asset(
//         //                 'assets/icons/histori 1.png',
//         //                 fit: BoxFit.cover,
//         //               ),
//         //             ),
//         //           ],
//         //         ),
//         //       ),
//         //     ],
//         //   ),
//         // ),
//       );
//       // );
//     }

//     Widget saldoMenu() {
//       return Container(
//         margin: EdgeInsets.only(top: 8, left: 10, right: 10),
//         height: 15.h,
//         width: double.infinity,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             Container(
//               margin: EdgeInsets.only(left: 20, top: 3, right: 20),
//               child: Text(
//                 'Saldo Komisi',
//                 style: Constant.primaryTextStyle.copyWith(
//                     fontSize: 18,
//                     fontWeight: Constant.medium,
//                     color: Color(0xFFFFCC47)),
//               ),
//             ),
//             SizedBox(height: 3),
//             Container(
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Container(
//                     height: 40,
//                     margin: EdgeInsets.only(top: 18),
//                     child: Text(
//                       komisiP?.commissionBalance ?? "0",
//                       style: Constant.s12BoldBlack
//                           .copyWith(fontSize: 30, color: Colors.white),
//                     ),
//                   )
//                 ],
//               ),
//             ),
//           ],
//         ),
//       );
//     }

//     Widget komisiButton() {
//       return GestureDetector(
//         onTap: () async {
//           Navigator.of(context).push(MaterialPageRoute(
//             builder: (context) => TarikKomisiView(),
//           ));
//         },
//         child: Container(
//             margin: EdgeInsets.only(top: 50, left: 100, right: 100),
//             padding: EdgeInsets.only(right: 31, left: 31),
//             height: 42,
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(20),
//               color: Colors.white,
//             ),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       height: 40,
//                       width: 40,
//                       child: Image.asset(
//                         'assets/icons/Tarik Komisi.png',
//                         fit: BoxFit.cover,
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     Expanded(
//                       child: Text(
//                         'Tarik Komisi',
//                         style: Constant.primaryTextStyle.copyWith(fontSize: 14),
//                       ),
//                     )
//                   ],
//                 )
//               ],
//             )),
//       );
//     }

//     Widget komisiTitle() {
//       return Container(
//         margin: EdgeInsets.only(left: 10, top: 16),
//         child: Text(
//           'Riwayat Saldo Komisi',
//           style: Constant.primaryTextStyle
//               .copyWith(fontSize: 16, fontWeight: Constant.semibold),
//         ),
//       );
//     }

//     Widget komisiList(int index) {
//       final item = komisiP?.detail?[index];
//       return InkWell(
//         onTap: () async {
//           if (item?.type == "withdrawal") {
//             Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) =>
//                       DetailPenarikanKomisiView.create(item?.id ?? 0),
//                 ));
//           }
//         },
//         child: Column(
//           children: [
//             CustomContainer.mainCard(
//               isShadow: true,
//               margin: EdgeInsets.only(top: 8, left: 10, right: 10),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Row(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       SizedBox(
//                         width: 30,
//                         height: 30,
//                         child: Image.asset(item?.type == "withdrawal"
//                             ? 'assets/icons/Tarik Komisi.png'
//                             : 'assets/icons/komisi pendaftaran 2.png'),
//                       ),
//                       SizedBox(width: 6),
//                       Expanded(
//                         flex: 5,
//                         child: Column(
//                           mainAxisSize: MainAxisSize.min,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Text(
//                               (item?.type ?? "-") == "withdrawal"
//                                   ? "Penarikan Komisi"
//                                   : "Komisi Pendaftaran",
//                               style:
//                                   Constant.s12BoldBlack.copyWith(fontSize: 16),
//                             ),
//                             SizedBox(height: 3),
//                             (item?.type ?? "-") == "withdrawal"
//                                 ? SizedBox()
//                                 : Padding(
//                                     padding: const EdgeInsets.only(bottom: 3),
//                                     child: Text(
//                                       item?.desc ?? "-",
//                                       style: Constant.primaryTextStyle.copyWith(
//                                           fontWeight: Constant.semibold),
//                                     ),
//                                   ),
//                             Row(
//                               mainAxisSize: MainAxisSize.min,
//                               children: [
//                                 Expanded(
//                                   flex: 9,
//                                   child: Text(
//                                     item?.dates ?? "-",
//                                     maxLines: 1,
//                                     overflow: TextOverflow.ellipsis,
//                                     style: Constant.primaryTextStyle
//                                         .copyWith(fontSize: 12),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                       Expanded(
//                         flex: 3,
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           crossAxisAlignment: CrossAxisAlignment.end,
//                           children: [
//                             Row(
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 Flexible(
//                                   child: Text(
//                                     '${item?.type == "withdrawal" ? "-" : "+"} ${item?.amount ?? "-"}',
//                                     overflow: TextOverflow.ellipsis,
//                                     maxLines: 2,
//                                     textAlign: TextAlign.right,
//                                     style: Constant.primaryTextStyle.copyWith(
//                                         fontWeight: Constant.semibold,
//                                         color: item?.type == "withdrawal"
//                                             ? Constant.primaryColor
//                                             : Constant.textPriceColor),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       body: SafeArea(
//         top: true,
//         child: Container(
//           color: Colors.white,
//           child: RefreshIndicator(
//             color: Constant.primaryColor,
//             onRefresh: () async {
//               await context.read<KomisiProvider>().fetchKomisi();
//             },
//             child: ListView(
//               shrinkWrap: true,
//               children: [
//                 Container(
//                   height: 28.h,
//                   child: Stack(
//                     children: [
//                       Container(
//                         width: 100.w,
//                         height: 28.h,
//                         child: ClipRRect(
//                           borderRadius: BorderRadius.only(
//                               bottomLeft: Radius.circular(16),
//                               bottomRight: Radius.circular(16)),
//                           child: Image.asset(
//                             'assets/images/BG Home.png',
//                             fit: BoxFit.fitWidth,
//                           ),
//                         ),
//                       ),
//                       Positioned(top: 1.h, left: 0, right: 0, child: header()),
//                       Positioned(
//                           top: 10.h, left: 0, right: 0, child: saldoMenu()),
//                       // Positioned(
//                       //     top: 18.h, left: 0, right: 0, child: komisiButton()),
//                     ],
//                   ),
//                 ),
//                 komisiTitle(),
//                 (komisiP?.detail ?? []).isEmpty
//                     ? Padding(
//                         padding: EdgeInsets.only(top: 64),
//                         child: Utils.notFoundImage(),
//                       )
//                     : ListView.separated(
//                         physics: NeverScrollableScrollPhysics(),
//                         shrinkWrap: true,
//                         itemCount: komisiP?.detail?.length ?? 0,
//                         itemBuilder: (context, index) {
//                           return komisiList(index);
//                         },
//                         separatorBuilder: (context, index) {
//                           return SizedBox();
//                         },
//                       ),
//                 SizedBox(
//                   height: 24,
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
