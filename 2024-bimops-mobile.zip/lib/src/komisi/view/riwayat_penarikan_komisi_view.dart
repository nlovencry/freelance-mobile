// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/komisi/provider/riwayat_penarikan_komisi_provider.dart';
// import 'package:provider/provider.dart';
// import 'detail_penarikan_komisi_view.dart';
// import 'package:flutter/material.dart';

// class RiwayatPenarikanKomisiView extends StatefulWidget {
//   RiwayatPenarikanKomisiView({super.key, this.adminId});

//   int? adminId;

//   @override
//   State<RiwayatPenarikanKomisiView> createState() =>
//       _RiwayatPenarikanKomisiViewState();
// }

// class _RiwayatPenarikanKomisiViewState
//     extends BaseState<RiwayatPenarikanKomisiView> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     loading(true);
//     await context
//         .read<RiwayatPenarikanKomisiProvider>()
//         .fetchRiwayatPenarikan(adminId: widget.adminId);
//     loading(false);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final f1 = context.watch<RiwayatPenarikanKomisiProvider>().riwayat.data;
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Riwayat Penarikan Komisi',
//         color: Colors.black,
//         isLeading: true,
//         isCenter: true,
//       );
//     }

//     Widget cardRiwayat() {
//       return ListView.builder(
//         // physics: NeverScrollableScrollPhysics(),
//         shrinkWrap: true,
//         itemBuilder: (context, index) {
//           final riwayat = f1?[index];
//           return GestureDetector(
//             onTap: () {
//               Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) =>
//                         DetailPenarikanKomisiView.create(riwayat?.id ?? 0),
//                   ));
//             },
//             child: CustomContainer.mainCard(
//               isShadow: true,
//               margin: EdgeInsets.only(top: 8, left: 8, right: 8),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Row(
//                     children: [
//                       Text(
//                         '${riwayat?.dates}',
//                         style: Constant.primaryTextStyle,
//                       ),
//                       Spacer(),
//                       Text('${riwayat?.status}')
//                     ],
//                   ),
//                   SizedBox(
//                     height: 4,
//                   ),
//                   Text(
//                     '${riwayat?.amount}',
//                     style: Constant.primaryTextStyle.copyWith(
//                       fontWeight: Constant.semibold,
//                     ),
//                   ),
//                   SizedBox(
//                     height: 4,
//                   ),
//                   Text(
//                     '${riwayat?.paymentMethod}',
//                     style: Constant.primaryTextStyle,
//                   )
//                 ],
//               ),
//             ),
//           );
//         },
//         itemCount: f1?.length ?? 0,
//       );
//     }

//     return Scaffold(
//       appBar: header(),
//       body: Container(
//           child: SingleChildScrollView(
//         child: RefreshIndicator(
//             color: Constant.primaryColor,
//             onRefresh: () async {
//               await context
//                   .read<RiwayatPenarikanKomisiProvider>()
//                   .fetchRiwayatPenarikan();
//             },
//             child: cardRiwayat()),
//       )),
//     );
//   }
// }
