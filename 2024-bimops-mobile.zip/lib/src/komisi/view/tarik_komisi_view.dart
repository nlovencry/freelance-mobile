// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_textfield.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/komisi/provider/tarik_komisi_provider.dart';
// import 'package:chatour/utils/utils.dart';
// import 'package:firebase_crashlytics/firebase_crashlytics.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:intl/intl.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';

// import '../provider/komisi_provider.dart';

// class TarikKomisiView extends StatefulWidget {
//   const TarikKomisiView({super.key});

//   @override
//   State<TarikKomisiView> createState() => _TarikKomisiViewState();
// }

// class _TarikKomisiViewState extends BaseState<TarikKomisiView> {
//   @override
//   void initState() {
//     getData();
//     super.initState();
//   }

//   getData() async {
//     loading(true);
//     await context.read<KomisiProvider>().fetchKomisi();
//     loading(false);
//   }

//   static String thousandSeparator(int val) {
//     return NumberFormat.currency(locale: "in_ID", symbol: "", decimalDigits: 0)
//         .format(val);
//   }

//   @override
//   Widget build(BuildContext context) {
//     setState(() {});
//     final tarikKomisiP = context.watch<TarikKomisiProvider>();
//     final komisiModelP = context.watch<KomisiProvider>().komisiModel.data;
//     final komisiP = context.watch<KomisiProvider>();

//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Tarik Komisi',
//         color: Colors.black,
//         // action: [
//         //   Padding(
//         //     padding: const EdgeInsets.only(right: 8),
//         //     child: Icon(Icons.list),
//         //   )
//         // ],
//         isLeading: true,
//         isCenter: true,
//       );
//     }

//     Widget saldoMenu() {
//       return Container(
//         margin: EdgeInsets.only(top: 40, left: 10, right: 10),
//         height: 15.h,
//         width: double.infinity,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             Container(
//               margin: EdgeInsets.only(left: 20, top: 3, right: 20),
//               child: Text(
//                 'Saldo Komisi',
//                 style: Constant.primaryTextStyle.copyWith(
//                     fontSize: 18,
//                     fontWeight: Constant.medium,
//                     color: Colors.black),
//               ),
//             ),
//             SizedBox(height: 3),
//             Container(
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Container(
//                     height: 40,
//                     margin: EdgeInsets.only(top: 18),
//                     child: Text(
//                       komisiModelP?.commissionBalance ?? "-",
//                       style: Constant.s12BoldBlack
//                           .copyWith(fontSize: 30, color: Colors.black),
//                     ),
//                   ),
//                   SizedBox(height: 8),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       );
//     }

//     Widget nominalPenarikan() {
//       int nominalSaldo = 0;
//       String v = "";
//       if (komisiModelP?.commissionBalance != null) {
//         v = komisiModelP?.commissionBalance?.replaceAll(".", "") ?? "";
//         v = v.replaceAll("Rp", "");
//         v = v.trim();
//         nominalSaldo = int.parse(v);
//       }
//       return Form(
//         key: tarikKomisiP.tarikKomisiKey,
//         child: Container(
//           margin: EdgeInsets.only(top: 55, left: 45, right: 45),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Container(
//                 margin: EdgeInsets.only(left: 20, top: 3, right: 20),
//                 child: Text(
//                   'Isi nominal penarikan',
//                   style: Constant.primaryTextStyle.copyWith(
//                       fontSize: 18,
//                       fontWeight: Constant.medium,
//                       color: Colors.black),
//                 ),
//               ),
//               SizedBox(
//                 height: 8,
//               ),
//               CustomTextField.underlineTextField(
//                 tarikKomisiP.nominal,
//                 colorBorder: Colors.black,
//                 textInputType: TextInputType.number,
//                 isDecimalFormatter: true,
//                 enabled: nominalSaldo > 0,
//                 onChange: (val) {
//                   if (val.trim() == "") {
//                     tarikKomisiP.nominalPenarikan = 0;
//                   } else {
//                     tarikKomisiP.nominalPenarikan =
//                         int.parse(val.replaceAll(".", ""));
//                   }
//                   setState(() {});
//                 },
//                 // inputFormatters: [
//                 // FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                 // FilteringTextInputFormatter.digitsOnly,
//                 // ],
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   TextButton(
//                     onPressed: () {
//                       if (nominalSaldo > 0) {
//                         tarikKomisiP.nominal.text =
//                             "${thousandSeparator(komisiP.allNominalPenarikan)}";
//                         tarikKomisiP.nominalPenarikan =
//                             komisiP.allNominalPenarikan;
//                         tarikKomisiP.nominal.selection =
//                             TextSelection.collapsed(
//                                 offset: tarikKomisiP.nominal.text.length);
//                         setState(() {});
//                       }
//                     },
//                     child: Text(
//                       "Tarik Semua",
//                       style: Constant.primaryTextStyle.copyWith(
//                           color: nominalSaldo > 0 ? Colors.blue : Colors.grey),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       );
//     }

//     Widget button() {
//       int nominalSaldo = 0;
//       String v = "";
//       if (komisiModelP?.commissionBalance != null) {
//         v = komisiModelP?.commissionBalance?.replaceAll(".", "") ?? "";
//         v = v.replaceAll("Rp", "");
//         v = v.trim();
//         nominalSaldo = int.parse(v);
//       }
//       return Container(
//           height: 60,
//           color: Colors.white,
//           padding: EdgeInsets.only(left: 30, top: 10),
//           child: CustomButton.mainButton("Ajukan Penarikan", () {
//             if (nominalSaldo > 0 &&
//                 nominalSaldo >=
//                     tarikKomisiP
//                         .nominalPenarikan /*&& tarikKomisiP.nominal.value != ""*/) {
//               Utils.showYesNoDialog(
//                 context: context,
//                 title: "Penarikan Komisi",
//                 desc: 'Apakah Anda ingin mengajukan penarikan komisi?',
//                 yesCallback: () async {
//                   handleTap(() async {
//                     await context
//                         .read<TarikKomisiProvider>()
//                         .tarikKomisi()
//                         .then((value) async {
//                       await Utils.showSuccess(msg: "Berhasil Tarik Komisi");
//                       Navigator.pop(context);
//                       Navigator.pop(context);
//                     }).onError((error, stackTrace) {
//                       FirebaseCrashlytics.instance
//                           .log("Tarik Komisi Error : " + error.toString());
//                       Utils.showFailed(
//                           msg:
//                               error.toString().toLowerCase().contains("doctype")
//                                   ? "Gagal Tarik Komisi"
//                                   : "$error");
//                     });
//                   });
//                 },
//                 noCallback: () {
//                   Navigator.pop(context);
//                 },
//               );
//             }
//           },
//               color: nominalSaldo > 0 &&
//                       nominalSaldo >=
//                           tarikKomisiP
//                               .nominalPenarikan /*&& tarikKomisiP.nominal.value != ""*/
//                   ? Constant.primaryColor
//                   : Colors.grey));
//     }

//     return Scaffold(
//       appBar: header(),
//       floatingActionButton: button(),
//       // resizeToAvoidBottomInset: false,
//       body: Container(
//         child: RefreshIndicator(
//           color: Constant.primaryColor,
//           onRefresh: () async {
//             await saldoMenu();
//           },
//           child: ListView(
//             shrinkWrap: true,
//             children: [
//               saldoMenu(),
//               nominalPenarikan(),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
