// import 'dart:convert';
// import 'dart:developer';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/notifikasi/model/notifikasi_model.dart';
// import 'package:chatour/utils/utils.dart';
// import 'package:flutter/material.dart';

// class NotifikasiProvider extends BaseController with ChangeNotifier {
//   NotifikasiModel _notifikasiModel = NotifikasiModel();

//   NotifikasiModel get notifikasiModel => this._notifikasiModel;

//   set notifikasiModel(NotifikasiModel value) => this._notifikasiModel = value;

//   bool isNotif = true;
//   bool get getIsNotif => this.isNotif;
  
//   Future<void> fetchNotif({bool withLoading = false}) async {
//     log("IS NOTIF : $getIsNotif");
//     if (withLoading) loading(true);
//     final response = await get(Constant.BASE_API_FULL + '/agen/notificationv2');

//     if (response.statusCode == 200) {
//       final model = NotifikasiModel.fromJson(jsonDecode(response.body));
//       notifikasiModel = model;
//       notifyListeners();

//       if (withLoading) loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }

//   // Future<void> fetchNotif() async {
//   //   Utils.showLoading();
//   //   log("Notif : ${notifikasiModel}");
//   //   await Utils.dismissLoading();
//   // }
// }
