// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/common/helper/scroll_listener.dart';
// import 'package:chatour/src/notifikasi/provider/notifikasi_detail_provider.dart';
// // import 'package:chatour/src/notifikasi/provider/notifikasi_provider.dart';
// import 'package:chatour/utils/utils.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// class DetailNotifikasiView extends StatefulWidget {
//   const DetailNotifikasiView({super.key, required this.id});

//   static Widget create(int id) => ChangeNotifierProvider<ScrollListener>(
//       create: (context) => ScrollListener.initialise(ScrollController()),
//       child: DetailNotifikasiView(
//         id: id,
//       ));

//   final int id;

//   @override
//   State<DetailNotifikasiView> createState() => _DetailNotifikasiViewState();
// }

// class _DetailNotifikasiViewState extends State<DetailNotifikasiView> {
//   @override
//   void initState() {
//     // context.read<NotifikasiDetailProvider().fetchDetailNotifikasi(widget.id);
//     context.read<NotifikasiDetailProvider>().fetchDetailNotifikasi(widget.id);

//     super.initState();
//   }

//   // getData() async {
//   //   await Utils.showLoading();
//   //   await context.read<NotifikasiDetailProvider>().notifikasiDetailModel.data;
//   //   await Utils.dismissLoading();
//   // }

//   @override
//   Widget build(BuildContext context) {
//     // final listNotif = context.watch<NotifikasiDetailProvider>().notifikasiDetailModel.data;
//     final listen = context.watch<ScrollListener>();
//     final detail =
//         context.watch<NotifikasiDetailProvider>().notifikasiDetailModel.data;
//     return Scaffold(
//       appBar: CustomAppBar.appBar('Detail Notifikasi',
//           isCenter: true, isLeading: true, color: Colors.black),
//       body: Container(
//         margin: EdgeInsets.only(top: 24, left: 30, right: 30),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Container(
//               height: 190,
//               decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(14),
//                   image: DecorationImage(
//                       image: AssetImage('assets/images/notif.png'),
//                       fit: BoxFit.cover)),
//             ),
//             SizedBox(
//               height: 20,
//             ),
//             Row(
//               // crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Image.asset(
//                   'assets/icons/iconnotifdetail.png',
//                   width: 24,
//                 ),
//                 SizedBox(
//                   width: 14,
//                 ),
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       '${detail?.title}',
//                       style: Constant.primaryTextStyle.copyWith(
//                           fontSize: 16, fontWeight: Constant.semibold),
//                     ),
//                     SizedBox(
//                       height: 4,
//                     ),
//                     Text(
//                       '${detail?.createdDesc}',
//                       style: Constant.primaryTextStyle.copyWith(fontSize: 12),
//                     ),
//                   ],
//                 )
//               ],
//             ),
//             SizedBox(
//               height: 24,
//             ),
//             // Divider(
//             //   thickness: 0.5,
//             //   color: Colors.grey,
//             // )
//             Text(
//               '${detail?.message}',
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
