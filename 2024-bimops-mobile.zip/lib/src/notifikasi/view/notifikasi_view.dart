// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/notifikasi/model/notifikasi_model.dart';
// import 'package:chatour/src/notifikasi/provider/notifikasi_provider.dart';
// import 'package:chatour/src/notifikasi/view/notifikasi_detail_view.dart';
// import 'package:chatour/utils/utils.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';

// class NotifikasiView extends StatefulWidget {
//   @override
//   State<NotifikasiView> createState() => _NotifikasiViewState();
// }

// class _NotifikasiViewState extends State<NotifikasiView> {
//   @override
//   Widget build(BuildContext context) {
//     final Notifikasi = context.watch<NotifikasiProvider>();
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar(
//         'Notifikasi',
//         color: Colors.black,
//         isLeading: false,
//         isCenter: true,
//       );
//     }

//     Widget cardNotifikasi() {
//       return ListView.builder(
//         physics: NeverScrollableScrollPhysics(),
//         shrinkWrap: true,
//         itemCount: Notifikasi.notifikasiModel.data?.data?.length,
//         itemBuilder: (context, index) {
//           final notif = Notifikasi.notifikasiModel.data?.data?[index];
//           return GestureDetector(
//             onTap: () {
//               Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                       builder: (context) =>
//                           DetailNotifikasiView.create(notif?.id ?? 0)));
//             },
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 CustomContainer.mainCard(
//                   isShadow: true,
//                   margin: EdgeInsets.only(top: 8, left: 8, right: 8),
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           SizedBox(
//                             width: 26,
//                             height: 26,
//                             child: Image.asset(
//                                 'assets/icons/${iconPath(notif?.type ?? "-")}'),
//                           ),
//                           SizedBox(width: 4),
//                           Expanded(
//                             child: Column(
//                               mainAxisSize: MainAxisSize.min,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Text(
//                                   '${notif?.title}',
//                                   style: Constant.primaryTextStyle.copyWith(
//                                     fontSize: 15,
//                                     color: (notif?.type ?? "-") ==
//                                                 "commission_withdrawal" ||
//                                             (notif?.type ?? "-") ==
//                                                 "withdrawal_submission"
//                                         ? Constant.textPriceColor
//                                         : Constant.primaryColor,
//                                   ),
//                                 ),
//                                 SizedBox(
//                                   height: 5,
//                                 ),
//                                 Text(
//                                   '${notif?.message}',
//                                   style: Constant.primaryTextStyle.copyWith(
//                                       fontWeight: Constant.semibold,
//                                       fontSize: 15),
//                                 ),
//                                 SizedBox(
//                                   height: 5,
//                                 ),
//                                 Text(
//                                   '${notif?.createdDesc}',
//                                   style: Constant.primaryTextStyle.copyWith(
//                                       color: Constant.textColor2, fontSize: 12),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//                 // CustomContainer.mainCard(
//                 //   isShadow: true,
//                 //   margin: EdgeInsets.only(top: 8, left: 8, right: 8),
//                 //   child: Column(
//                 //     mainAxisSize: MainAxisSize.min,
//                 //     crossAxisAlignment: CrossAxisAlignment.start,
//                 //     children: [
//                 //       Row(
//                 //         crossAxisAlignment: CrossAxisAlignment.start,
//                 //         children: [
//                 //           SizedBox(
//                 //             width: 26,
//                 //             height: 26,
//                 //             child: Image.asset('assets/icons/tambah Jamaah.png'),
//                 //           ),
//                 //           SizedBox(width: 4),
//                 //           Expanded(
//                 //             child: Column(
//                 //               mainAxisSize: MainAxisSize.min,
//                 //               crossAxisAlignment: CrossAxisAlignment.start,
//                 //               children: [
//                 //                 Text('Tambah Jamaah',
//                 //                     style: Constant.primaryTextStyle.copyWith(
//                 //                         fontSize: 15,
//                 //                         color: Constant.primaryColor)),
//                 //                 SizedBox(
//                 //                   height: 5,
//                 //                 ),
//                 //                 Text(
//                 //                   'Penambahan Jamaah Idris Ali Berhasil',
//                 //                   style: Constant.primaryTextStyle.copyWith(
//                 //                       fontWeight: Constant.semibold,
//                 //                       fontSize: 15),
//                 //                 ),
//                 //                 SizedBox(
//                 //                   height: 5,
//                 //                 ),
//                 //                 Text(
//                 //                   '12 November 2023 13:09',
//                 //                   style: Constant.primaryTextStyle.copyWith(
//                 //                       color: Constant.textColor2, fontSize: 12),
//                 //                 ),
//                 //               ],
//                 //             ),
//                 //           ),
//                 //         ],
//                 //       ),
//                 //     ],
//                 //   ),
//                 // ),
//               ],
//             ),
//           );
//           // CustomContainer.mainCard(
//           //   isShadow: true,
//           //   margin: EdgeInsets.only(top: 8, left: 8, right: 8),
//           //   child: Column(
//           //     mainAxisSize: MainAxisSize.min,
//           //     crossAxisAlignment: CrossAxisAlignment.start,
//           //     children: [
//           //       Text(
//           //         'Tambah Jamaah',
//           //         style: Constant.primaryTextStyle,
//           //       ),
//           //       SizedBox(
//           //         height: 4,
//           //       ),
//           //       Text(
//           //         'Penambahan Jamaah Idris Ali Berhasil',
//           //         style: Constant.primaryTextStyle.copyWith(
//           //           fontWeight: Constant.semibold,
//           //         ),
//           //       ),
//           //       SizedBox(
//           //         height: 4,
//           //       ),
//           //       Text(
//           //         '12 November 2023 13.09',
//           //         style: Constant.primaryTextStyle,
//           //       )
//           //     ],
//           //   ),
//           // );
//         },
//       );
//     }

//     return Scaffold(
//       appBar: header(),
//       body: Container(
//         child: RefreshIndicator(
//           color: Constant.primaryColor,
//           onRefresh: () async {
//             await context
//                 .read<NotifikasiProvider>()
//                 .fetchNotif(withLoading: true);
//           },
//           child: ListView(
//             shrinkWrap: true,
//             children: [
//               cardNotifikasi(),
//               SizedBox(height: 24),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   String iconPath(String type) {
//     if (type == "commission_withdrawal" || type == "withdrawal_submission") {
//       return "Tarik Komisi.png";
//     }
//     return "tambah Jamaah.png";
//   }
// }
