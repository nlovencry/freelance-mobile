// import 'dart:convert';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/sub_agen/model/sub_agen_detail_model.dart';
// import 'package:flutter/material.dart';
// import 'package:syncfusion_flutter_charts/charts.dart';

// class DetailSubAgenProvider extends BaseController with ChangeNotifier {
//   SubAgenDetailModel subAgenDetailModel = SubAgenDetailModel();

//   SubAgenDetailModel get getsubAgenDetailModel => this.subAgenDetailModel;

//   set getsubAgenDetailModel(SubAgenDetailModel value) =>
//       this.subAgenDetailModel = value;

//   late TooltipBehavior _tooltipBehavior;
//   late ZoomPanBehavior _zoomPanBehavior;
//   TooltipBehavior get tooltipBehavior => this._tooltipBehavior;

//   set tooltipBehavior(TooltipBehavior value) => this._tooltipBehavior = value;

//   ZoomPanBehavior get zoomPanBehavior => this._zoomPanBehavior;

//   set zoomPanBehavior(ZoomPanBehavior value) => this._zoomPanBehavior = value;

//   Future<void> fetchDetailSubAgen(int id) async {
//     loading(true);
//     final response =
//         await get(Constant.BASE_API_FULL + '/agen/detail-sub-agen/${id}');

//     if (response.statusCode == 200) {
//       final subagen = SubAgenDetailModel.fromJson(jsonDecode(response.body));
//       getsubAgenDetailModel = subagen;
//       notifyListeners();
//       loading(false);
//     } else {
//       final message = jsonDecode(response.body)['message'];
//       loading(false);
//       throw Exception(message);
//     }
//   }
// }
