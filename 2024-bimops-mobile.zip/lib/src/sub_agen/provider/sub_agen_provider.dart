// import 'dart:convert';
// import 'dart:developer';
// import 'dart:io';

// import 'package:chatour/common/base/base_controller.dart';
// import 'package:chatour/common/base/base_response.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/profil/model/bank_model.dart';
// import 'package:chatour/src/sub_agen/model/sub_agen_model.dart';
// import 'package:flutter/material.dart';
// import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
// import 'package:intl/intl.dart';

// import 'package:http/http.dart' as http;
// import '../../../common/helper/multipart.dart';
// import '../../../main.dart';
// import '../../../utils/utils.dart';

// class SubAgenProvider extends BaseController with ChangeNotifier {
//   bool _isFetching = false;
//   bool get isFetching => this._isFetching;

//   set isFetching(bool value) => this._isFetching = value;
//   SubAgenModel _SubAgenModel = SubAgenModel();

//   SubAgenModel get subagenmodel => this._SubAgenModel;

//   set subagenmodel(SubAgenModel value) => this._SubAgenModel = value;

//   BankModel _bankModel = BankModel();

//   BankModel get bankModel => this._bankModel;

//   set bankModel(BankModel value) => this._bankModel = value;

//   TextEditingController NIKC = TextEditingController();
//   TextEditingController namaLengkapC = TextEditingController();
//   TextEditingController emailC = TextEditingController();
//   TextEditingController noTelpC = TextEditingController();
//   TextEditingController tempatLahirC = TextEditingController();
//   TextEditingController tanggalLahirC = TextEditingController();
//   TextEditingController alamatC = TextEditingController();
//   TextEditingController noRekC = TextEditingController();
//   TextEditingController atasNamaRekC = TextEditingController();

//   TextEditingController _provinsiC = TextEditingController();
//   TextEditingController _kotaC = TextEditingController();
//   TextEditingController _kecamatanNameVC = TextEditingController();
//   TextEditingController _desaC = TextEditingController();

//   TextEditingController get provinsiC => this._provinsiC;

//   set provinsiC(TextEditingController value) => this._provinsiC = value;

//   TextEditingController get kotaC => this._kotaC;

//   set kotaC(value) => this._kotaC = value;

//   TextEditingController get kecamatanNameVC => this._kecamatanNameVC;

//   set kecamatanNameVC(value) => this._kecamatanNameVC = value;

//   TextEditingController get desaC => this._desaC;

//   set desaC(value) => this._desaC = value;

//   PagingController<int, SubAgenModelData> _pagingController =
//       PagingController(firstPageKey: 1);

//   PagingController<int, SubAgenModelData> get pagingController =>
//       this._pagingController;

//   set pagingController(PagingController<int, SubAgenModelData> value) =>
//       this._pagingController = value;

//   TextEditingController searchC = TextEditingController();

//   int pageSize = 0;

//   get getPageSize => this.pageSize;

//   set setPageSize(pageSize) => this.pageSize;

//   String? _provinsiNameV;
//   String? _kotaNameV;
//   String? _kecamatanNameV;
//   String? _desaNameV;
//   String? _bankRekV;

//   String? get provinsiNameV => this._provinsiNameV;

//   set provinsiNameV(String? value) {
//     this._provinsiNameV = value;
//     notifyListeners();
//   }

//   get kotaNameV => this._kotaNameV;

//   set kotaNameV(value) {
//     this._kotaNameV = value;
//     notifyListeners();
//   }

//   get kecamatanNameV => this._kecamatanNameV;

//   set kecamatanNameV(value) {
//     this._kecamatanNameV = value;
//     notifyListeners();
//   }

//   get desaNameV => this._desaNameV;

//   set desaNameV(value) {
//     this._desaNameV = value;
//     notifyListeners();
//   }

//   get bankRekV => this._bankRekV;

//   set bankRekV(value) {
//     this._bankRekV = value;
//     notifyListeners();
//   }

//   String? _provinsiIdV;
//   String? _kotaIdV;
//   String? _kecamatanIdV;
//   String? _desaIdV;
//   String? get provinsiIdV => this._provinsiIdV;

//   set provinsiIdV(String? value) {
//     this._provinsiIdV = value;
//     notifyListeners();
//   }

//   get kotaIdV => this._kotaIdV;

//   set kotaIdV(value) {
//     this._kotaIdV = value;
//     notifyListeners();
//   }

//   get kecamatanIdV => this._kecamatanIdV;

//   set kecamatanIdV(value) {
//     this._kecamatanIdV = value;
//     notifyListeners();
//   }

//   get desaIdV => this._desaIdV;

//   set desaIdV(value) {
//     this._desaIdV = value;
//     notifyListeners();
//   }

//   bool _gender = true;

//   get gender => _gender;

//   set gender(value) {
//     this._gender = value;
//     notifyListeners();
//   }

//   GlobalKey<FormState> profileKey = GlobalKey<FormState>();

//   DateTime? _tanggalLahir;

//   get tanggalLahir => _tanggalLahir;

//   setTanggalLahir(DateTime? date) {
//     _tanggalLahir = date;
//     tanggalLahirC.text =
//         DateFormat("dd MMMM yyyy").format(date ?? DateTime.now()).toString();

//     notifyListeners();
//   }

//   bool isSubAgent = true;
//   bool get getIsSubAgent => this.isSubAgent;

//   set setIsSubAgent(bool isSubAgent) => this.isSubAgent = isSubAgent;

//   File? _pasPhotoPic;
//   File? get pasPhotoPic => _pasPhotoPic;

//   set pasPhotoPic(File? pasPhotoPic) {
//     _pasPhotoPic = pasPhotoPic;
//     notifyListeners();
//   }

//   File? _ktpPic;
//   File? get ktpPic => _ktpPic;

//   set ktpPic(File? ktpPic) {
//     _ktpPic = ktpPic;
//     notifyListeners();
//   }

//   File? _paymentPic;
//   File? get paymentPic => _paymentPic;

//   set paymentPic(File? paymentPic) {
//     _paymentPic = paymentPic;
//     notifyListeners();
//   }

//   Future<void> fetchSubAgen({
//     bool withLoading = false,
//     required int page,
//   }) async {
//     if (!isFetching) {
//       isFetching = true;

//       log("IS SUB AGENT : $getIsSubAgent");
//       if (withLoading) loading(true);
//       Map<String, String> param = {
//         'page': '$page',
//         'key': searchC.text,
//         // 'is_promo': isPromo == true ? "1" : "0",
//         // 'is_reguler': isReguler == true ? "1" : "0",
//       };
//       final response = await get(Constant.BASE_API_FULL + '/agen/list-sub-agen',
//           query: param);

//       if (response.statusCode == 200) {
//         final model = SubAgenModel.fromJson(jsonDecode(response.body));
//         // subagenmodel = subagen;

//         final newItems = model.data ?? [];
//         pageSize = model.pagination?.perPage ?? 0;
//         final isLastPage = newItems.length < pageSize;
//         if (isLastPage) {
//           pagingController.appendLastPage(newItems as List<SubAgenModelData>);
//         } else {
//           final nextPageKey = page += 1;
//           pagingController.appendPage(
//               newItems as List<SubAgenModelData>, nextPageKey);
//         }
//         notifyListeners();
//         if (withLoading) loading(false);
//       } else {
//         final message = jsonDecode(response.body)['message'];
//         loading(false);
//         throw Exception(message);
//       }
//       isFetching = false;
//     }
//   }

//   Future<void> fetchsubAgen() async {
//     Utils.showLoading();
//     log("NIK : ${NIKC.text}");
//     log("TANGGAL LAHIR : ${tanggalLahirC.text}");
//     log("TANGGAL LAHIR VALUE : ${tanggalLahir}");
//     log("JENIS KELAMIN : ${gender ? "Laki-laki" : "Perempuan"}");
//     log("PROVINSI : $provinsiNameV");
//     await Utils.dismissLoading();
//   }

//   Future<void> addSubAgen() async {
//     loading(true);
//     if (profileKey.currentState!.validate()) {
//       Map<String, String> param = {
//         'nik': NIKC.text,
//         'name': namaLengkapC.text,
//         'email': emailC.text,
//         'phone': "62" + noTelpC.text,
//         'birth_place': tempatLahirC.text,
//         'birth_date': tanggalLahir.toString(),
//         'gender': "${gender ? 1 : 0}",
//         'address': alamatC.text,
//         'province': provinsiNameV.toString(),
//         'city': kotaNameV.toString(),
//         'sub_district': kecamatanNameV.toString(),
//         'district': desaNameV.toString(),
//         'bank_name': bankRekV.toString(),
//         'bank_account': noRekC.text,
//         "account_name": atasNamaRekC.text,
//       };
//       // if (NIKC.text != "") {
//       //   param.addAll({'nik': NIKC.text});
//       // }
//       // if (tempatLahirC.text != "") {
//       //   param.addAll({'birth_place': tempatLahirC.text});
//       // }
//       // if (tanggalLahir != null) {
//       //   param.addAll({'birth_date': tanggalLahir.toString()});
//       // }
//       // if (alamatC.text != "") {
//       //   param.addAll({'address': alamatC.text});
//       // }
//       // if (provinsiNameV != null) {
//       //   param.addAll({'province': provinsiNameV.toString()});
//       // }
//       // if (kotaNameV != null) {
//       //   param.addAll({'city': kotaNameV.toString()});
//       // }
//       // if (kecamatanNameV != null) {
//       //   param.addAll({'sub_district': kecamatanNameV.toString()});
//       // }
//       // if (bankRekV != null) {
//       //   param.addAll({'bank_name': bankRekV.toString()});
//       // }
//       // if (noRekC.text != "") {
//       //   param.addAll({'bank_account': noRekC.text});
//       // }

//       List<http.MultipartFile> files = [];
//       if (pasPhotoPic != null) {
//         files.add(await getMultipart('pas_photo', File(pasPhotoPic!.path)));
//       } else {
//         throw 'Harap Isi Pas Foto';
//       }
//       if (ktpPic != null) {
//         files.add(await getMultipart('id_card', File(ktpPic!.path)));
//       } else {
//         throw 'Harap Isi Foto KTP';
//       }
//       if (paymentPic != null) {
//         files.add(await getMultipart('down_payment', File(paymentPic!.path)));
//       } else {
//         throw 'Harap Isi Foto Bukti Pembayaran';
//       }
//       final response = BaseResponse.from(await post(
//         Constant.BASE_API_FULL + '/agen/add-sub-agen',
//         body: param,
//         files: files.isEmpty ? null : files,
//       ));

//       if (response.success) {
//         NIKC.clear();
//         namaLengkapC.clear();
//         emailC.clear();
//         noTelpC.clear();
//         tempatLahirC.clear();
//         _tanggalLahir = null;
//         tanggalLahirC.clear();
//         gender = true;
//         alamatC.clear();
//         provinsiIdV = null;
//         provinsiNameV = null;
//         kotaIdV = null;
//         kotaNameV = null;
//         kecamatanIdV = null;
//         kecamatanNameV = null;
//         desaIdV = null;
//         desaNameV = null;
//         noRekC.clear();
//         atasNamaRekC.clear();
//         bankRekV = null;
//         pasPhotoPic = null;
//         ktpPic = null;
//         paymentPic = null;
//         loading(false);
//       } else {
//         loading(false);
//         throw Exception(response.message);
//       }
//     } else {
//       loading(false);
//       throw 'Harap Lengkapi Form';
//     }
//   }

//   Future<void> clearSubAgen() async {
//     NIKC.clear();
//     namaLengkapC.clear();
//     emailC.clear();
//     noTelpC.clear();
//     tempatLahirC.clear();
//     _tanggalLahir = null;
//     tanggalLahirC.clear();
//     gender = true;
//     alamatC.clear();
//     provinsiIdV = null;
//     provinsiNameV = null;
//     kotaIdV = null;
//     kotaNameV = null;
//     kecamatanIdV = null;
//     kecamatanNameV = null;
//     desaIdV = null;
//     desaNameV = null;
//     noRekC.clear();
//     atasNamaRekC.clear();
//     bankRekV = null;
//     pasPhotoPic = null;
//     ktpPic = null;
//     paymentPic = null;
//   }

//   Future<void> fetchBank() async {
//     loading(true);
//     final response = await get(Constant.BASE_API_FULL + '/agen/list-bank');

//     if (response.statusCode == 200) {
//       final model = BankModel.fromJson(jsonDecode(response.body));
//       bankModel = model;
//       notifyListeners();
//       loading(false);
//     } else {
//       final message = jsonDecode(response.body)["message"];
//       loading(false);
//       throw Exception(message);
//     }
//   }
// }
