// import 'dart:developer';
// import 'dart:io';

// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/profil/provider/profile_provider.dart';
// import 'package:chatour/src/region/model/region_model.dart';
// import 'package:chatour/src/region/provider/region_provider.dart';
// import 'package:chatour/src/sub_agen/provider/sub_agen_provider.dart';
// import 'package:chatour/utils/utils.dart';
// import 'package:firebase_crashlytics/firebase_crashlytics.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';
// import 'package:path/path.dart' as p;

// import '../../../common/base/base_state.dart';
// import '../../../common/component/custom_date_picker.dart';
// import '../../../common/component/custom_dropdown.dart';
// import '../../../common/component/custom_image_picker.dart';
// import '../../../common/component/custom_textfield.dart';

// class AddSubAgenView extends StatefulWidget {
//   @override
//   State<AddSubAgenView> createState() => _AddSubAgenViewState();
// }

// class _AddSubAgenViewState extends BaseState<AddSubAgenView> {
//   @override
//   void initState() {
//     getData();

//     super.initState();
//   }

//   getData() async {
//     await Utils.showLoading();
//     await context.read<ProfileProvider>().fetchBank();
//     // setState(() {});
//     await context.read<RegionProvider>().fetchProvince();
//     await Utils.dismissLoading();
//   }

//   String gender = 'Laki-laki';

//   @override
//   Widget build(BuildContext context) {
//     final subAgenP = context.watch<SubAgenProvider>();
//     final listBank =
//         context.watch<ProfileProvider>().bankModel.data?.banks ?? [];

//     final listProvince = context.watch<RegionProvider>().provinceModel.data;
//     final listCity = context.watch<RegionProvider>().cityModel.data;
//     final listDistrict = context.watch<RegionProvider>().districtModel.data;
//     final listSubDistrict =
//         context.watch<RegionProvider>().subDistrictModel.data;

//     Widget textField(
//         {required TextEditingController controller,
//         Widget? suffixIcon,
//         String? hintText}) {
//       return Column(
//         children: [
//           SizedBox(
//             height: 6,
//           ),
//           TextFormField(
//             cursorColor: Constant.primaryColor,
//             controller: controller,
//             style: Constant.primaryTextStyle,
//             decoration: InputDecoration(
//               isDense: true,
//               contentPadding: EdgeInsets.fromLTRB(14, 14, 14, 14),
//               hintText: hintText ?? "",
//               suffixIcon: Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: suffixIcon,
//               ),
//               suffixIconConstraints:
//                   BoxConstraints(maxHeight: 30, maxWidth: 30),
//               border: OutlineInputBorder(
//                   borderSide: BorderSide.none,
//                   borderRadius: BorderRadius.circular(10)),
//               filled: true,
//               fillColor: Colors.grey.shade200,
//             ),
//           ),
//           SizedBox(
//             height: 10,
//           )
//         ],
//       );
//     }

//     Widget form() {
//       return Form(
//         key: subAgenP.profileKey,
//         child: Container(
//           margin: EdgeInsets.only(top: 20),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               CustomTextField.normalTextField(
//                 controller: subAgenP.NIKC,
//                 labelText: "NIK",
//                 hintText: "NIK",
//                 textInputType: TextInputType.number,
//                 maxLength: 16,
//                 inputFormatters: [
//                   FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                   FilteringTextInputFormatter.digitsOnly
//                 ],
//                 validator: (value) {
//                   if (value != null && value.isNotEmpty) {
//                     // if (value == null || value.isEmpty) {
//                     //   return "Maaf, NIK wajib diisi";
//                     // }
//                     if (value.isNotEmpty && value.length < 6) {
//                       return "NIK harus 16 digit";
//                     }
//                   }
//                   return null;
//                 },
//                 required: false,
//               ),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.namaLengkapC,
//                 labelText: "Nama Lengkap",
//                 hintText: "Nama Lengkap",
//                 textInputType: TextInputType.text,
//                 textCapitalization: TextCapitalization.words,
//               ),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                   controller: subAgenP.emailC,
//                   labelText: "Email",
//                   hintText: "Email"),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.noTelpC,
//                 labelText: "No. Telp",
//                 hintText: "No. Telp",
//                 textInputType: TextInputType.phone,
//                 prefix: Container(
//                     margin: EdgeInsets.fromLTRB(12, 12, 0, 0),
//                     child: Text("62  |")),
//                 inputFormatters: [
//                   FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                   FilteringTextInputFormatter.digitsOnly,
//                   // FilteringTextInputFormatter.allow(RegExp(r'^(0|[1-9][0-9]*)$')),
//                 ],
//               ),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.tempatLahirC,
//                 labelText: "Tempat Lahir",
//                 hintText: "Tempat Lahir",
//                 required: false,
//               ),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.tanggalLahirC,
//                 labelText: "Tanggal Lahir",
//                 hintText: "Tanggal Lahir",
//                 readOnly: true,
//                 onTap: () async {
//                   await subAgenP.setTanggalLahir(
//                       await CustomDatePicker.pickDate(context, DateTime.now()));
//                   FocusManager.instance.primaryFocus?.unfocus();
//                 },
//                 suffixIcon: Icon(Icons.calendar_month),
//                 suffixIconColor: Colors.black,
//                 required: false,
//               ),
//               SizedBox(height: 10),
//               Padding(
//                 padding: const EdgeInsets.only(left: 20, right: 20),
//                 child: Text(
//                   "Jenis Kelamin",
//                   style: Constant.primaryTextStyle.copyWith(
//                     fontSize: 14,
//                     fontWeight: Constant.medium,
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 8),
//                 child: Row(
//                   children: [
//                     Radio(
//                       value: true,
//                       groupValue: subAgenP.gender,
//                       activeColor: Constant.primaryColor,
//                       onChanged: (value) =>
//                           context.read<SubAgenProvider>().gender = value,
//                     ),
//                     Text(
//                       'Laki-laki',
//                       style: Constant.primaryTextStyle,
//                     ),
//                     Radio(
//                       value: false,
//                       groupValue: subAgenP.gender,
//                       activeColor: Constant.primaryColor,
//                       onChanged: (value) =>
//                           context.read<SubAgenProvider>().gender = value,
//                     ),
//                     Text(
//                       'Perempuan',
//                       style: Constant.primaryTextStyle,
//                     ),
//                   ],
//                 ),
//               ),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.alamatC,
//                 labelText: "Alamat",
//                 hintText: "Alamat",
//                 required: false,
//               ),
//               SizedBox(height: 10),
//               CustomDropdown.normalDropdown(
//                   labelText: "Provinsi",
//                   hintText: "Pilih Provinsi",
//                   selectedItem: subAgenP.provinsiNameV,
//                   list: (listProvince ?? [])
//                       .map((e) => DropdownMenuItem(
//                           value: e?.province, child: Text(e?.province ?? "")))
//                       .toList(),
//                   onChanged: (val) {
//                     subAgenP.kotaNameV = null;
//                     subAgenP.kotaIdV = null;
//                     subAgenP.provinsiNameV = val;
//                     subAgenP.kecamatanIdV = null;
//                     subAgenP.kecamatanNameV = null;
//                     subAgenP.desaIdV = null;
//                     subAgenP.desaNameV = null;
//                     subAgenP.provinsiIdV = (listProvince ?? [])
//                         .firstWhere((element) => element?.province == val)
//                         ?.provinceId;
//                     setState(() {});
//                     context.read<RegionProvider>().cityModel = CityModel();
//                     context.read<RegionProvider>().fetchCity(
//                         subAgenP.provinsiIdV ?? "",
//                         withLoading: true);
//                   }),
//               SizedBox(height: 10),
//               CustomDropdown.normalDropdown(
//                 labelText: "Kabupaten / Kota",
//                 selectedItem: subAgenP.kotaNameV,
//                 hintText: "Pilih Kabupaten / Kota",
//                 list: (listCity ?? [])
//                     .map((e) => DropdownMenuItem(
//                         value: e?.cityName, child: Text(e?.cityName ?? "")))
//                     .toList(),
//                 onChanged: (val) {
//                   subAgenP.kecamatanIdV = null;
//                   subAgenP.kecamatanNameV = null;
//                   subAgenP.kotaNameV = val;
//                   subAgenP.kotaIdV = (listCity ?? [])
//                       .firstWhere((element) => element?.cityName == val)
//                       ?.cityId;
//                   setState(() {});

//                   context.read<RegionProvider>().districtModel =
//                       DistrictModel();
//                   context
//                       .read<RegionProvider>()
//                       .fetchDistrict(subAgenP.kotaIdV ?? "", withLoading: true);
//                 },
//               ),
//               SizedBox(height: 10),
//               CustomDropdown.normalDropdown(
//                 labelText: "Kecamatan",
//                 selectedItem: subAgenP.kecamatanNameV,
//                 hintText: "Pilih Kecamatan",
//                 list: (listDistrict ?? [])
//                     .map((e) => DropdownMenuItem(
//                         value: e?.districtName,
//                         child: Text(e?.districtName ?? "")))
//                     .toList(),
//                 onChanged: (val) {
//                   subAgenP.desaIdV = null;
//                   subAgenP.desaNameV = null;
//                   subAgenP.kecamatanNameV = val;
//                   subAgenP.kecamatanIdV = (listDistrict ?? [])
//                       .firstWhere((element) => element?.districtName == val)
//                       ?.districtId;
//                   setState(() {});

//                   context.read<RegionProvider>().subDistrictModel =
//                       SubDistrictModel();
//                   // context.read<RegionProvider>().fetchSubDistrict(
//                   //     subAgenP.kecamatanIdV ?? "", subAgenP.kecamatanIdV ?? "");
//                 },
//               ),
//               // SizedBox(height: 10),
//               // CustomDropdown.normalDropdown(
//               //   labelText: "Kelurahan / Desa",
//               //   selectedItem: subAgenP.desaNameV,
//               //   hintText: "Pilih Kelurahan / Desa",
//               //   list: (listSubDistrict ?? [])
//               //       .map((e) => DropdownMenuItem(
//               //           value: e?.subdistrictName,
//               //           child: Text(e?.subdistrictName ?? "")))
//               //       .toList(),
//               //   onChanged: (val) {
//               //     subAgenP.desaNameV = val;
//               //     subAgenP.desaIdV = (listSubDistrict ?? [])
//               //         .firstWhere((element) => element?.subdistrictName == val)
//               //         ?.subdistrictId;
//               //     setState(() {});
//               //   },
//               // ),
//               SizedBox(height: 10),
//               CustomDropdown.normalDropdown(
//                 labelText: "Bank Rekening",
//                 hintText: "Pilih Bank Rekening",
//                 list: listBank
//                     .map((e) => DropdownMenuItem<String>(
//                           value: e,
//                           child: Text(e ?? ""),
//                         ))
//                     .toList(),
//                 onChanged: (val) => subAgenP.bankRekV = val,
//                 required: true,
//               ),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.noRekC,
//                 labelText: "Nomor Rekening",
//                 hintText: "Nomor Rekening",
//                 textInputType: TextInputType.number,
//                 inputFormatters: [
//                   FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d?')),
//                   FilteringTextInputFormatter.digitsOnly
//                 ],
//                 required: false,
//               ),
//               SizedBox(height: 10),
//               CustomTextField.normalTextField(
//                 controller: subAgenP.atasNamaRekC,
//                 labelText: "Atas Nama Rekening",
//                 hintText: "Atas Nama Rekening",
//                 textCapitalization: TextCapitalization.words,
//                 required: false,
//               ),
//               SizedBox(height: 14),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: Row(
//                   children: [
//                     Icon(Icons.image, size: 24),
//                     Expanded(
//                         child: CustomButton.secondaryButton(
//                             subAgenP.pasPhotoPic != null
//                                 ? p.basename(subAgenP.pasPhotoPic!.path)
//                                 : 'Upload Pas Foto', () async {
//                       var file =
//                           await CustomImagePicker.cameraOrGallery(context);
//                       if (file != null) {
//                         subAgenP.pasPhotoPic = File(file.path);
//                       }
//                     }, margin: EdgeInsets.only(left: 10)))
//                   ],
//                 ),
//               ),
//               SizedBox(height: 14),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: Row(
//                   children: [
//                     Icon(Icons.image, size: 24),
//                     Expanded(
//                         child: CustomButton.secondaryButton(
//                             subAgenP.ktpPic != null
//                                 ? p.basename(subAgenP.ktpPic!.path)
//                                 : 'Upload Foto KTP', () async {
//                       var file =
//                           await CustomImagePicker.cameraOrGallery(context);
//                       if (file != null) {
//                         subAgenP.ktpPic = File(file.path);
//                       }
//                     }, margin: EdgeInsets.only(left: 10)))
//                   ],
//                 ),
//               ),
//               SizedBox(height: 14),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: Row(
//                   children: [
//                     Icon(Icons.image, size: 24),
//                     Expanded(
//                         child: CustomButton.secondaryButton(
//                             subAgenP.paymentPic != null
//                                 ? p.basename(subAgenP.paymentPic!.path)
//                                 : 'Upload Bukti Pembayaran', () async {
//                       var file =
//                           await CustomImagePicker.cameraOrGallery(context);
//                       if (file != null) {
//                         subAgenP.paymentPic = File(file.path);
//                       }
//                     }, margin: EdgeInsets.only(left: 10)))
//                   ],
//                 ),
//               ),
//               SizedBox(height: 24),
//               CustomButton.mainButton(
//                   'Simpan',
//                   () => handleTap(() async {
//                         await context
//                             .read<SubAgenProvider>()
//                             .addSubAgen()
//                             .then((value) async {
//                           await Utils.showSuccess(
//                               msg: "Sukses Tambah Sub Agen");
//                           Future.delayed(Duration(seconds: 2),
//                               () => Navigator.pop(context));
//                         }).onError((error, stackTrace) {
//                           FirebaseCrashlytics.instance.log(
//                               "Tambah Sub Agen Error : " + error.toString());
//                           Utils.showFailed(
//                               msg: error
//                                       .toString()
//                                       .toLowerCase()
//                                       .contains("doctype")
//                                   ? "Gagal Tambah Sub Agen"
//                                   : "$error");
//                         });
//                       }),
//                   color: !isBusy() ? Constant.primaryColor : Colors.grey,
//                   margin: EdgeInsets.symmetric(horizontal: 20)),
//               SizedBox(height: 24),
//             ],
//           ),
//         ),
//       );
//     }

//     return Scaffold(
//       appBar: CustomAppBar.appBar('Masukkan Data Sub Agen',
//           isLeading: true, isCenter: true, color: Colors.black),
//       body: WillPopScope(
//           onWillPop: () async {
//             await Utils.showYesNoDialog(
//               context: context,
//               title: "Batalkan Tambah Sub Agen",
//               desc: 'Apakah Anda yakin ingin membatalkan tambah sub agen?',
//               yesCallback: () async {
//                 await context
//                     .read<SubAgenProvider>()
//                     .clearSubAgen()
//                     .then((value) {
//                   Navigator.of(context)
//                     ..pop()
//                     ..pop();
//                   return true;
//                 }).onError((error, stackTrace) {
//                   FirebaseCrashlytics.instance.log(
//                       "Cancel Tambah Sub Agen Error : " + error.toString());
//                   Utils.showFailed(
//                       msg: error.toString().toLowerCase().contains("doctype")
//                           ? "Gagal Batalkan Tambah Sub Agen!"
//                           : "$error");
//                   return false;
//                 });
//               },
//               noCallback: () {
//                 Navigator.pop(context);
//               },
//             );
//             return false;
//           },
//           child: ListView(children: [form()])),
//     );
//   }
// }
