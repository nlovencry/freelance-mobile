// import 'dart:io';

// import 'package:chatour/common/component/custom_alert.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/common/helper/scroll_listener.dart';
// import 'package:chatour/src/home/view/main_home.dart';
// import 'package:chatour/src/jamaah/provider/detail_jamaah_provider.dart';
// import 'package:chatour/src/jamaah/view/jamaah_sub_agen_view.dart';
// import 'package:chatour/src/komisi/view/komisi_agen_view.dart';
// import 'package:chatour/src/sub_agen/model/sub_agen_detail_model.dart';
// import 'package:chatour/src/sub_agen/provider/detail_sub_agen_provider.dart';
// import 'package:chatour/utils/Utils.dart';
// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/rendering.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:syncfusion_flutter_charts/charts.dart';
// import 'package:url_launcher/url_launcher.dart';

// import '../../../common/helper/safe_network_image.dart';
// import '../../komisi/view/komisi_sub_agen_view.dart';

// // class DetailSubAgen extends StatefulWidget {
// //   @override
// //   State<DetailSubAgen> createState() => _DetailSubAgenState();
// // }

// class DetailSubAgen extends StatefulWidget {
//   const DetailSubAgen({super.key, required this.id});

//   static Widget create(int id) => ChangeNotifierProvider<ScrollListener>(
//       create: (context) => ScrollListener.initialise(ScrollController()),
//       child: DetailSubAgen(id: id));

//   final int id;

//   @override
//   State<DetailSubAgen> createState() => _DetailSubAgenState();
// }

// class _DetailSubAgenState extends State<DetailSubAgen> {
//   @override
//   void initState() {
//     context.read<DetailSubAgenProvider>().fetchDetailSubAgen(widget.id);
//     context.read<DetailSubAgenProvider>().tooltipBehavior =
//         TooltipBehavior(enable: true, header: '' /*, format: 'point.y%'*/);
//     context.read<DetailSubAgenProvider>().zoomPanBehavior = ZoomPanBehavior(
//       enablePanning: true,
//       enablePinching: true,
//       enableMouseWheelZooming: true,
//       enableDoubleTapZooming: true,
//       enableSelectionZooming: true,
//     );
//     super.initState();
//   }

//   // bool _showAppbar = false;
//   @override
//   Widget build(BuildContext context) {
//     final listen = context.watch<ScrollListener>();
//     final detail =
//         context.watch<DetailSubAgenProvider>().getsubAgenDetailModel.data;

//     Future<void> _makePhoneCall(String url) async {
//       if (await canLaunch(url)) {
//         await launch(url);
//       } else {
//         throw 'Could not launch $url';
//       }
//     }

//     openWhatsApp() async {
//       String whatsapp = '${detail?.agen?.phone}';
//       String whatsappUrlAndroid = "https://wa.me/$whatsapp?text=Hello";
//       String whatsappUrlIOS =
//           "https://wa.me/$whatsapp?text=${Uri.parse("Hello")}";
//       if (Platform.isIOS) {
//         if (await canLaunchUrl(Uri.parse(whatsappUrlIOS))) {
//           await launchUrl(Uri.parse(whatsappUrlIOS));
//         } else {
//           throw 'WhatsApp tidak terinstall';
//         }
//       } else {
//         if (await canLaunchUrl(Uri.parse(whatsappUrlAndroid))) {
//           await launchUrl(Uri.parse(whatsappUrlAndroid));
//         } else {
//           throw 'WhatsApp tidak terinstall';
//         }
//       }
//     }

//     Widget header() {
//       return SafeArea(
//         child: Container(
//           margin: EdgeInsets.only(top: 10),
//           width: double.infinity,
//           height: 56,
//           child: AppBar(
//             elevation: 0,
//             backgroundColor: Colors.transparent,
//             foregroundColor: Colors.white,
//             automaticallyImplyLeading: true,
//             leading: InkWell(
//               onTap: () => Navigator.pop(context),
//               child: Icon(Icons.arrow_back),
//             ),
//             centerTitle: true,
//             title: Text(
//               'Detail Sub Agen - ${detail?.agen?.name ?? ""}',
//               textAlign: TextAlign.center,
//               style: Constant.primaryTextStyle
//                   .copyWith(fontSize: 18, color: Colors.white),
//             ),
//           ),
//         ),
//       );
//     }

//     Widget account() {
//       return CustomContainer.mainCard(
//         margin: EdgeInsets.symmetric(horizontal: 15),
//         isShadow: true,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Container(
//               margin: EdgeInsets.only(top: 4),
//               child: Text(
//                 detail?.agen?.mitraNo == null ||
//                         detail?.agen?.mitraNo == "" ||
//                         detail?.agen?.mitraNo == "-"
//                     ? "Mitra No : -"
//                     : '${detail?.agen?.mitraNo}',
//                 style: Constant.primaryTextStyle,
//               ),
//             ),
//             SizedBox(height: 10),
//             Row(
//               children: [
//                 SafeNetworkImage.circle(
//                   url: '${detail?.agen?.photo ?? ""}',
//                   radius: 44,
//                   errorBuilder: CircleAvatar(
//                     radius: 18,
//                     backgroundImage: AssetImage('assets/images/avatar.png'),
//                   ),
//                 ),
//                 // CircleAvatar(
//                 //   radius: 18,
//                 //   backgroundImage: NetworkImage('${detail?.agen?.photo}'),
//                 // ),
//                 SizedBox(
//                   width: 10,
//                 ),
//                 Text(
//                   '${detail?.agen?.name}',
//                   maxLines: 1,
//                   style: Constant.primaryTextStyle.copyWith(
//                     fontSize: 18,
//                     fontWeight: Constant.semibold,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                 )
//               ],
//             ),
//             SizedBox(
//               height: 10,
//             ),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               crossAxisAlignment: CrossAxisAlignment.end,
//               children: [
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Container(
//                         // width: 260,
//                         child: Row(
//                           children: [
//                             SizedBox(width: 8),
//                             Icon(
//                               Icons.email_outlined,
//                               color: Constant.primaryColor,
//                               size: 18,
//                             ),
//                             SizedBox(width: 15),
//                             Flexible(
//                               child: Text(
//                                 '${detail?.agen?.email}',
//                                 maxLines: 1,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                             ),
//                             SizedBox(
//                               width: 6,
//                             ),
//                             (detail?.agen?.email ?? "") == ""
//                                 ? SizedBox()
//                                 : InkWell(
//                                     onTap: () {
//                                       String? email = detail?.agen?.email;
//                                       if (email != null || email != "") {
//                                         Clipboard.setData(new ClipboardData(
//                                             text: email ?? ""));
//                                         CustomAlert.showSnackBar(context,
//                                             'Email berhasil disalin', false,
//                                             color: Colors.black);
//                                       }
//                                     },
//                                     child: Container(
//                                       // padding: EdgeInsets.all(2),
//                                       // width: 46,
//                                       // height: 18,
//                                       decoration: BoxDecoration(
//                                           // color: Constant.primaryColor,
//                                           borderRadius:
//                                               BorderRadius.circular(50)),
//                                       child: Row(
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.center,
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.center,
//                                         children: [
//                                           Icon(
//                                             Icons.copy_outlined,
//                                             color: Constant.primaryColor,
//                                             size: 14,
//                                           ),
//                                           SizedBox(
//                                             width: 2,
//                                           ),
//                                           // Text(
//                                           //   'salin',
//                                           //   style: Constant.primaryTextStyle
//                                           //       .copyWith(
//                                           //           color: Colors.white,
//                                           //           fontSize: 10),
//                                           // ),
//                                         ],
//                                       ),
//                                     ),
//                                   )
//                           ],
//                         ),
//                       ),
//                       SizedBox(
//                         height: 8,
//                       ),
//                       Row(
//                         children: [
//                           SizedBox(
//                             width: 8,
//                           ),
//                           Icon(
//                             Icons.phone_outlined,
//                             color: Constant.primaryColor,
//                             size: 18,
//                           ),
//                           SizedBox(
//                             width: 15,
//                           ),
//                           Flexible(
//                             child: Text(detail?.agen?.phone == null ||
//                                     detail?.agen?.phone == ""
//                                 ? "-"
//                                 : '${detail?.agen?.phone}'),
//                           ),
//                           SizedBox(
//                             width: 6,
//                           ),
//                           (detail?.agen?.phone ?? "") == ""
//                               ? SizedBox()
//                               : InkWell(
//                                   onTap: () {
//                                     String? phone = detail?.agen?.phone;
//                                     if (phone != null || phone != "") {
//                                       Clipboard.setData(new ClipboardData(
//                                           text: detail?.agen?.phone ?? ""));
//                                       CustomAlert.showSnackBar(context,
//                                           'Nomor HP berhasil disalin', false,
//                                           color: Colors.black);
//                                     }
//                                   },
//                                   child: Container(
//                                     // padding: EdgeInsets.all(2),
//                                     // width: 46,
//                                     // height: 18,
//                                     decoration: BoxDecoration(
//                                         // color: Constant.primaryColor,
//                                         borderRadius:
//                                             BorderRadius.circular(50)),
//                                     child: Row(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.center,
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.center,
//                                       children: [
//                                         Icon(
//                                           Icons.copy_outlined,
//                                           color: Constant.primaryColor,
//                                           size: 14,
//                                         ),
//                                         SizedBox(
//                                           width: 2,
//                                         ),
//                                         // Text(
//                                         //   'salin',
//                                         //   style: Constant.primaryTextStyle
//                                         //       .copyWith(
//                                         //           color: Colors.white,
//                                         //           fontSize: 10),
//                                         // ),
//                                       ],
//                                     ),
//                                   ),
//                                 )
//                         ],
//                       ),
//                       SizedBox(
//                         height: 8,
//                       ),
//                       Row(
//                         children: [
//                           SizedBox(width: 8),
//                           Icon(
//                             Icons.location_on_outlined,
//                             color: Constant.primaryColor,
//                             size: 18,
//                           ),
//                           SizedBox(width: 15),
//                           Expanded(
//                             child: Text(
//                               detail?.agen?.city == null ||
//                                       detail?.agen?.city == ""
//                                   ? "-"
//                                   : '${detail?.agen?.city}',
//                               maxLines: 1,
//                               overflow: TextOverflow.ellipsis,
//                             ),
//                           ),
//                           Row(
//                             children: [
//                               InkWell(
//                                 onTap: () {
//                                   setState(() {
//                                     _makePhoneCall(
//                                         'tel:${detail?.agen?.phone}');
//                                   });
//                                 },
//                                 child: Container(
//                                   padding: EdgeInsets.all(4),
//                                   decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(80),
//                                       color: Constant.primaryColor),
//                                   child: Center(
//                                     child: Icon(
//                                       Icons.phone,
//                                       color: Colors.white,
//                                       size: 20,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               SizedBox(
//                                 width: 10,
//                               ),
//                               InkWell(
//                                 onTap: () {
//                                   setState(() {
//                                     openWhatsApp();
//                                   });
//                                 },
//                                 child: Container(
//                                   padding: EdgeInsets.all(6),
//                                   decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(80),
//                                       color: Constant.primaryColor),
//                                   child: Center(
//                                     child: Image.asset(
//                                       'assets/icons/whatsapp.png',
//                                       width: 18,
//                                     ),
//                                   ),
//                                 ),
//                               )
//                             ],
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       );
//     }

//     Widget statistik() {
//       final graph = detail?.dataMonthly;
//       final tooltip = context.watch<DetailSubAgenProvider>().tooltipBehavior;
//       final zoomPanBehavior =
//           context.watch<DetailSubAgenProvider>().zoomPanBehavior;
//       return Container(
//         margin: EdgeInsets.only(top: 10, left: 15, right: 15),
//         padding: EdgeInsets.only(top: 12, right: 12, left: 12),
//         height: 460,
//         width: double.infinity,
//         decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(14),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.grey.withOpacity(0.5),
//                 spreadRadius: 1,
//                 blurRadius: 2,
//               )
//             ]),
//         child: Column(
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text('Closing Bulan ini', style: Constant.primaryTextStyle),
//                 Text('${detail?.closingMonthly ?? 0} Jamaah',
//                     style: Constant.primaryTextStyle)
//               ],
//             ),
//             SizedBox(height: 6),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text('Total Jamaah', style: Constant.primaryTextStyle),
//                 Text('${detail?.totalPilgrim ?? 0} Jamaah',
//                     style: Constant.primaryTextStyle)
//               ],
//             ),
//             SizedBox(height: 6),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text('Tabungan Bulan ini', style: Constant.primaryTextStyle),
//                 Text('${detail?.omsetMonthly ?? 0}',
//                     style: Constant.primaryTextStyle)
//               ],
//             ),
//             SizedBox(height: 6),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text('Komisi Bulan ini', style: Constant.primaryTextStyle),
//                 Text('${detail?.commissionMonthly ?? 0}',
//                     style: Constant.primaryTextStyle)
//               ],
//             ),
//             SizedBox(height: 6),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text('Saldo Komisi', style: Constant.primaryTextStyle),
//                 Text('${detail?.saldoCommission ?? 0}',
//                     style: Constant.primaryTextStyle)
//               ],
//             ),
//             SizedBox(height: 24),
//             SfCartesianChart(
//               primaryXAxis: CategoryAxis(),
//               primaryYAxis: NumericAxis(numberFormat: NumberFormat.compact()),
//               tooltipBehavior: tooltip,
//               zoomPanBehavior: zoomPanBehavior,
//               series: <CartesianSeries<SubAgenDetailModelDataDataMonthly?,
//                   String>>[
//                 ColumnSeries<SubAgenDetailModelDataDataMonthly?, String>(
//                   borderRadius: BorderRadius.only(
//                       topLeft: Radius.circular(16),
//                       topRight: Radius.circular(16)),
//                   spacing: 0.9,
//                   dataSource: detail?.dataMonthly ?? [],
//                   xValueMapper: (SubAgenDetailModelDataDataMonthly? a, b) =>
//                       "${a?.bln ?? 0}",
//                   yValueMapper: (SubAgenDetailModelDataDataMonthly? a, b) =>
//                       a?.total ?? 0,
//                   color: Constant.primaryColor,

//                   // markerSettings:
//                   //     MarkerSettings(isVisible: true, color: Colors.black),
//                   // Enable data label
//                   dataLabelSettings: DataLabelSettings(isVisible: true),
//                 ),
//               ],
//             ),
//             // Container(
//             //   margin: EdgeInsets.only(top: 24),
//             //   height: 211,
//             //   width: 272,
//             //   child: Image.asset(
//             //     'assets/images/statistik.png',
//             //     fit: BoxFit.cover,
//             //   ),
//             // )
//           ],
//         ),
//       );
//     }

//     return Scaffold(
//       extendBodyBehindAppBar: true,
//       appBar: PreferredSize(
//           child: AnimatedBuilder(
//               animation: listen,
//               builder: (context, child) {
//                 if (listen.showAppbar) {
//                   return Container(
//                     color: Constant.primaryColor,
//                     child: CustomAppBar.appBar("Detail Sub Agen",
//                         color: Colors.black, isLeading: true, isCenter: true),
//                   );
//                 }
//                 return AppBar(
//                   elevation: 0,
//                   backgroundColor: Colors.transparent,
//                   foregroundColor: Colors.transparent,
//                   automaticallyImplyLeading: true,
//                   title: Container(),
//                 );
//               }),
//           preferredSize: Size.fromHeight(56)),
//       body: ListView(
//         padding: EdgeInsets.only(top: 0),
//         controller: listen.scrollController,
//         children: [
//           SizedBox(height: 24),
//           Container(
//             height: 280,
//             child: Stack(
//               children: [
//                 Container(
//                   width: 100.w,
//                   height: 171,
//                   decoration: BoxDecoration(
//                       image: DecorationImage(
//                           image: AssetImage(
//                             'assets/images/BG login.png',
//                           ),
//                           fit: BoxFit.fitWidth)),
//                 ),
//                 Positioned(top: -78, left: 0, right: 0, child: header()),
//                 Positioned(top: 80, left: 0, right: 0, child: account())
//               ],
//             ),
//           ),
//           statistik(),
//           Container(
//             margin: EdgeInsets.only(top: 24, left: 30, right: 30),
//             child: CustomButton.mainButton('Perolehan Komisi', () {
//               Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) =>
//                         KomisiSubAgenView(adminId: detail?.agen?.id ?? 0),
//                   ));
//             }),
//           ),
//           Container(
//             margin: EdgeInsets.only(top: 10, left: 30, right: 30),
//             child: CustomButton.mainButton('Daftar Jamaah', color: Colors.black,
//                 () {
//               Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => JamaahSubAgenView(
//                       subAgenid: widget.id,
//                       subAgenName: detail?.agen?.name ?? "",
//                     ),
//                   ));
//             }),
//           ),
//           SizedBox(height: 12),
//         ],
//       ),
//     );
//   }
// }
