// import 'package:chatour/common/base/base_state.dart';
// import 'package:chatour/common/component/custom_appbar.dart';
// import 'package:chatour/common/component/custom_button.dart';
// import 'package:chatour/common/component/custom_container.dart';
// import 'package:chatour/common/helper/constant.dart';
// import 'package:chatour/src/sub_agen/model/sub_agen_model.dart';
// import 'package:chatour/src/sub_agen/provider/sub_agen_provider.dart';
// import 'package:chatour/src/sub_agen/view/detail_sub_agen_view.dart';
// import 'package:chatour/utils/Utils.dart';
// import 'package:flutter/material.dart';
// import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
// import 'package:provider/provider.dart';

// import '../../../common/component/custom_loading_indicator.dart';

// class SubAgenView extends StatefulWidget {
//   @override
//   State<SubAgenView> createState() => _SubAgenViewState();
// }

// class _SubAgenViewState extends BaseState<SubAgenView> {
//   @override
//   void initState() {
//     final jP = context.read<SubAgenProvider>();
//     jP.pagingController = PagingController(firstPageKey: 1)
//       ..addPageRequestListener((pageKey) => jP.fetchSubAgen(page: pageKey));
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final subAgen = context.watch<SubAgenProvider>();
//     final pagingC = context.watch<SubAgenProvider>().pagingController;
//     PreferredSizeWidget header() {
//       return CustomAppBar.appBar('Data Sub Agen',
//           color: Colors.black,
//           action: [
//             Padding(
//                 padding: const EdgeInsets.only(right: 8),
//                 child: GestureDetector(
//                     onTap: () async {
//                       await CustomContainer.showModalBottom2(
//                         context: context,
//                         child: StatefulBuilder(
//                           builder: (context, state) {
//                             final search = context.watch<SubAgenProvider>();
//                             // final reguler2 = context.watch<PaketProvider>().isReguler;
//                             // final promo2 = context.watch<PaketProvider>().isPromo;
//                             return Container(
//                               margin:
//                                   EdgeInsets.only(top: 8, left: 12, right: 12),
//                               child: Column(
//                                 mainAxisSize: MainAxisSize.min,
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Text(
//                                     'Masukkan Nama',
//                                     style: Constant.primaryTextStyle.copyWith(
//                                         fontWeight: Constant.semibold,
//                                         fontSize: 18),
//                                   ),
//                                   SizedBox(height: 5),
//                                   Container(
//                                     padding:
//                                         EdgeInsets.symmetric(horizontal: 10),
//                                     height: 50,
//                                     width: double.infinity,
//                                     decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(14),
//                                         border:
//                                             Border.all(color: Colors.black)),
//                                     child: TextFormField(
//                                       controller: subAgen.searchC,
//                                       decoration: InputDecoration(
//                                           border: InputBorder.none),
//                                     ),
//                                   ),
//                                   SizedBox(height: 16),
//                                   Row(
//                                     crossAxisAlignment: CrossAxisAlignment.end,
//                                     children: [
//                                       CustomButton.secondaryButton(
//                                         'Bersihkan Filter',
//                                         () async {
//                                           loading(true);
//                                           subAgen.searchC.clear();
//                                           pagingC.refresh();
//                                           loading(false);
//                                           Navigator.pop(context);
//                                         },
//                                       ),
//                                       SizedBox(width: 5),
//                                       Expanded(
//                                         child: CustomButton.mainButton(
//                                           'Filter',
//                                           () async {
//                                             loading(true);
//                                             pagingC.refresh();
//                                             loading(false);
//                                             Navigator.pop(context);
//                                           },
//                                           stretched: true,
//                                         ),
//                                       ),
//                                     ],
//                                   )
//                                   // SizedBox(height: 10),
//                                 ],
//                               ),
//                             );
//                           },
//                         ),
//                       );
//                     },
//                     child: ImageIcon(AssetImage('assets/icons/filter 2.png')))),
//           ],
//           isLeading: false,
//           isCenter: true);
//     }

//     Widget cardSubAgen() {
//       return PagedListView(
//         shrinkWrap: true,
//         padding: EdgeInsets.only(bottom: 24),
//         pagingController: pagingC,
//         builderDelegate: PagedChildBuilderDelegate<SubAgenModelData>(
//           firstPageProgressIndicatorBuilder: (_) => Container(
//             color: Colors.white,
//             padding: EdgeInsets.only(top: 32),
//             child: CustomLoadingIndicator.buildIndicator(),
//           ),
//           newPageProgressIndicatorBuilder: (_) => Container(
//             color: Colors.white,
//             child: CustomLoadingIndicator.buildIndicator(),
//           ),
//           noItemsFoundIndicatorBuilder: (_) => Padding(
//             padding: const EdgeInsets.only(top: 56),
//             child: Utils.notFoundImage(),
//           ),
//           itemBuilder: (context, item, index) {
//             final subAgen = item;
//             return GestureDetector(
//               onTap: () {
//                 Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) =>
//                           DetailSubAgen.create(subAgen?.id ?? 0),
//                     ));
//               },
//               child: Container(
//                   // height: 84,
//                   width: double.infinity,
//                   margin: EdgeInsets.only(left: 20, right: 20, top: 10),
//                   padding:
//                       EdgeInsets.only(left: 14, right: 14, top: 12, bottom: 12),
//                   decoration: BoxDecoration(
//                       border: Border.all(color: Colors.grey, width: 0.5),
//                       borderRadius: BorderRadius.circular(14)),
//                   child: Row(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Container(
//                         height: 40,
//                         width: 40,
//                         decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(8),
//                             image: DecorationImage(
//                                 image: AssetImage('assets/images/avatar.png'))),
//                       ),
//                       SizedBox(
//                         width: 12,
//                       ),
//                       Expanded(
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Text(
//                               '${subAgen?.name}'.toUpperCase(),
//                               style: Constant.primaryTextStyle.copyWith(
//                                 fontWeight: Constant.bold,
//                               ),
//                             ),
//                             Divider(
//                               thickness: 0.4,
//                               color: Colors.grey,
//                             ),
//                             // SizedBox(
//                             //   height: 2,
//                             // ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(
//                                   'SBW003147 (01-007-02-07)',
//                                   style: Constant.primaryTextStyle
//                                       .copyWith(fontSize: 12),
//                                 ),
//                                 // Spacer(),
//                                 // jamaah1?.agenName == null ||
//                                 //         jamaah1?.agenName == ""
//                                 //     ? SizedBox(
//                                 //         width: 10,
//                                 //       )
//                                 //     : Row(
//                                 //         mainAxisAlignment: MainAxisAlignment.end,
//                                 //         children: [
//                                 //           Image.asset(
//                                 //             'assets/icons/userr.png',
//                                 //             width: 13,
//                                 //           ),
//                                 //           SizedBox(
//                                 //             width: 8,
//                                 //           ),
//                                 //           Text(
//                                 //             '${jamaah1?.agenName}',
//                                 //             style: Constant.primaryTextStyle
//                                 //                 .copyWith(
//                                 //                     fontWeight: Constant.bold,
//                                 //                     fontSize: 12),
//                                 //           ),
//                                 //         ],
//                                 //       )
//                               ],
//                             ),
//                             SizedBox(
//                               height: 6,
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.start,
//                                   children: [
//                                     Image.asset(
//                                       'assets/icons/userr.png',
//                                       width: 12,
//                                     ),
//                                     SizedBox(
//                                       width: 8,
//                                     ),
//                                     Text(
//                                       '${subAgen?.countPilgrim} Jamaah',
//                                       style: Constant.primaryTextStyle.copyWith(
//                                           // fontWeight: Constant.bold,
//                                           fontSize: 12),
//                                     ),
//                                   ],
//                                 ),
//                                 Row(
//                                   // crossAxisAlignment: CrossAxisAlignment.center,
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     Image.asset(
//                                       'assets/icons/money.png',
//                                       width: 15,
//                                     ),
//                                     SizedBox(
//                                       width: 8,
//                                     ),
//                                     Text(
//                                       Utils.thousandSeparator(
//                                           subAgen?.savings ?? 0),
//                                       style: Constant.primaryTextStyle.copyWith(
//                                           fontWeight: Constant.bold,
//                                           fontSize: 12),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             )
//                           ],
//                         ),
//                       )
//                     ],
//                   )),
//             );
//           },
//         ),
//       );
//     }

//     // Widget cardSubAgen() {
//     //   return ListView.separated(
//     //     physics: NeverScrollableScrollPhysics(),
//     //     shrinkWrap: true,
//     //     separatorBuilder: (context, index) {
//     //       return SizedBox(
//     //         height: 0,
//     //       );
//     //     },
//     //     itemCount: subAgen.subagenmodel.data?.length ?? 0,
//     //     itemBuilder: (context, index) {
//     //       final subAgen = subAgen.subagenmodel.data?[index];
//     //       return GestureDetector(
//     //         onTap: () {
//     //           Navigator.push(
//     //               context,
//     //               MaterialPageRoute(
//     //                 builder: (context) =>
//     //                     DetailSubAgen.create(subAgen?.id ?? 0),
//     //               ));
//     //         },
//     //         child: CustomContainer.mainCard(
//     //           isShadow: true,
//     //           margin: EdgeInsets.only(top: 10, left: 12, right: 12),
//     //           child: Row(
//     //             crossAxisAlignment: CrossAxisAlignment.start,
//     //             children: [
//     //               Expanded(
//     //                 flex: 1,
//     //                 child: subAgen?.photoPath == null
//     //                     ? Container()
//     //                     : CircleAvatar(
//     //                         radius: 26,
//     //                         backgroundImage:
//     //                             NetworkImage('${subAgen?.photoPath}'),
//     //                       ),
//     //               ),
//     //               SizedBox(width: 12),
//     //               Expanded(
//     //                 flex: 8,
//     //                 child: Column(
//     //                   mainAxisSize: MainAxisSize.min,
//     //                   crossAxisAlignment: CrossAxisAlignment.start,
//     //                   children: [
//     //                     Row(
//     //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//     //                       children: [
//     //                         Text('SBW003147 (01-007-02-07)',
//     //                             style: Constant.primaryTextStyle
//     //                                 .copyWith(fontSize: 12)),
//     //                         Row(
//     //                           crossAxisAlignment: CrossAxisAlignment.end,
//     //                           mainAxisAlignment: MainAxisAlignment.end,
//     //                           children: [
//     //                             Image.asset(
//     //                               'assets/icons/koin.png',
//     //                               width: 20,
//     //                             ),
//     //                             SizedBox(
//     //                               width: 4,
//     //                             ),
//     //                             Text(
//     //                               Utils.thousandSeparator(
//     //                                   subAgen?.savings ?? 0),
//     //                               style: Constant.primaryTextStyle
//     //                                   .copyWith(color: Constant.textPriceColor),
//     //                             )
//     //                           ],
//     //                         )
//     //                       ],
//     //                     ),
//     //                     SizedBox(
//     //                       height: 2,
//     //                     ),
//     //                     Text(
//     //                       '${subAgen?.name}',
//     //                       maxLines: 1,
//     //                       overflow: TextOverflow.ellipsis,
//     //                       style: Constant.primaryTextStyle.copyWith(
//     //                           fontWeight: Constant.semibold, fontSize: 16),
//     //                     ),
//     //                     SizedBox(
//     //                       height: 4,
//     //                     ),
//     //                     Row(
//     //                       children: [
//     //                         Container(
//     //                           height: 20,
//     //                           width: 20,
//     //                           decoration: BoxDecoration(
//     //                               image: DecorationImage(
//     //                                   image: AssetImage(
//     //                                       'assets/icons/Tambah Agen hitam 1.png'),
//     //                                   fit: BoxFit.cover)),
//     //                         ),
//     //                         SizedBox(width: 8),
//     //                         Text(
//     //                           '${subAgen?.countPilgrim} Jamaah',
//     //                           maxLines: 1,
//     //                           overflow: TextOverflow.ellipsis,
//     //                           style: Constant.primaryTextStyle,
//     //                         ),
//     //                       ],
//     //                     ),
//     //                   ],
//     //                 ),
//     //               ),
//     //             ],
//     //           ),
//     //         ),
//     //       );
//     //     },
//     //   );
//     // }

//     return Scaffold(
//       // backgroundColor: Constant.primaryColor,
//       appBar: header(),
//       resizeToAvoidBottomInset: true,
//       body: RefreshIndicator(
//         color: Constant.primaryColor,
//         onRefresh: () async => pagingC.refresh(),
//         child: cardSubAgen(),
//       ),
//     );
//   }
// }
