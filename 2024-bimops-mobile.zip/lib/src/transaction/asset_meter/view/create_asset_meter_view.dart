import 'package:bimops/common/component/custom_appbar.dart';
import 'package:bimops/common/component/custom_button.dart';
import 'package:bimops/common/component/custom_textfield.dart';
import 'package:bimops/common/helper/safe_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../../common/component/custom_date_picker.dart';
import '../../../../common/component/custom_dropdown.dart';
import '../../../../common/helper/constant.dart';
import '../provider/asset_meter_provider.dart';

class CreateAssetMeterView extends StatelessWidget {
  CreateAssetMeterView();

  static String thousandSeparator(int val) {
    return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
        .format(val);
  }

  @override
  Widget build(BuildContext context) {
    final assetMeterP = context.watch<AssetMeterProvider>();

    Widget form() {
      return Form(
        key: assetMeterP.createAssetKey,
        child: Padding(
          padding: EdgeInsets.only(top: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomTextField.borderTextField(
                controller: assetMeterP.assetC,
                labelText: "Asset",
                hintText: "Asset",
                textInputType: TextInputType.text,
                textCapitalization: TextCapitalization.words,
              ),
              Constant.xSizedBox16,
              CustomTextField.borderTextField(
                controller: assetMeterP.dateC,
                labelText: "Tanggal Lahir",
                hintText: "Tanggal Lahir",
                readOnly: true,
                onTap: () async {
                  await assetMeterP.setDate(
                      await CustomDatePicker.pickDate(context, DateTime.now()));
                  FocusManager.instance.primaryFocus?.unfocus();
                },
                suffixIcon: Icon(Icons.calendar_month),
                suffixIconColor: Constant.textHintColor,
                required: true,
              ),
              Constant.xSizedBox16,
              CustomDropdown.normalDropdown(
                labelText: "Category",
                hintText: "Select Category",
                selectedItem: assetMeterP.categoryV,
                list: [
                  DropdownMenuItem(value: "a", child: Text("a")),
                  DropdownMenuItem(value: "b", child: Text("b"))
                ],
                // list: (listProvince ?? [])
                //     .map((e) => DropdownMenuItem(
                //         value: e?.province, child: Text(e?.province ?? "")))
                //     .toList(),
                onChanged: (val) {
                  assetMeterP.categoryIdV = val;
                  // subAgenP.kotaNameV = null;
                  // subAgenP.kotaIdV = null;
                  // subAgenP.provinsiNameV = val;
                  // subAgenP.kecamatanIdV = null;
                  // subAgenP.kecamatanNameV = null;
                  // subAgenP.desaIdV = null;
                  // subAgenP.desaNameV = null;
                  // subAgenP.provinsiIdV = (listProvince ?? [])
                  //     .firstWhere((element) => element?.province == val)
                  //     ?.provinceId;
                  // setState(() {});
                  // context.read<RegionProvider>().cityModel = CityModel();
                  // context.read<RegionProvider>().fetchCity(
                  //     subAgenP.provinsiIdV ?? "",
                  //     withLoading: true);
                },
              ),
              Constant.xSizedBox16,
              Row(
                children: [
                  Expanded(
                    flex: 5,
                    child: CustomTextField.borderTextField(
                      padding: EdgeInsets.only(left: 20),
                      required: true,
                      controller: assetMeterP.meter1C,
                      labelText: "Meter 1",
                      hintText: "Meter 1",
                      textInputType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d?')),
                        FilteringTextInputFormatter.digitsOnly
                      ],
                    ),
                  ),
                  Constant.xSizedBox16,
                  Expanded(
                    flex: 5,
                    child: CustomTextField.borderTextField(
                      padding: EdgeInsets.only(right: 20),
                      required: true,
                      controller: assetMeterP.meter2C,
                      labelText: "Meter 2",
                      hintText: "Meter 2",
                      textInputType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d?')),
                        FilteringTextInputFormatter.digitsOnly
                      ],
                    ),
                  ),
                ],
              ),
              Constant.xSizedBox16,
              CustomTextField.borderTextArea(
                controller: assetMeterP.descC,
                labelText: "Description",
                hintText: "Free text",
                textInputType: TextInputType.text,
                textCapitalization: TextCapitalization.words,
                focusNode: assetMeterP.descNode,
              ),
            ],
          ),
        ),
      );
    }

    Widget cancelSaveButton() {
      return Row(
        children: [
          Expanded(child: CustomButton.secondaryButton("Cancel", () {})),
          Constant.xSizedBox16,
          Expanded(child: CustomButton.mainButton("Save", () {}))
        ],
      );
    }

    return Scaffold(
      appBar: CustomAppBar.appBar(context, "Create Asset Meter"),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          child: RefreshIndicator(
            color: Constant.primaryColor,
            onRefresh: () async => await context
                .read<AssetMeterProvider>()
                .fetchAssetMeter(withLoading: true),
            child: Column(
              children: [
                Expanded(
                  child: ListView(
                    children: [
                      form(),
                      Constant.xSizedBox16,
                      SizedBox(height: 48),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: cancelSaveButton(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
