import 'package:bimops/common/component/custom_appbar.dart';
import 'package:bimops/common/component/custom_button.dart';
import 'package:bimops/common/component/custom_textfield.dart';
import 'package:bimops/common/helper/safe_network_image.dart';
import 'package:bimops/src/transaction/asset_meter/view/create_asset_meter_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../../common/component/custom_date_picker.dart';
import '../../../../common/component/custom_dropdown.dart';
import '../../../../common/helper/constant.dart';
import '../provider/asset_meter_provider.dart';

class ViewAssetMeterView extends StatelessWidget {
  ViewAssetMeterView();

  static String thousandSeparator(int val) {
    return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
        .format(val);
  }

  @override
  Widget build(BuildContext context) {
    final assetMeterP = context.watch<AssetMeterProvider>();

    Widget header() {
      return Column(
        children: [
          Row(
            children: [
              Container(
                  width: 60,
                  child: Text("Code", style: Constant.grayRegular12)),
              Constant.xSizedBox16,
              Text("CCR035-0005", style: Constant.blackBold16)
            ],
          ),
          Constant.xSizedBox16,
          Row(
            children: [
              Container(
                  width: 60,
                  child: Text("Name", style: Constant.grayRegular12)),
              Constant.xSizedBox16,
              Text("CC01-Nilam-Mitsubishi", style: Constant.blackBold16)
            ],
          ),
        ],
      );
    }

    Widget table() {
      return ListView.separated(
        shrinkWrap: true,
        itemCount: 7,
        itemBuilder: (context, index) {
          if (index == 0) {
            return Container(
              height: 45,
              color: Constant.primaryColor,
              child: Row(
                children: [
                  Constant.xSizedBox4,
                  Expanded(
                      flex: 1, child: Text("#", style: Constant.whiteBold15)),
                  Expanded(
                      flex: 3,
                      child: Text("Category", style: Constant.whiteBold15)),
                  Constant.xSizedBox4,
                  Expanded(
                      flex: 2,
                      child: Text("Date", style: Constant.whiteBold15)),
                  Constant.xSizedBox4,
                  Expanded(
                      flex: 2,
                      child: Text("Meter", style: Constant.whiteBold15)),
                  Expanded(
                      flex: 3,
                      child: Text("Created by", style: Constant.whiteBold15)),
                  Constant.xSizedBox4,
                ],
              ),
            );
          }
          if (index % 2 == 0) {
            return Container(
              color: Colors.white,
              child: Row(
                children: [
                  Constant.xSizedBox4,
                  Expanded(
                      flex: 1,
                      child: Text("$index", style: Constant.grayRegular13)),
                  Expanded(
                      flex: 3,
                      child: Text("Wirerope-Hoist",
                          style: Constant.grayRegular13)),
                  Constant.xSizedBox4,
                  Expanded(
                      flex: 2,
                      child: Text("2022-09-08", style: Constant.grayRegular13)),
                  Constant.xSizedBox4,
                  Expanded(
                      flex: 2, child: Text("1", style: Constant.grayRegular13)),
                  Expanded(
                      flex: 3,
                      child: Text("Septian Andhika Putra",
                          style: Constant.grayRegular13)),
                  Constant.xSizedBox4,
                ],
              ),
            );
          }
          return Container(
            color: Constant.primaryColor.withOpacity(0.2),
            child: Row(
              children: [
                Constant.xSizedBox4,
                Expanded(
                    flex: 1,
                    child: Text("$index", style: Constant.grayRegular13)),
                Expanded(
                    flex: 3,
                    child:
                        Text("Wirerope-Hoist", style: Constant.grayRegular13)),
                Constant.xSizedBox4,
                Expanded(
                    flex: 2,
                    child: Text("2022-09-08", style: Constant.grayRegular13)),
                Constant.xSizedBox4,
                Expanded(
                    flex: 2, child: Text("1", style: Constant.grayRegular13)),
                Expanded(
                    flex: 3,
                    child: Text("Septian Andhika Putra",
                        style: Constant.grayRegular13)),
                Constant.xSizedBox4,
              ],
            ),
          );
        },
        separatorBuilder: (_, __) => SizedBox(height: 4),
      );
    }

    Widget cancelSaveButton() {
      return Row(
        children: [
          Expanded(child: CustomButton.secondaryButton("Cancel", () {})),
          Constant.xSizedBox16,
          Expanded(child: CustomButton.mainButton("Save", () {}))
        ],
      );
    }

    return Scaffold(
      appBar: CustomAppBar.appBar(context, "View Asset Meter"),
      body: SafeArea(
        child: Container(
          margin: EdgeInsets.only(top: 20),
          padding: EdgeInsets.symmetric(horizontal: 20),
          color: Colors.white,
          child: RefreshIndicator(
            color: Constant.primaryColor,
            onRefresh: () async => await context
                .read<AssetMeterProvider>()
                .fetchAssetMeter(withLoading: true),
            child: ListView(
              children: [
                header(),
                Constant.xSizedBox16,
                table(),
                Constant.xSizedBox16,
                FloatingActionButton(
                    backgroundColor: Constant.primaryColor,
                    child: Icon(
                      Icons.add_rounded,
                      size: 40,
                    ),
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CreateAssetMeterView()))),
                SizedBox(height: 48),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
