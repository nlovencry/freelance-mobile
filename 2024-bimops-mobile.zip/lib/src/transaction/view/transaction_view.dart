import 'package:bimops/common/component/custom_container.dart';
import 'package:bimops/common/component/skeleton.dart';
import 'package:bimops/common/helper/safe_network_image.dart';
import 'package:bimops/src/transaction/model/transaction_model.dart';
import 'package:bimops/src/jamaah/view/detail_jamaah_view.dart';
import 'package:bimops/src/jamaah/view/tambah_jamaah_2_view.dart';
import 'package:bimops/src/jamaah/view/pilih_paket_umroh_view.dart';
import 'package:bimops/src/komisi/view/komisi_sub_agen_view.dart';
import 'package:bimops/src/komisi/view/tarik_komisi_view.dart';
import 'package:bimops/src/paket/view/paket_umroh_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../../common/helper/constant.dart';
import '../../../utils/utils.dart';
import '../../auth/provider/auth_provider.dart';
import '../../komisi/view/komisi_agen_view.dart';
import '../../paket/provider/paket_provider.dart';
import '../../paket/view/paket_haji_view.dart';
import '../../sub_agen/view/add_sub_agen_view.dart';
import '../asset_meter/view/asset_meter_view.dart';
import '../provider/transaction_provider.dart';

class TransactionView extends StatelessWidget {
  TransactionView();

  static String thousandSeparator(int val) {
    return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
        .format(val);
  }

  @override
  Widget build(BuildContext context) {
    final transaction = context.watch<TransactionProvider>();

    Widget subMenu() {
      return Container(
        height: 92,
        margin: EdgeInsets.only(top: 14, left: 20, right: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 3,
              child: InkWell(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => AssetMeterView()));
                },
                child: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        offset: Offset(0, 1),
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 1,
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          margin: EdgeInsets.only(top: 4, bottom: 8),
                          child: Image.asset('assets/icons/ic-asset-meter.png',
                              width: 30)),
                      Text('Asset Meter',
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              flex: 3,
              child: InkWell(
                onTap: () {
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //       builder: (context) => TambahJamaah2View(),
                  //     ));
                },
                child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          offset: Offset(0, 1),
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 2,
                        ),
                      ],
                    ),
                    child: InkWell(
                      onTap: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //       builder: (context) => AddSubAgenView(),
                        //     ));
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              margin: EdgeInsets.only(top: 4, bottom: 8),
                              child: Image.asset(
                                  'assets/icons/ic-asset-downtime.png',
                                  width: 30)),
                          Text('Asset\nDowntime',
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    )),
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              flex: 3,
              child: InkWell(
                onTap: () {
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //       builder: (context) => TambahJamaah2View(),
                  //     ));
                },
                child: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        offset: Offset(0, 1),
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 1,
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          margin: EdgeInsets.only(top: 4, bottom: 8),
                          child: Image.asset(
                              'assets/icons/ic-operation-hours.png',
                              width: 30)),
                      Text('Operation\nHours',
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis)
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        top: true,
        child: Container(
          color: Colors.white,
          child: RefreshIndicator(
            color: Constant.primaryColor,
            onRefresh: () async => await context
                .read<TransactionProvider>()
                .fetchTransaction(withLoading: true),
            child: ListView(
              children: [
                SizedBox(height: 48),
                subMenu(),
                SizedBox(height: 48),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
