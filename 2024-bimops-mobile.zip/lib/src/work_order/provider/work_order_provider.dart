import 'dart:convert';
import 'dart:developer';

import 'package:bimops/common/base/base_controller.dart';
import 'package:bimops/common/helper/constant.dart';
import 'package:bimops/src/work_order/model/work_order_model.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WorkOrderProvider extends BaseController with ChangeNotifier {
  String isSubAgent = "agen";
  String get getIsSubAgent => this.isSubAgent;
  WorkOrderModel workOrderModel = WorkOrderModel();

  WorkOrderModel get getWorkOrderModel => this.workOrderModel;

  set setWorkOrderModel(WorkOrderModel workOrderModel) =>
      this.workOrderModel = workOrderModel;
  set setIsSubAgent(String isSubAgent) => this.isSubAgent = isSubAgent;

  Future<void> fetchWorkOrder({bool withLoading = false}) async {
    log("IS SUB AGENT : $getIsSubAgent");
    if (withLoading) loading(true);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setIsSubAgent = prefs.getString(Constant.kSetPrefRoles) ?? "agen";

    final response = await get(Constant.BASE_API_FULL + '/agen/workOrder');

    if (response.statusCode == 201 || response.statusCode == 200) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      setWorkOrderModel = WorkOrderModel.fromJson(jsonDecode(response.body));
      notifyListeners();

      if (withLoading) loading(false);
      // return model;
    } else {
      final message = jsonDecode(response.body)["message"];
      loading(false);
      throw Exception(message);
    }
  }
}
