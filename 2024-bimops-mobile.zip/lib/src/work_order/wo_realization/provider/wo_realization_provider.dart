import 'dart:convert';
import 'dart:developer';

import 'package:bimops/common/base/base_controller.dart';
import 'package:bimops/common/helper/constant.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/wo_realization_model.dart';

class WORealizationProvider extends BaseController with ChangeNotifier {
  GlobalKey<FormState> createAssetKey = GlobalKey<FormState>();
  TextEditingController _assetSearchC = TextEditingController();
  get assetSearchC => this._assetSearchC;
  set assetSearchC(value) => this._assetSearchC = value;

  TextEditingController assetC = TextEditingController();
  TextEditingController dateC = TextEditingController();
  TextEditingController categoryC = TextEditingController();
  TextEditingController meter1C = TextEditingController();
  TextEditingController meter2C = TextEditingController();
  TextEditingController descC = TextEditingController();

  FocusNode descNode = FocusNode();

  DateTime? _date;

  get date => _date;

  setDate(DateTime? date) {
    _date = date;
    dateC.text =
        DateFormat("dd MMMM yyyy").format(date ?? DateTime.now()).toString();
    notifyListeners();
  }

  String? _categoryV;

  String? get categoryV => this._categoryV;

  set categoryV(String? value) {
    this._categoryV = value;
    notifyListeners();
  }

  String? _categoryIdV;

  String? get categoryIdV => this._categoryIdV;

  set categoryIdV(String? value) {
    this._categoryIdV = value;
    notifyListeners();
  }

  String isSubAgent = "agen";
  String get getIsSubAgent => this.isSubAgent;
  WORealizationModel assetMeterModel = WORealizationModel();

  WORealizationModel get getWORealizationModel => this.assetMeterModel;

  set setWORealizationModel(WORealizationModel assetMeterModel) =>
      this.assetMeterModel = assetMeterModel;
  set setIsSubAgent(String isSubAgent) => this.isSubAgent = isSubAgent;

  Future<void> fetchWORealization({bool withLoading = false}) async {
    log("IS SUB AGENT : $getIsSubAgent");
    if (withLoading) loading(true);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setIsSubAgent = prefs.getString(Constant.kSetPrefRoles) ?? "agen";

    final response = await get(Constant.BASE_API_FULL + '/agen/assetMeter');

    if (response.statusCode == 201 || response.statusCode == 200) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      setWORealizationModel =
          WORealizationModel.fromJson(jsonDecode(response.body));
      notifyListeners();

      if (withLoading) loading(false);
      // return model;
    } else {
      final message = jsonDecode(response.body)["message"];
      loading(false);
      throw Exception(message);
    }
  }
}
