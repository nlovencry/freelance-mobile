import 'package:bimops/common/component/custom_appbar.dart';
import 'package:bimops/common/component/custom_textfield.dart';
import 'package:bimops/common/helper/safe_network_image.dart';
import 'package:bimops/src/transaction/asset_meter/view/create_asset_meter_view.dart';
import 'package:bimops/src/transaction/asset_meter/view/view_asset_meter_view.dart';
import 'package:bimops/src/work_order/wo_agreement/view/view_wo_agreement_view.dart';
import 'package:bimops/src/work_order/wo_realization/view/view_wo_realization_view.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../../common/helper/constant.dart';
import '../provider/wo_realization_provider.dart';
import 'create_wo_realization_view.dart';

class WORealizationView extends StatelessWidget {
  WORealizationView();

  static String thousandSeparator(int val) {
    return NumberFormat.currency(locale: "in_ID", symbol: '', decimalDigits: 0)
        .format(val);
  }

  @override
  Widget build(BuildContext context) {
    final transactionP = context.watch<WORealizationProvider>();

    Widget search() => CustomTextField.borderTextField(
          controller: transactionP.assetSearchC,
          hintText: "Search",
          hintColor: Constant.textHintColor,
          suffixIcon: Padding(
            padding: const EdgeInsets.all(12),
            child: Image.asset(
              'assets/icons/ic-search.png',
              width: 5,
              height: 5,
            ),
          ),
        );

    return Scaffold(
      appBar: CustomAppBar.appBar(context, "Asset Meter"),
      floatingActionButton: FloatingActionButton(
          onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => CreateWORealizationView()))),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          child: RefreshIndicator(
            color: Constant.primaryColor,
            onRefresh: () async => await context
                .read<WORealizationProvider>()
                .fetchWORealization(withLoading: true),
            child: ListView(
              children: [
                search(),
                Constant.xSizedBox16,
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text("Asset List",
                      style: Constant.grayMedium.copyWith(
                          color: Colors.black38, fontWeight: FontWeight.w500)),
                ),
                ListView.separated(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  shrinkWrap: true,
                  itemCount: 4,
                  separatorBuilder: (_, __) => Constant.xSizedBox16,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ViewWORealizationView())),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: SafeNetworkImage.circle(
                              radius: 40,
                              url: "a",
                              errorBuilder: CircleAvatar(
                                backgroundColor: Colors.white,
                                child: Image.asset(
                                    'assets/icons/ic-asset-meter.png'),
                              ),
                            ),
                          ),
                          Constant.xSizedBox4,
                          Expanded(
                            flex: 6,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("ASSET CODE", style: Constant.blackBold),
                                SizedBox(height: 5),
                                Text("Asset Name", style: Constant.grayRegular),
                                SizedBox(height: 5),
                                Text("Site", style: Constant.grayRegular12),
                              ],
                            ),
                          ),
                          Constant.xSizedBox4,
                          Expanded(
                            flex: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  "Asset Category",
                                  style: Constant.grayRegular12,
                                  textAlign: TextAlign.right,
                                ),
                                SizedBox(height: 5),
                                Text(
                                  "Company",
                                  style: Constant.grayRegular12,
                                  textAlign: TextAlign.right,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                SizedBox(height: 48),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
